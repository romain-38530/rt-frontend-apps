"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const mongoose_1 = __importDefault(require("mongoose"));
const orders_1 = __importDefault(require("./routes/orders"));
const invitations_1 = __importDefault(require("./routes/invitations"));
const dispatch_1 = __importDefault(require("./routes/dispatch"));
const lanes_1 = __importDefault(require("./routes/lanes"));
const scoring_1 = __importDefault(require("./routes/scoring"));
const archive_1 = __importDefault(require("./routes/archive"));
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3003;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/rt-orders';
// Middleware - CORS configuration compatible with EB environment
const corsOrigins = process.env.CORS_ALLOWED_ORIGINS || process.env.CORS_ORIGIN || '*';
app.use((0, cors_1.default)({
    origin: corsOrigins === '*' ? '*' : corsOrigins.split(','),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'x-industrial-id', 'x-user-id']
}));
app.use(express_1.default.json());
// Routes
app.get('/', (req, res) => {
    res.json({
        name: 'RT Technologie Orders API',
        version: '2.0.0',
        description: 'API de gestion des commandes SYMPHONI.A - Cycle de vie complet',
        endpoints: {
            health: '/health',
            orders: {
                list: 'GET /api/v1/orders',
                create: 'POST /api/v1/orders',
                get: 'GET /api/v1/orders/:orderId',
                update: 'PUT /api/v1/orders/:orderId',
                cancel: 'PUT /api/v1/orders/:orderId/cancel',
                duplicate: 'POST /api/v1/orders/:orderId/duplicate',
                events: 'GET /api/v1/orders/:orderId/events',
                delete: 'DELETE /api/v1/orders/:orderId',
                resendInvitation: 'POST /api/v1/orders/:orderId/invitations/:invitationId/resend'
            },
            invitations: {
                accept: 'POST /api/v1/invitations/accept',
                get: 'GET /api/v1/invitations/:token'
            },
            dispatch: {
                detectLane: 'POST /api/v1/dispatch/detect-lane/:orderId',
                generateChain: 'POST /api/v1/dispatch/generate-chain/:orderId',
                start: 'POST /api/v1/dispatch/start/:chainId',
                respond: 'POST /api/v1/dispatch/respond/:chainId',
                timeout: 'POST /api/v1/dispatch/timeout/:chainId/:attemptId',
                status: 'GET /api/v1/dispatch/status/:orderId',
                events: 'GET /api/v1/dispatch/events/:orderId',
                auto: 'POST /api/v1/dispatch/auto/:orderId'
            },
            lanes: {
                list: 'GET /api/v1/lanes',
                get: 'GET /api/v1/lanes/:laneId',
                create: 'POST /api/v1/lanes',
                update: 'PUT /api/v1/lanes/:laneId',
                delete: 'DELETE /api/v1/lanes/:laneId',
                addCarrier: 'POST /api/v1/lanes/:laneId/carriers',
                removeCarrier: 'DELETE /api/v1/lanes/:laneId/carriers/:carrierId',
                reorderCarriers: 'PUT /api/v1/lanes/:laneId/carriers/reorder'
            },
            scoring: {
                calculate: 'POST /api/v1/scoring/calculate',
                carrierGlobal: 'GET /api/v1/scoring/carrier/:carrierId',
                carrierHistory: 'GET /api/v1/scoring/carrier/:carrierId/history',
                topCarriers: 'GET /api/v1/scoring/top',
                stats: 'GET /api/v1/scoring/stats',
                orderScore: 'GET /api/v1/scoring/order/:orderId',
                recalculate: 'POST /api/v1/scoring/recalculate/:carrierId'
            },
            archive: {
                create: 'POST /api/v1/archive/:orderId',
                get: 'GET /api/v1/archive/:archiveId',
                list: 'GET /api/v1/archive',
                search: 'GET /api/v1/archive/search',
                verify: 'POST /api/v1/archive/:archiveId/verify',
                export: 'GET /api/v1/archive/:archiveId/export',
                stats: 'GET /api/v1/archive/stats',
                cleanup: 'POST /api/v1/archive/cleanup'
            }
        }
    });
});
app.use('/api/v1/orders', orders_1.default);
app.use('/api/v1/invitations', invitations_1.default);
app.use('/api/v1/dispatch', dispatch_1.default);
app.use('/api/v1/lanes', lanes_1.default);
app.use('/api/v1/scoring', scoring_1.default);
app.use('/api/v1/archive', archive_1.default);
// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', message: 'RT Orders API is running' });
});
// Connect to MongoDB and start server
mongoose_1.default.connect(MONGODB_URI)
    .then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
    });
})
    .catch((error) => {
    console.error('MongoDB connection error:', error);
    process.exit(1);
});
//# sourceMappingURL=index.js.map