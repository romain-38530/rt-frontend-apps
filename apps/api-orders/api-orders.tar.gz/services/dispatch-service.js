"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * DispatchService - Service de gestion du dispatch automatique SYMPHONI.A
 * Gère le Lane Matching, la chaîne d'affectation et l'escalade vers Affret.IA
 */
const uuid_1 = require("uuid");
const Lane_1 = __importDefault(require("../models/Lane"));
const DispatchChain_1 = __importDefault(require("../models/DispatchChain"));
const Order_1 = __importDefault(require("../models/Order"));
const event_service_1 = __importDefault(require("./event-service"));
class DispatchService {
    /**
     * Détecte la ligne de transport correspondant à une commande
     * Lane Matching basé sur origine/destination et type de marchandise
     */
    static async detectLane(orderId) {
        const order = await Order_1.default.findOne({ orderId });
        if (!order)
            throw new Error('Commande non trouvée');
        // Recherche des lanes correspondantes
        const matchedLanes = await this.findMatchingLanes(order);
        if (matchedLanes.length === 0) {
            // Aucune lane trouvée - escalade directe vers Affret.IA
            await event_service_1.default.escalatedToAffretia(orderId, order.reference, 'Aucune ligne de transport configurée pour ce trajet');
            return null;
        }
        // Prendre la meilleure lane (score le plus élevé)
        const bestMatch = matchedLanes[0];
        // Enregistrer l'événement
        await event_service_1.default.laneDetected(orderId, order.reference, bestMatch.lane.laneId, bestMatch.lane.name);
        return bestMatch.lane;
    }
    /**
     * Trouve les lanes correspondantes pour une commande
     */
    static async findMatchingLanes(order) {
        const lanes = await Lane_1.default.find({ isActive: true });
        const matches = [];
        for (const lane of lanes) {
            const matchResult = this.evaluateLaneMatch(lane, order);
            if (matchResult.isMatch) {
                matches.push({
                    lane,
                    matchScore: matchResult.score,
                    matchedCriteria: matchResult.criteria
                });
            }
        }
        // Trier par score décroissant
        return matches.sort((a, b) => b.matchScore - a.matchScore);
    }
    /**
     * Évalue si une lane correspond à une commande
     */
    static evaluateLaneMatch(lane, order) {
        let score = 0;
        const criteria = [];
        // Vérifier l'origine
        const originMatch = this.checkLocationMatch(lane.origin, order.pickupAddress);
        if (originMatch.matches) {
            score += originMatch.score;
            criteria.push(`Origine: ${originMatch.matchType}`);
        }
        else if (lane.origin.city || lane.origin.postalCodePrefix) {
            // Critère d'origine défini mais non satisfait
            return { isMatch: false, score: 0, criteria: [] };
        }
        // Vérifier la destination
        const destMatch = this.checkLocationMatch(lane.destination, order.deliveryAddress);
        if (destMatch.matches) {
            score += destMatch.score;
            criteria.push(`Destination: ${destMatch.matchType}`);
        }
        else if (lane.destination.city || lane.destination.postalCodePrefix) {
            return { isMatch: false, score: 0, criteria: [] };
        }
        // Vérifier le type de marchandise
        if (lane.merchandiseTypes && lane.merchandiseTypes.length > 0) {
            const goodsType = order.goods?.type || order.goods?.nature;
            if (goodsType && lane.merchandiseTypes.includes(goodsType)) {
                score += 20;
                criteria.push(`Type marchandise: ${goodsType}`);
            }
        }
        // Vérifier les contraintes
        if (order.constraints && order.constraints.length > 0 && lane.requiredConstraints) {
            const orderConstraints = order.constraints.map((c) => c.type);
            const matchedConstraints = orderConstraints.filter((c) => lane.requiredConstraints.includes(c));
            if (matchedConstraints.length > 0) {
                score += matchedConstraints.length * 5;
                criteria.push(`Contraintes: ${matchedConstraints.join(', ')}`);
            }
        }
        return {
            isMatch: score > 0,
            score,
            criteria
        };
    }
    /**
     * Vérifie la correspondance d'un critère de localisation
     */
    static checkLocationMatch(laneLoc, address) {
        if (!address)
            return { matches: false, score: 0, matchType: '' };
        // Code postal prefix (plus précis = plus de points)
        if (laneLoc.postalCodePrefix && address.postalCode) {
            if (address.postalCode.startsWith(laneLoc.postalCodePrefix)) {
                return { matches: true, score: 50, matchType: 'Code postal' };
            }
        }
        // Ville
        if (laneLoc.city && address.city) {
            const normalizedCity = address.city.toLowerCase().trim();
            if (laneLoc.city.toLowerCase().trim() === normalizedCity) {
                return { matches: true, score: 40, matchType: 'Ville' };
            }
        }
        // Région
        if (laneLoc.region && address.region) {
            if (laneLoc.region === address.region) {
                return { matches: true, score: 20, matchType: 'Région' };
            }
        }
        // Pays
        if (laneLoc.country) {
            const country = address.country || 'France';
            if (laneLoc.country === country) {
                return { matches: true, score: 10, matchType: 'Pays' };
            }
        }
        return { matches: false, score: 0, matchType: '' };
    }
    /**
     * Génère la chaîne d'affectation à partir d'une lane
     */
    static async generateDispatchChain(orderId, lane) {
        const order = await Order_1.default.findOne({ orderId });
        if (!order)
            throw new Error('Commande non trouvée');
        const chainId = `chain_${(0, uuid_1.v4)()}`;
        // Créer les tentatives à partir des transporteurs de la lane
        const attempts = lane.carriers
            .filter((c) => c.isActive)
            .sort((a, b) => a.position - b.position)
            .map((carrier) => ({
            carrierId: carrier.carrierId,
            carrierName: carrier.carrierName,
            position: carrier.position,
            status: 'pending',
            responseDelayMinutes: carrier.responseDelayMinutes || lane.dispatchConfig.defaultResponseDelayMinutes,
            notificationChannels: lane.dispatchConfig.notificationChannels,
            notificationsSent: []
        }));
        const chain = new DispatchChain_1.default({
            chainId,
            orderId,
            orderReference: order.reference,
            industrialId: order.industrialId,
            laneId: lane.laneId,
            laneName: lane.name,
            attempts,
            currentAttemptIndex: 0,
            maxAttempts: lane.dispatchConfig.maxAttempts,
            status: 'pending',
            config: {
                autoEscalate: lane.dispatchConfig.escalateToAffretia,
                notifyIndustrial: true,
                requirePriceConfirmation: false
            }
        });
        await chain.save();
        // Enregistrer l'événement
        await event_service_1.default.dispatchChainGenerated(orderId, order.reference, chainId, attempts.length);
        return chain;
    }
    /**
     * Démarre le processus de dispatch - envoie au premier transporteur
     */
    static async startDispatch(chainId) {
        const chain = await DispatchChain_1.default.findOne({ chainId });
        if (!chain)
            throw new Error('Chaîne de dispatch non trouvée');
        if (chain.status !== 'pending') {
            throw new Error(`Dispatch déjà démarré (status: ${chain.status})`);
        }
        chain.status = 'in_progress';
        chain.startedAt = new Date();
        await chain.save();
        return this.sendToNextCarrier(chain);
    }
    /**
     * Envoie la commande au prochain transporteur dans la chaîne
     */
    static async sendToNextCarrier(chain) {
        const attempt = chain.attempts[chain.currentAttemptIndex];
        if (!attempt) {
            // Plus de transporteurs disponibles - escalade vers Affret.IA
            await this.escalateToAffretia(chain, 'Tous les transporteurs ont refusé ou n\'ont pas répondu');
            throw new Error('Aucun transporteur disponible - escalade vers Affret.IA');
        }
        // Calculer l'expiration
        const expiresAt = new Date();
        expiresAt.setMinutes(expiresAt.getMinutes() + attempt.responseDelayMinutes);
        // Mettre à jour la tentative
        attempt.status = 'sent';
        attempt.sentAt = new Date();
        attempt.expiresAt = expiresAt;
        await chain.save();
        // Enregistrer l'événement
        await event_service_1.default.orderSentToCarrier(chain.orderId, chain.orderReference, attempt.carrierId, attempt.carrierName, attempt.position, expiresAt);
        // TODO: Envoyer notification email/SMS au transporteur
        // await NotificationService.sendCarrierInvitation(attempt);
        return attempt;
    }
    /**
     * Traite l'acceptation par un transporteur
     */
    static async handleCarrierAccept(chainId, carrierId, proposedPrice) {
        const chain = await DispatchChain_1.default.findOne({ chainId });
        if (!chain)
            throw new Error('Chaîne de dispatch non trouvée');
        const attempt = chain.attempts.find((a) => a.carrierId === carrierId && a.status === 'sent');
        if (!attempt)
            throw new Error('Tentative non trouvée ou déjà traitée');
        // Mettre à jour la tentative
        attempt.status = 'accepted';
        attempt.respondedAt = new Date();
        if (proposedPrice) {
            attempt.proposedPrice = proposedPrice;
        }
        // Mettre à jour la chaîne
        chain.status = 'completed';
        chain.completedAt = new Date();
        chain.assignedCarrierId = carrierId;
        chain.assignedCarrierName = attempt.carrierName;
        chain.assignedAt = new Date();
        await chain.save();
        // Enregistrer l'événement
        await event_service_1.default.carrierAccepted(chain.orderId, chain.orderReference, carrierId, attempt.carrierName, proposedPrice);
        // Mettre à jour la commande avec le transporteur assigné
        await Order_1.default.findOneAndUpdate({ orderId: chain.orderId }, {
            $set: {
                assignedCarrier: {
                    carrierId,
                    carrierName: attempt.carrierName,
                    assignedAt: new Date(),
                    proposedPrice
                },
                status: 'carrier_assigned'
            }
        });
        return chain;
    }
    /**
     * Traite le refus par un transporteur
     */
    static async handleCarrierRefuse(chainId, carrierId, reason) {
        const chain = await DispatchChain_1.default.findOne({ chainId });
        if (!chain)
            throw new Error('Chaîne de dispatch non trouvée');
        const attempt = chain.attempts.find((a) => a.carrierId === carrierId && a.status === 'sent');
        if (!attempt)
            throw new Error('Tentative non trouvée ou déjà traitée');
        // Mettre à jour la tentative
        attempt.status = 'refused';
        attempt.respondedAt = new Date();
        if (reason) {
            attempt.refusalReason = reason;
        }
        // Passer au transporteur suivant
        chain.currentAttemptIndex = chain.currentAttemptIndex + 1;
        await chain.save();
        // Enregistrer l'événement
        await event_service_1.default.carrierRefused(chain.orderId, chain.orderReference, carrierId, attempt.carrierName, reason);
        // Essayer le transporteur suivant
        try {
            await this.sendToNextCarrier(chain);
        }
        catch (error) {
            // Plus de transporteurs - déjà escaladé
        }
        return chain;
    }
    /**
     * Traite le timeout d'un transporteur
     */
    static async handleCarrierTimeout(chainId, attemptIndex) {
        const chain = await DispatchChain_1.default.findOne({ chainId });
        if (!chain)
            throw new Error('Chaîne de dispatch non trouvée');
        const attempt = chain.attempts[attemptIndex];
        if (!attempt || attempt.status !== 'sent') {
            throw new Error('Tentative non trouvée ou déjà traitée');
        }
        // Vérifier si vraiment en timeout
        if (attempt.expiresAt && new Date() < attempt.expiresAt) {
            throw new Error('Délai non encore expiré');
        }
        // Mettre à jour la tentative
        attempt.status = 'timeout';
        attempt.respondedAt = new Date();
        // Passer au transporteur suivant
        chain.currentAttemptIndex = chain.currentAttemptIndex + 1;
        await chain.save();
        // Enregistrer l'événement
        await event_service_1.default.carrierTimeout(chain.orderId, chain.orderReference, attempt.carrierId, attempt.carrierName);
        // Essayer le transporteur suivant
        try {
            await this.sendToNextCarrier(chain);
        }
        catch (error) {
            // Plus de transporteurs - déjà escaladé
        }
        return chain;
    }
    /**
     * Escalade vers Affret.IA
     */
    static async escalateToAffretia(chain, reason) {
        chain.status = 'escalated';
        chain.escalation = {
            escalatedAt: new Date(),
            status: 'pending'
        };
        await chain.save();
        // Enregistrer l'événement
        await event_service_1.default.escalatedToAffretia(chain.orderId, chain.orderReference, reason);
        // TODO: Notifier Affret.IA via API ou message queue
    }
    /**
     * Récupère le statut de dispatch d'une commande
     */
    static async getDispatchStatus(orderId) {
        return DispatchChain_1.default.findOne({ orderId }).sort({ createdAt: -1 });
    }
    /**
     * Récupère toutes les lanes actives
     */
    static async getActiveLanes() {
        return Lane_1.default.find({ isActive: true }).sort({ name: 1 });
    }
    /**
     * Crée une nouvelle lane
     */
    static async createLane(laneData) {
        const lane = new Lane_1.default({
            laneId: `lane_${(0, uuid_1.v4)()}`,
            ...laneData
        });
        return lane.save();
    }
    /**
     * Met à jour une lane
     */
    static async updateLane(laneId, updates) {
        return Lane_1.default.findOneAndUpdate({ laneId }, { $set: updates }, { new: true });
    }
}
exports.default = DispatchService;
//# sourceMappingURL=dispatch-service.js.map