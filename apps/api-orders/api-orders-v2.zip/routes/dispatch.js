"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Routes Dispatch - Gestion de la chaîne d'affectation SYMPHONI.A
 */
const express_1 = require("express");
const dispatch_service_1 = __importDefault(require("../services/dispatch-service"));
const event_service_1 = __importDefault(require("../services/event-service"));
const router = (0, express_1.Router)();
/**
 * POST /api/v1/dispatch/detect-lane/:orderId
 * Détecte la lane correspondant à une commande
 */
router.post('/detect-lane/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        const lane = await dispatch_service_1.default.detectLane(orderId);
        if (!lane) {
            return res.status(200).json({
                success: true,
                message: 'Aucune lane trouvée - commande escaladée vers Affret.IA',
                lane: null,
                escalated: true
            });
        }
        res.json({
            success: true,
            lane: {
                laneId: lane.laneId,
                name: lane.name,
                carriersCount: lane.carriers.length
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /api/v1/dispatch/generate-chain/:orderId
 * Génère la chaîne de dispatch à partir de la lane détectée
 */
router.post('/generate-chain/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        const { laneId } = req.body;
        // Si laneId fourni, utiliser cette lane, sinon détecter automatiquement
        let lane;
        if (laneId) {
            const lanes = await dispatch_service_1.default.getActiveLanes();
            lane = lanes.find(l => l.laneId === laneId);
            if (!lane) {
                return res.status(404).json({ success: false, error: 'Lane non trouvée' });
            }
        }
        else {
            lane = await dispatch_service_1.default.detectLane(orderId);
            if (!lane) {
                return res.status(200).json({
                    success: false,
                    error: 'Aucune lane disponible',
                    escalated: true
                });
            }
        }
        const chain = await dispatch_service_1.default.generateDispatchChain(orderId, lane);
        res.json({
            success: true,
            chain: {
                chainId: chain.chainId,
                laneId: chain.laneId,
                laneName: chain.laneName,
                status: chain.status,
                attempts: chain.attempts.map(a => ({
                    position: a.position,
                    carrierName: a.carrierName,
                    status: a.status
                })),
                config: chain.config
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /api/v1/dispatch/start/:chainId
 * Démarre le dispatch (envoie au premier transporteur)
 */
router.post('/start/:chainId', async (req, res) => {
    try {
        const { chainId } = req.params;
        const attempt = await dispatch_service_1.default.startDispatch(chainId);
        res.json({
            success: true,
            message: `Commande envoyée au transporteur ${attempt.carrierName}`,
            attempt: {
                position: attempt.position,
                carrierName: attempt.carrierName,
                status: attempt.status,
                sentAt: attempt.sentAt,
                expiresAt: attempt.expiresAt
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /api/v1/dispatch/respond/:chainId
 * Réponse d'un transporteur (acceptation ou refus)
 */
router.post('/respond/:chainId', async (req, res) => {
    try {
        const { chainId } = req.params;
        const { carrierId, accepted, proposedPrice, refusalReason } = req.body;
        if (!carrierId || accepted === undefined) {
            return res.status(400).json({
                success: false,
                error: 'carrierId et accepted sont requis'
            });
        }
        let chain;
        if (accepted) {
            chain = await dispatch_service_1.default.handleCarrierAccept(chainId, carrierId, proposedPrice);
            res.json({
                success: true,
                message: 'Transporteur accepté',
                chain: {
                    chainId: chain.chainId,
                    status: chain.status,
                    selectedCarrier: chain.assignedCarrierName
                }
            });
        }
        else {
            chain = await dispatch_service_1.default.handleCarrierRefuse(chainId, carrierId, refusalReason);
            res.json({
                success: true,
                message: 'Refus enregistré, passage au transporteur suivant',
                chain: {
                    chainId: chain.chainId,
                    status: chain.status,
                    currentAttemptIndex: chain.currentAttemptIndex
                }
            });
        }
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /api/v1/dispatch/timeout/:chainId/:attemptIndex
 * Traite le timeout d'une tentative
 */
router.post('/timeout/:chainId/:attemptIndex', async (req, res) => {
    try {
        const { chainId, attemptIndex } = req.params;
        const chain = await dispatch_service_1.default.handleCarrierTimeout(chainId, parseInt(attemptIndex));
        res.json({
            success: true,
            message: 'Timeout traité, passage au transporteur suivant',
            chain: {
                chainId: chain.chainId,
                status: chain.status,
                currentAttemptIndex: chain.currentAttemptIndex
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /api/v1/dispatch/status/:orderId
 * Récupère le statut de dispatch d'une commande
 */
router.get('/status/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        const chain = await dispatch_service_1.default.getDispatchStatus(orderId);
        if (!chain) {
            return res.status(404).json({
                success: false,
                error: 'Aucune chaîne de dispatch trouvée pour cette commande'
            });
        }
        res.json({
            success: true,
            dispatch: {
                chainId: chain.chainId,
                orderId: chain.orderId,
                orderReference: chain.orderReference,
                laneId: chain.laneId,
                laneName: chain.laneName,
                status: chain.status,
                currentAttemptIndex: chain.currentAttemptIndex,
                attempts: chain.attempts,
                assignedCarrier: chain.assignedCarrierName,
                escalation: chain.escalation,
                startedAt: chain.startedAt,
                completedAt: chain.completedAt
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /api/v1/dispatch/events/:orderId
 * Récupère tous les événements d'une commande
 */
router.get('/events/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        const events = await event_service_1.default.getOrderEvents(orderId);
        res.json({
            success: true,
            count: events.length,
            events
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /api/v1/dispatch/auto/:orderId
 * Dispatch automatique complet (détection lane + génération chaîne + démarrage)
 */
router.post('/auto/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        // 1. Détecter la lane
        const lane = await dispatch_service_1.default.detectLane(orderId);
        if (!lane) {
            return res.json({
                success: true,
                message: 'Aucune lane disponible - commande escaladée vers Affret.IA',
                escalated: true
            });
        }
        // 2. Générer la chaîne
        const chain = await dispatch_service_1.default.generateDispatchChain(orderId, lane);
        // 3. Démarrer le dispatch
        const attempt = await dispatch_service_1.default.startDispatch(chain.chainId);
        res.json({
            success: true,
            message: `Dispatch automatique lancé - commande envoyée à ${attempt.carrierName}`,
            result: {
                lane: {
                    laneId: lane.laneId,
                    name: lane.name
                },
                chain: {
                    chainId: chain.chainId,
                    carriersCount: chain.attempts.length
                },
                currentAttempt: {
                    position: attempt.position,
                    carrierName: attempt.carrierName,
                    expiresAt: attempt.expiresAt
                }
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=dispatch.js.map