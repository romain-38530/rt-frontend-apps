import type { IAddress } from '../models/Order';
interface CreateInvitationParams {
    orderId: string;
    orderReference: string;
    address: IAddress;
    role: 'supplier' | 'recipient';
    invitedBy: string;
}
export declare class PortalInvitationService {
    /**
     * Crée et envoie une invitation portail si l'accès est activé
     */
    static createAndSendInvitation(params: CreateInvitationParams): Promise<string | null>;
    /**
     * Envoie l'email d'invitation
     */
    private static sendInvitationEmail;
    /**
     * Accepte une invitation et lie l'utilisateur
     */
    static acceptInvitation(token: string, userId: string): Promise<any>;
    /**
     * Récupère les invitations d'une commande
     */
    static getOrderInvitations(orderId: string): Promise<any[]>;
    /**
     * Renvoie une invitation expirée
     */
    static resendInvitation(invitationId: string): Promise<void>;
}
export default PortalInvitationService;
//# sourceMappingURL=portal-invitation-service.d.ts.map