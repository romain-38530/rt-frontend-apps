declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=carrier-portal.d.ts.map