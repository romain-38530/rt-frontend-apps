/**
 * API Admin Gateway - SYMPHONI.A
 * Administration centralisee de la plateforme
 */
declare const app: import("express-serve-static-core").Express;
export default app;
//# sourceMappingURL=index.d.ts.map