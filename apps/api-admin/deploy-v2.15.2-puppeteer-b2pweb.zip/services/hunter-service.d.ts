/**
 * Hunter.io API Service
 * Recherche et validation d'emails
 */
interface HunterEmail {
    value: string;
    type: 'personal' | 'generic';
    confidence: number;
    first_name?: string;
    last_name?: string;
    position?: string;
    seniority?: string;
    department?: string;
    linkedin?: string;
    phone_number?: string;
    verification?: {
        date: string;
        status: string;
    };
}
interface HunterDomainSearchResult {
    domain: string;
    disposable: boolean;
    webmail: boolean;
    accept_all: boolean;
    pattern?: string;
    organization?: string;
    emails: HunterEmail[];
}
interface HunterVerifyResult {
    status: 'valid' | 'invalid' | 'accept_all' | 'webmail' | 'disposable' | 'unknown';
    result: string;
    score: number;
    email: string;
    regexp: boolean;
    gibberish: boolean;
    disposable: boolean;
    webmail: boolean;
    mx_records: boolean;
    smtp_server: boolean;
    smtp_check: boolean;
    accept_all: boolean;
    block: boolean;
}
interface HunterEmailFinderResult {
    email: string;
    score: number;
    domain: string;
    accept_all: boolean;
    position?: string;
    company?: string;
    first_name: string;
    last_name: string;
    verification?: {
        date: string;
        status: string;
    };
}
declare class HunterService {
    private makeRequest;
    /**
     * Rechercher tous les emails d'un domaine
     */
    domainSearch(domain: string, options?: {
        department?: string;
        seniority?: string;
        limit?: number;
    }): Promise<HunterDomainSearchResult | null>;
    /**
     * Vérifier la validité d'un email
     */
    verifyEmail(email: string): Promise<HunterVerifyResult | null>;
    /**
     * Trouver l'email d'une personne à partir de son nom et domaine
     */
    findEmail(params: {
        domain: string;
        firstName: string;
        lastName: string;
        company?: string;
    }): Promise<HunterEmailFinderResult | null>;
    /**
     * Mapper le statut Hunter vers notre format
     */
    mapEmailStatus(hunterStatus: string): 'VALID' | 'INVALID' | 'UNKNOWN' | 'CATCH_ALL' | 'DISPOSABLE';
    /**
     * Rechercher des contacts supply chain pour un domaine
     */
    searchSupplyChainContacts(domain: string): Promise<HunterEmail[]>;
    /**
     * Vérifier plusieurs emails en batch
     */
    verifyEmailsBatch(emails: string[]): Promise<Map<string, HunterVerifyResult>>;
}
declare const _default: HunterService;
export default _default;
export { HunterEmail, HunterVerifyResult, HunterEmailFinderResult };
//# sourceMappingURL=hunter-service.d.ts.map