"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transportScrapingService = exports.TransportScrapingService = void 0;
/**
 * Transport Scraping Service
 * Service de scraping continu pour les entreprises de transport (B2PWeb, annuaires, etc.)
 * Enregistre les annonces et les routes associées
 * Utilise Puppeteer pour l'authentification et le scraping (B2PWeb = SPA JavaScript)
 */
const axios_1 = __importDefault(require("axios"));
const puppeteer_1 = __importDefault(require("puppeteer"));
const TransportCompany_1 = __importDefault(require("../models/TransportCompany"));
const TransportOffer_1 = __importDefault(require("../models/TransportOffer"));
const mongoose_1 = __importDefault(require("mongoose"));
// ============================================
// STATE
// ============================================
// Store des jobs en cours
const scrapingJobs = new Map();
// Intervals pour le scraping continu
const continuousIntervals = new Map();
// Configuration globale
let scrapingConfig = {
    b2pwebEnabled: false,
    intervalMinutes: 30,
    maxOffersPerRun: 500
};
// ============================================
// SERVICE
// ============================================
// Helper function for delays (waitForTimeout is deprecated in newer Puppeteer)
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
class TransportScrapingService {
    constructor() {
        this.b2pwebClient = null;
        this.b2pwebToken = null;
        this.b2pwebCookies = null;
        this.isAuthenticated = false;
        // Puppeteer browser instance
        this.browser = null;
        this.page = null;
    }
    // ============================================
    // CONFIGURATION
    // ============================================
    getConfig() {
        return { ...scrapingConfig };
    }
    updateConfig(config) {
        scrapingConfig = { ...scrapingConfig, ...config };
        return scrapingConfig;
    }
    // ============================================
    // AUTHENTIFICATION B2PWEB (Puppeteer)
    // ============================================
    async authenticateB2PWeb(username, password) {
        try {
            console.log('[B2PWeb] Starting Puppeteer authentication...');
            // Close existing browser if any
            if (this.browser) {
                await this.browser.close();
                this.browser = null;
                this.page = null;
            }
            // Launch Puppeteer browser
            this.browser = await puppeteer_1.default.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--no-first-run',
                    '--no-zygote',
                    '--disable-gpu'
                ]
            });
            this.page = await this.browser.newPage();
            // Set viewport and user agent
            await this.page.setViewport({ width: 1920, height: 1080 });
            await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
            console.log('[B2PWeb] Navigating to login page...');
            // Navigate to B2PWeb login page
            await this.page.goto('https://app.b2pweb.com', {
                waitUntil: 'networkidle2',
                timeout: 60000
            });
            // Wait for page to load
            await delay(3000);
            // Take screenshot for debugging
            console.log('[B2PWeb] Page loaded, searching for login form...');
            // Try different selectors for login form
            const loginSelectors = [
                'input[name="username"]',
                'input[name="email"]',
                'input[name="login"]',
                'input[type="email"]',
                'input[id="username"]',
                'input[id="email"]',
                '#username',
                '#email',
                'input[placeholder*="email" i]',
                'input[placeholder*="identifiant" i]',
                'input[placeholder*="login" i]'
            ];
            const passwordSelectors = [
                'input[name="password"]',
                'input[type="password"]',
                'input[id="password"]',
                '#password'
            ];
            let usernameInput = null;
            let passwordInput = null;
            // Find username field
            for (const selector of loginSelectors) {
                try {
                    usernameInput = await this.page.$(selector);
                    if (usernameInput) {
                        console.log(`[B2PWeb] Found username field with selector: ${selector}`);
                        break;
                    }
                }
                catch (e) { /* continue */ }
            }
            // Find password field
            for (const selector of passwordSelectors) {
                try {
                    passwordInput = await this.page.$(selector);
                    if (passwordInput) {
                        console.log(`[B2PWeb] Found password field with selector: ${selector}`);
                        break;
                    }
                }
                catch (e) { /* continue */ }
            }
            if (!usernameInput || !passwordInput) {
                // Maybe we need to click a login button first
                const loginButtonSelectors = [
                    'button:has-text("Connexion")',
                    'a:has-text("Connexion")',
                    'button:has-text("Se connecter")',
                    'a:has-text("Se connecter")',
                    '[href*="login"]',
                    '.login-button',
                    '#login-btn'
                ];
                for (const selector of loginButtonSelectors) {
                    try {
                        const btn = await this.page.$(selector);
                        if (btn) {
                            await btn.click();
                            await delay(2000);
                            break;
                        }
                    }
                    catch (e) { /* continue */ }
                }
                // Try again to find inputs
                for (const selector of loginSelectors) {
                    try {
                        usernameInput = await this.page.$(selector);
                        if (usernameInput)
                            break;
                    }
                    catch (e) { /* continue */ }
                }
                for (const selector of passwordSelectors) {
                    try {
                        passwordInput = await this.page.$(selector);
                        if (passwordInput)
                            break;
                    }
                    catch (e) { /* continue */ }
                }
            }
            if (!usernameInput || !passwordInput) {
                // Log page content for debugging
                const pageContent = await this.page.content();
                console.log('[B2PWeb] Page HTML snippet:', pageContent.substring(0, 2000));
                return {
                    success: false,
                    error: 'Impossible de trouver le formulaire de connexion B2PWeb. Vérifiez que le site est accessible.'
                };
            }
            console.log('[B2PWeb] Filling login credentials...');
            // Clear and fill username
            await usernameInput.click({ clickCount: 3 });
            await usernameInput.type(username, { delay: 50 });
            // Clear and fill password
            await passwordInput.click({ clickCount: 3 });
            await passwordInput.type(password, { delay: 50 });
            // Find and click submit button
            const submitSelectors = [
                'button[type="submit"]',
                'input[type="submit"]',
                'button:has-text("Connexion")',
                'button:has-text("Se connecter")',
                'button:has-text("Login")',
                '.login-submit',
                '#login-submit',
                'form button'
            ];
            let submitted = false;
            for (const selector of submitSelectors) {
                try {
                    const submitBtn = await this.page.$(selector);
                    if (submitBtn) {
                        console.log(`[B2PWeb] Clicking submit button with selector: ${selector}`);
                        await submitBtn.click();
                        submitted = true;
                        break;
                    }
                }
                catch (e) { /* continue */ }
            }
            if (!submitted) {
                // Try pressing Enter
                await this.page.keyboard.press('Enter');
            }
            console.log('[B2PWeb] Waiting for authentication...');
            // Wait for navigation or content change
            await delay(5000);
            // Check if we're authenticated by looking for dashboard elements or URL change
            const currentUrl = this.page.url();
            console.log(`[B2PWeb] Current URL after login: ${currentUrl}`);
            // Get cookies
            const cookies = await this.page.cookies();
            this.b2pwebCookies = cookies.map(c => `${c.name}=${c.value}`).join('; ');
            // Check if authentication succeeded by looking for error messages or dashboard elements
            const errorSelectors = [
                '.error-message',
                '.alert-danger',
                '.login-error',
                '[class*="error"]',
                'text/Erreur',
                'text/incorrect',
                'text/invalide'
            ];
            let hasError = false;
            for (const selector of errorSelectors) {
                try {
                    const errorEl = await this.page.$(selector);
                    if (errorEl) {
                        const errorText = await errorEl.evaluate(el => el.textContent);
                        if (errorText && (errorText.toLowerCase().includes('erreur') || errorText.toLowerCase().includes('incorrect') || errorText.toLowerCase().includes('invalid'))) {
                            hasError = true;
                            return { success: false, error: `Erreur de connexion B2PWeb: ${errorText}` };
                        }
                    }
                }
                catch (e) { /* continue */ }
            }
            // Check for successful login indicators
            const successIndicators = [
                currentUrl.includes('/offer'),
                currentUrl.includes('/dashboard'),
                currentUrl.includes('/home'),
                !currentUrl.includes('login'),
                cookies.length > 2
            ];
            if (successIndicators.some(Boolean) && !hasError) {
                console.log('[B2PWeb] Authentication successful!');
                this.isAuthenticated = true;
                scrapingConfig.b2pwebEnabled = true;
                scrapingConfig.b2pwebCredentials = { username, password };
                // Create axios client with cookies for API calls
                this.b2pwebClient = axios_1.default.create({
                    baseURL: 'https://app.b2pweb.com',
                    headers: {
                        'Cookie': this.b2pwebCookies || '',
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });
                return { success: true };
            }
            return {
                success: false,
                error: 'Authentification B2PWeb échouée. Vérifiez vos identifiants.'
            };
        }
        catch (error) {
            console.error('[B2PWeb] Authentication error:', error.message);
            // Cleanup on error
            if (this.browser) {
                await this.browser.close();
                this.browser = null;
                this.page = null;
            }
            return { success: false, error: `Erreur Puppeteer: ${error.message}` };
        }
    }
    // Cleanup browser on service shutdown
    async closeBrowser() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
            this.page = null;
            this.isAuthenticated = false;
        }
    }
    isB2PWebAuthenticated() {
        return this.isAuthenticated;
    }
    // ============================================
    // GESTION DES JOBS
    // ============================================
    createScrapingJob(source, type, filters) {
        const job = {
            id: new mongoose_1.default.Types.ObjectId().toString(),
            source,
            type,
            status: 'pending',
            totalFound: 0,
            totalImported: 0,
            totalUpdated: 0,
            totalDuplicates: 0,
            errors: [],
            filters,
            isActive: true
        };
        scrapingJobs.set(job.id, job);
        return job;
    }
    getJobStatus(jobId) {
        return scrapingJobs.get(jobId);
    }
    getAllJobs() {
        return Array.from(scrapingJobs.values()).sort((a, b) => (b.startedAt?.getTime() || 0) - (a.startedAt?.getTime() || 0));
    }
    stopJob(jobId) {
        const job = scrapingJobs.get(jobId);
        if (job) {
            job.status = 'stopped';
            job.isActive = false;
            const interval = continuousIntervals.get(jobId);
            if (interval) {
                clearInterval(interval);
                continuousIntervals.delete(jobId);
            }
            return true;
        }
        return false;
    }
    // ============================================
    // SCRAPING CONTINU DES OFFRES B2PWEB
    // ============================================
    async startContinuousScraping(intervalMinutes) {
        const interval = intervalMinutes || scrapingConfig.intervalMinutes;
        const job = this.createScrapingJob('b2pweb', 'continuous', { intervalMinutes: interval });
        job.interval = interval;
        job.status = 'running';
        job.startedAt = new Date();
        // Lancer immédiatement
        this.runOffersScraping(job.id);
        // Programmer les exécutions suivantes
        const intervalId = setInterval(() => {
            if (job.isActive) {
                this.runOffersScraping(job.id);
            }
        }, interval * 60 * 1000);
        continuousIntervals.set(job.id, intervalId);
        return job;
    }
    async runOffersScraping(jobId) {
        const job = scrapingJobs.get(jobId);
        if (!job || !job.isActive)
            return;
        job.lastRunAt = new Date();
        job.nextRunAt = new Date(Date.now() + (job.interval || 30) * 60 * 1000);
        try {
            // Re-authenticate if needed
            if (!this.isAuthenticated && scrapingConfig.b2pwebCredentials) {
                await this.authenticateB2PWeb(scrapingConfig.b2pwebCredentials.username, scrapingConfig.b2pwebCredentials.password);
            }
            if (!this.isAuthenticated || !this.page) {
                job.errors.push('Non authentifié sur B2PWeb');
                return;
            }
            console.log('[B2PWeb] Starting offers scraping...');
            let rawOffers = [];
            // Try API endpoints first (with cookies from Puppeteer session)
            if (this.b2pwebClient) {
                const offerEndpoints = [
                    '/api/offers',
                    '/api/v1/offers',
                    '/api/transport/offers',
                    '/api/fret/offers',
                    '/api/annonces',
                    '/api/v1/annonces',
                    '/api/freight/offers',
                    '/api/loads'
                ];
                for (const endpoint of offerEndpoints) {
                    try {
                        let page = 1;
                        let hasMore = true;
                        while (hasMore && rawOffers.length < scrapingConfig.maxOffersPerRun) {
                            const response = await this.b2pwebClient.get(endpoint, {
                                params: {
                                    page,
                                    limit: 100,
                                    per_page: 100,
                                    pageSize: 100,
                                    status: 'active'
                                }
                            });
                            const data = response.data?.data || response.data?.offers || response.data?.results || response.data?.items || response.data;
                            if (Array.isArray(data) && data.length > 0) {
                                rawOffers = [...rawOffers, ...data];
                                hasMore = data.length >= 100;
                                page++;
                            }
                            else {
                                hasMore = false;
                            }
                            await new Promise(resolve => setTimeout(resolve, 500));
                        }
                        if (rawOffers.length > 0)
                            break;
                    }
                    catch (e) {
                        // Continue to next endpoint
                    }
                }
            }
            // If API didn't work, use Puppeteer to scrape the page directly
            if (rawOffers.length === 0 && this.page) {
                console.log('[B2PWeb] API endpoints failed, using Puppeteer page scraping...');
                rawOffers = await this.scrapeOffersWithPuppeteer();
            }
            job.totalFound += rawOffers.length;
            console.log(`[B2PWeb] Found ${rawOffers.length} offers`);
            // Process offers
            for (const rawOffer of rawOffers) {
                try {
                    await this.processOffer(rawOffer, job);
                }
                catch (error) {
                    job.errors.push(`Erreur traitement offre: ${error.message}`);
                }
            }
        }
        catch (error) {
            console.error('[B2PWeb] Scraping error:', error.message);
            job.errors.push(`Erreur run scraping: ${error.message}`);
        }
    }
    // Scrape offers directly from B2PWeb page using Puppeteer
    async scrapeOffersWithPuppeteer() {
        if (!this.page)
            return [];
        try {
            // Navigate to offers page
            console.log('[B2PWeb] Navigating to offers page...');
            await this.page.goto('https://app.b2pweb.com/offer', {
                waitUntil: 'networkidle2',
                timeout: 60000
            });
            await delay(3000);
            const offers = [];
            let pageNum = 1;
            const maxPages = 10; // Limit to avoid infinite loops
            while (pageNum <= maxPages && offers.length < scrapingConfig.maxOffersPerRun) {
                console.log(`[B2PWeb] Scraping page ${pageNum}...`);
                // Wait for offer cards to load
                await delay(2000);
                // Extract offers from the page
                const pageOffers = await this.page.evaluate(() => {
                    const offerElements = document.querySelectorAll('[class*="offer"], [class*="Offer"], [class*="annonce"], [class*="card"], .list-item, tr[data-id], [data-offer-id]');
                    const extracted = [];
                    offerElements.forEach((el, index) => {
                        try {
                            // Try to extract data from various possible structures
                            const getText = (selectors) => {
                                for (const sel of selectors) {
                                    const elem = el.querySelector(sel);
                                    if (elem?.textContent)
                                        return elem.textContent.trim();
                                }
                                return '';
                            };
                            // Extract origin/destination from various formats
                            const routeText = getText(['.route', '.trajet', '[class*="route"]', '[class*="location"]', '.origin-dest', '.from-to']);
                            const originText = getText(['.origin', '.departure', '.from', '.chargement', '[class*="origin"]', '[class*="departure"]']);
                            const destText = getText(['.destination', '.arrival', '.to', '.livraison', '[class*="destination"]', '[class*="arrival"]']);
                            const companyText = getText(['.company', '.carrier', '.transporteur', '.advertiser', '[class*="company"]', '[class*="carrier"]']);
                            const priceText = getText(['.price', '.tarif', '.cost', '[class*="price"]', '[class*="tarif"]']);
                            const dateText = getText(['.date', '.loading-date', '.dateChargement', '[class*="date"]']);
                            const vehicleText = getText(['.vehicle', '.truck', '.equipment', '[class*="vehicle"]', '[class*="truck"]']);
                            const cargoText = getText(['.cargo', '.load', '.freight', '.merchandise', '[class*="cargo"]', '[class*="load"]']);
                            // Try to get ID from element
                            const id = el.getAttribute('data-id') || el.getAttribute('data-offer-id') || el.id || `scraped-${index}-${Date.now()}`;
                            // Parse route if combined
                            let origin = originText;
                            let destination = destText;
                            if (!origin && !destination && routeText) {
                                const routeParts = routeText.split(/\s*[-→>]\s*/);
                                if (routeParts.length >= 2) {
                                    origin = routeParts[0];
                                    destination = routeParts[routeParts.length - 1];
                                }
                            }
                            if (origin || destination || companyText) {
                                extracted.push({
                                    id,
                                    origin: { city: origin },
                                    destination: { city: destination },
                                    company: { name: companyText },
                                    price: priceText,
                                    loadingDate: dateText,
                                    vehicle: { type: vehicleText },
                                    cargo: { description: cargoText },
                                    rawHtml: el.innerHTML?.substring(0, 500)
                                });
                            }
                        }
                        catch (e) {
                            // Skip this element
                        }
                    });
                    return extracted;
                });
                offers.push(...pageOffers);
                console.log(`[B2PWeb] Found ${pageOffers.length} offers on page ${pageNum}`);
                // Try to go to next page
                const nextButton = await this.page.$('button.next, a.next, [aria-label="Next"], .pagination-next, button:has-text("Suivant"), a:has-text("Suivant")');
                if (nextButton && pageOffers.length > 0) {
                    await nextButton.click();
                    await delay(2000);
                    pageNum++;
                }
                else {
                    break;
                }
            }
            return offers;
        }
        catch (error) {
            console.error('[B2PWeb] Puppeteer scraping error:', error.message);
            return [];
        }
    }
    async processOffer(rawOffer, job) {
        // Extraire l'ID externe
        const externalId = rawOffer.id?.toString() || rawOffer._id?.toString() || rawOffer.reference || `${Date.now()}-${Math.random()}`;
        // Vérifier si l'offre existe déjà
        const existingOffer = await TransportOffer_1.default.findOne({
            externalId,
            'source.name': 'b2pweb'
        });
        if (existingOffer) {
            // Mettre à jour la date de dernière vue
            existingOffer.source.lastSeenAt = new Date();
            await existingOffer.save();
            job.totalUpdated++;
            return;
        }
        // Parser les données de l'offre
        const offerData = this.parseB2PWebOffer(rawOffer);
        // Créer l'offre
        const offer = new TransportOffer_1.default({
            externalId,
            source: {
                name: 'b2pweb',
                url: rawOffer.url || `https://app.b2pweb.com/offer/${externalId}`,
                scrapedAt: new Date(),
                lastSeenAt: new Date()
            },
            ...offerData
        });
        await offer.save();
        job.totalImported++;
        // Créer ou mettre à jour l'entreprise de transport
        await this.upsertTransportCompany(offerData, offer._id);
    }
    parseB2PWebOffer(raw) {
        // Parser les différents formats possibles de B2PWeb
        const origin = raw.origin || raw.departure || raw.loading || raw.from || {};
        const destination = raw.destination || raw.arrival || raw.delivery || raw.to || {};
        const company = raw.company || raw.carrier || raw.transporteur || raw.advertiser || {};
        const contact = raw.contact || company.contact || {};
        const cargo = raw.cargo || raw.freight || raw.load || raw.merchandise || {};
        const vehicle = raw.vehicle || raw.truck || raw.equipment || {};
        const price = raw.price || raw.tarif || raw.cost || {};
        return {
            offerType: raw.type === 'demand' || raw.type === 'freight' ? 'demand' : 'offer',
            company: {
                name: company.name || company.companyName || company.raison_sociale || raw.companyName || 'Inconnu',
                externalId: company.id?.toString() || company._id?.toString()
            },
            contact: {
                name: contact.name || contact.fullName || `${contact.firstName || ''} ${contact.lastName || ''}`.trim() || undefined,
                email: contact.email || contact.mail,
                phone: contact.phone || contact.tel || contact.telephone || contact.mobile
            },
            route: {
                origin: {
                    city: origin.city || origin.ville || origin.locality,
                    postalCode: origin.postalCode || origin.zipCode || origin.cp || origin.code_postal,
                    department: origin.department || origin.departement,
                    country: origin.country || origin.pays || 'France',
                    lat: parseFloat(origin.lat || origin.latitude) || undefined,
                    lng: parseFloat(origin.lng || origin.longitude || origin.lon) || undefined
                },
                destination: {
                    city: destination.city || destination.ville || destination.locality,
                    postalCode: destination.postalCode || destination.zipCode || destination.cp || destination.code_postal,
                    department: destination.department || destination.departement,
                    country: destination.country || destination.pays || 'France',
                    lat: parseFloat(destination.lat || destination.latitude) || undefined,
                    lng: parseFloat(destination.lng || destination.longitude || destination.lon) || undefined
                },
                distance: parseFloat(raw.distance || raw.km) || undefined
            },
            loadingDate: raw.loadingDate || raw.departureDate || raw.dateChargement ? new Date(raw.loadingDate || raw.departureDate || raw.dateChargement) : undefined,
            deliveryDate: raw.deliveryDate || raw.arrivalDate || raw.dateLivraison ? new Date(raw.deliveryDate || raw.arrivalDate || raw.dateLivraison) : undefined,
            cargo: {
                type: cargo.type || cargo.nature || cargo.category,
                weight: parseFloat(cargo.weight || cargo.poids || cargo.tonnage) || undefined,
                volume: parseFloat(cargo.volume || cargo.m3) || undefined,
                length: parseFloat(cargo.length || cargo.longueur) || undefined,
                width: parseFloat(cargo.width || cargo.largeur) || undefined,
                height: parseFloat(cargo.height || cargo.hauteur) || undefined,
                quantity: parseInt(cargo.quantity || cargo.quantite || cargo.pallets || cargo.nb_palettes) || undefined,
                description: cargo.description || cargo.details,
                adr: cargo.adr || cargo.dangerous || cargo.matiereDangereuse || false,
                temperature: cargo.temperature ? {
                    min: parseFloat(cargo.temperature.min || cargo.tempMin),
                    max: parseFloat(cargo.temperature.max || cargo.tempMax)
                } : undefined
            },
            vehicle: {
                type: vehicle.type || vehicle.vehicleType || vehicle.typeVehicule,
                capacity: parseFloat(vehicle.capacity || vehicle.tonnage) || undefined,
                features: vehicle.features || vehicle.equipements || vehicle.options || []
            },
            price: {
                amount: parseFloat(price.amount || price.value || price.montant || raw.price) || undefined,
                currency: price.currency || price.devise || 'EUR',
                type: price.negotiable ? 'negotiable' : price.amount ? 'fixed' : 'on_demand'
            },
            status: raw.status === 'expired' ? 'expired' : 'active',
            tags: ['b2pweb']
        };
    }
    async upsertTransportCompany(offerData, offerId) {
        const companyName = offerData.company?.name;
        if (!companyName || companyName === 'Inconnu')
            return;
        // Chercher l'entreprise existante
        let company = await TransportCompany_1.default.findOne({
            companyName: { $regex: new RegExp(`^${companyName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }
        });
        const originDept = offerData.route?.origin?.postalCode?.substring(0, 2);
        const destDept = offerData.route?.destination?.postalCode?.substring(0, 2);
        if (company) {
            // Mettre à jour les départements couverts
            const coveredDepts = new Set(company.transportInfo?.coveredDepartments || []);
            if (originDept)
                coveredDepts.add(originDept);
            if (destDept)
                coveredDepts.add(destDept);
            company.transportInfo = {
                ...company.transportInfo,
                coveredDepartments: Array.from(coveredDepts)
            };
            // Ajouter info contact si manquant
            if (!company.email && offerData.contact?.email) {
                company.email = offerData.contact.email;
            }
            if (!company.phone && offerData.contact?.phone) {
                company.phone = offerData.contact.phone;
            }
            company.source.lastUpdated = new Date();
            await company.save();
            // Lier l'offre à l'entreprise
            await TransportOffer_1.default.findByIdAndUpdate(offerId, {
                'company.transportCompanyId': company._id
            });
        }
        else {
            // Créer nouvelle entreprise
            company = new TransportCompany_1.default({
                companyName,
                email: offerData.contact?.email,
                phone: offerData.contact?.phone,
                address: {
                    city: offerData.route?.origin?.city,
                    postalCode: offerData.route?.origin?.postalCode,
                    departmentCode: originDept,
                    country: offerData.route?.origin?.country || 'France'
                },
                transportInfo: {
                    services: [],
                    specializations: [],
                    vehicleTypes: offerData.vehicle?.type ? [offerData.vehicle.type] : [],
                    operatingZones: ['National'],
                    coveredDepartments: [originDept, destDept].filter(Boolean),
                    coveredCountries: ['France']
                },
                mainContact: offerData.contact?.name ? {
                    firstName: offerData.contact.name.split(' ')[0],
                    lastName: offerData.contact.name.split(' ').slice(1).join(' '),
                    email: offerData.contact.email,
                    phone: offerData.contact.phone
                } : undefined,
                source: {
                    type: 'scraping',
                    name: 'b2pweb',
                    scrapedAt: new Date()
                },
                prospectionStatus: 'new',
                addedToLeadPool: false,
                tags: ['b2pweb', 'transport'],
                isActive: true
            });
            await company.save();
            // Lier l'offre à l'entreprise
            await TransportOffer_1.default.findByIdAndUpdate(offerId, {
                'company.transportCompanyId': company._id
            });
        }
    }
    // ============================================
    // STATISTIQUES DES OFFRES
    // ============================================
    async getOffersStats() {
        const [total, active, bySource, byOriginDept, byDestDept, topRoutes, lastOffer] = await Promise.all([
            TransportOffer_1.default.countDocuments(),
            TransportOffer_1.default.countDocuments({ status: 'active' }),
            TransportOffer_1.default.aggregate([
                { $group: { _id: '$source.name', count: { $sum: 1 } } }
            ]),
            TransportOffer_1.default.aggregate([
                { $match: { 'route.origin.department': { $exists: true } } },
                { $group: { _id: '$route.origin.department', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 20 }
            ]),
            TransportOffer_1.default.aggregate([
                { $match: { 'route.destination.department': { $exists: true } } },
                { $group: { _id: '$route.destination.department', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 20 }
            ]),
            TransportOffer_1.default.aggregate([
                {
                    $group: {
                        _id: {
                            origin: '$route.origin.city',
                            destination: '$route.destination.city'
                        },
                        count: { $sum: 1 }
                    }
                },
                { $sort: { count: -1 } },
                { $limit: 20 }
            ]),
            TransportOffer_1.default.findOne().sort({ 'source.scrapedAt': -1 })
        ]);
        return {
            total,
            active,
            bySource: Object.fromEntries(bySource.map(s => [s._id || 'unknown', s.count])),
            byOriginDepartment: Object.fromEntries(byOriginDept.map(s => [s._id || 'unknown', s.count])),
            byDestinationDepartment: Object.fromEntries(byDestDept.map(s => [s._id || 'unknown', s.count])),
            topRoutes: topRoutes.map(r => ({
                origin: r._id.origin || 'Inconnu',
                destination: r._id.destination || 'Inconnu',
                count: r.count
            })),
            lastScrapedAt: lastOffer?.source?.scrapedAt
        };
    }
    // ============================================
    // RECHERCHE DES OFFRES
    // ============================================
    async searchOffers(filters) {
        const query = {};
        if (filters.search) {
            query.$or = [
                { 'company.name': { $regex: filters.search, $options: 'i' } },
                { 'route.origin.city': { $regex: filters.search, $options: 'i' } },
                { 'route.destination.city': { $regex: filters.search, $options: 'i' } }
            ];
        }
        if (filters.originDepartment) {
            query['route.origin.department'] = filters.originDepartment;
        }
        if (filters.destinationDepartment) {
            query['route.destination.department'] = filters.destinationDepartment;
        }
        if (filters.originCity) {
            query['route.origin.city'] = { $regex: filters.originCity, $options: 'i' };
        }
        if (filters.destinationCity) {
            query['route.destination.city'] = { $regex: filters.destinationCity, $options: 'i' };
        }
        if (filters.vehicleType) {
            query['vehicle.type'] = { $regex: filters.vehicleType, $options: 'i' };
        }
        if (filters.dateFrom) {
            query.loadingDate = { $gte: filters.dateFrom };
        }
        if (filters.dateTo) {
            query.loadingDate = { ...query.loadingDate, $lte: filters.dateTo };
        }
        if (filters.status) {
            query.status = filters.status;
        }
        if (filters.companyId) {
            query['company.transportCompanyId'] = new mongoose_1.default.Types.ObjectId(filters.companyId);
        }
        const page = filters.page || 1;
        const limit = filters.limit || 50;
        const skip = (page - 1) * limit;
        const [offers, total] = await Promise.all([
            TransportOffer_1.default.find(query)
                .sort({ 'source.scrapedAt': -1 })
                .skip(skip)
                .limit(limit)
                .populate('company.transportCompanyId', 'companyName email phone'),
            TransportOffer_1.default.countDocuments(query)
        ]);
        return {
            offers,
            total,
            pages: Math.ceil(total / limit)
        };
    }
    // ============================================
    // ROUTES PAR ENTREPRISE
    // ============================================
    async getCompanyRoutes(companyId) {
        const routes = await TransportOffer_1.default.aggregate([
            { $match: { 'company.transportCompanyId': new mongoose_1.default.Types.ObjectId(companyId) } },
            {
                $group: {
                    _id: {
                        originCity: '$route.origin.city',
                        originDept: '$route.origin.department',
                        destCity: '$route.destination.city',
                        destDept: '$route.destination.department'
                    },
                    count: { $sum: 1 },
                    lastSeen: { $max: '$source.lastSeenAt' }
                }
            },
            { $sort: { count: -1 } }
        ]);
        const totalOffers = await TransportOffer_1.default.countDocuments({
            'company.transportCompanyId': new mongoose_1.default.Types.ObjectId(companyId)
        });
        return {
            routes: routes.map(r => ({
                origin: { city: r._id.originCity, department: r._id.originDept },
                destination: { city: r._id.destCity, department: r._id.destDept },
                count: r.count,
                lastSeen: r.lastSeen
            })),
            totalOffers
        };
    }
    // ============================================
    // LEGACY METHODS (companies)
    // ============================================
    async getStats() {
        const [total, bySource, byStatus, byDepartment, addedToLeadPool, withEmail, withPhone] = await Promise.all([
            TransportCompany_1.default.countDocuments({ isActive: true }),
            TransportCompany_1.default.aggregate([
                { $match: { isActive: true } },
                { $group: { _id: '$source.name', count: { $sum: 1 } } }
            ]),
            TransportCompany_1.default.aggregate([
                { $match: { isActive: true } },
                { $group: { _id: '$prospectionStatus', count: { $sum: 1 } } }
            ]),
            TransportCompany_1.default.aggregate([
                { $match: { isActive: true, 'address.departmentCode': { $exists: true } } },
                { $group: { _id: '$address.departmentCode', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 20 }
            ]),
            TransportCompany_1.default.countDocuments({ isActive: true, addedToLeadPool: true }),
            TransportCompany_1.default.countDocuments({ isActive: true, email: { $exists: true, $ne: null } }),
            TransportCompany_1.default.countDocuments({ isActive: true, phone: { $exists: true, $ne: null } })
        ]);
        return {
            total,
            bySource: Object.fromEntries(bySource.map(s => [s._id || 'unknown', s.count])),
            byStatus: Object.fromEntries(byStatus.map(s => [s._id || 'unknown', s.count])),
            byDepartment: Object.fromEntries(byDepartment.map(s => [s._id || 'unknown', s.count])),
            addedToLeadPool,
            withEmail,
            withPhone
        };
    }
    async searchCompanies(filters) {
        const query = { isActive: true };
        if (filters.search) {
            query.$or = [
                { companyName: { $regex: filters.search, $options: 'i' } },
                { 'address.city': { $regex: filters.search, $options: 'i' } },
                { email: { $regex: filters.search, $options: 'i' } }
            ];
        }
        if (filters.status)
            query.prospectionStatus = filters.status;
        if (filters.source)
            query['source.name'] = filters.source;
        if (filters.department)
            query['address.departmentCode'] = filters.department;
        if (filters.hasEmail !== undefined) {
            if (filters.hasEmail) {
                query.email = { $exists: true, $nin: [null, ''] };
            }
            else {
                query.$or = [{ email: { $exists: false } }, { email: null }, { email: '' }];
            }
        }
        if (filters.addedToLeadPool !== undefined) {
            query.addedToLeadPool = filters.addedToLeadPool;
        }
        const page = filters.page || 1;
        const limit = filters.limit || 50;
        const skip = (page - 1) * limit;
        const [companies, total] = await Promise.all([
            TransportCompany_1.default.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit),
            TransportCompany_1.default.countDocuments(query)
        ]);
        return { companies, total, pages: Math.ceil(total / limit) };
    }
    async addToLeadPool(companyIds) {
        let success = 0;
        let failed = 0;
        for (const id of companyIds) {
            try {
                await TransportCompany_1.default.findByIdAndUpdate(id, {
                    addedToLeadPool: true,
                    addedToLeadPoolAt: new Date(),
                    prospectionStatus: 'to_contact'
                });
                success++;
            }
            catch (e) {
                failed++;
            }
        }
        return { success, failed };
    }
    async updateProspectionStatus(companyId, status, notes) {
        return TransportCompany_1.default.findByIdAndUpdate(companyId, { prospectionStatus: status, ...(notes && { notes }) }, { new: true });
    }
    async deleteCompany(companyId) {
        const result = await TransportCompany_1.default.findByIdAndUpdate(companyId, { isActive: false }, { new: true });
        return !!result;
    }
    async exportToCSV(filters) {
        const query = { isActive: true };
        if (filters?.status)
            query.prospectionStatus = filters.status;
        if (filters?.source)
            query['source.name'] = filters.source;
        if (filters?.department)
            query['address.departmentCode'] = filters.department;
        const companies = await TransportCompany_1.default.find(query);
        const headers = ['Nom entreprise', 'Nom legal', 'SIRET', 'Email', 'Telephone', 'Ville', 'Code postal', 'Departement', 'Services', 'Types vehicules', 'Source', 'Statut', 'Score'];
        const rows = companies.map(c => [
            c.companyName || '', c.legalName || '', c.siret || '', c.email || '', c.phone || '',
            c.address?.city || '', c.address?.postalCode || '', c.address?.departmentCode || '',
            c.transportInfo?.services?.join(';') || '', c.transportInfo?.vehicleTypes?.join(';') || '',
            c.source?.name || '', c.prospectionStatus || '', c.score?.toString() || ''
        ]);
        return [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
    }
    // Import CSV
    async importFromCSV(jobId, data, sourceName) {
        const job = scrapingJobs.get(jobId);
        if (!job)
            return;
        job.status = 'running';
        job.startedAt = new Date();
        job.totalFound = data.length;
        try {
            for (const row of data) {
                try {
                    const existing = await TransportCompany_1.default.findOne({
                        $or: [
                            { companyName: { $regex: new RegExp(`^${row.companyName}$`, 'i') } },
                            ...(row.siret ? [{ siret: row.siret }] : []),
                            ...(row.email ? [{ email: row.email.toLowerCase() }] : [])
                        ]
                    });
                    if (existing) {
                        job.totalDuplicates++;
                        continue;
                    }
                    const company = new TransportCompany_1.default({
                        companyName: row.companyName,
                        siret: row.siret,
                        email: row.email?.toLowerCase(),
                        phone: row.phone,
                        address: {
                            city: row.city,
                            postalCode: row.postalCode,
                            departmentCode: row.postalCode?.substring(0, 2),
                            country: 'France'
                        },
                        transportInfo: {
                            services: row.services?.split(',').map(s => s.trim()) || [],
                            vehicleTypes: row.vehicleTypes?.split(',').map(s => s.trim()) || [],
                            specializations: [],
                            operatingZones: ['National'],
                            coveredDepartments: row.postalCode ? [row.postalCode.substring(0, 2)] : [],
                            coveredCountries: ['France']
                        },
                        source: { type: 'import', name: sourceName, scrapedAt: new Date() },
                        prospectionStatus: 'new',
                        addedToLeadPool: false,
                        tags: ['import', sourceName],
                        isActive: true
                    });
                    await company.save();
                    job.totalImported++;
                }
                catch (error) {
                    job.errors.push(`Erreur ligne ${row.companyName}: ${error.message}`);
                }
            }
            job.status = 'completed';
            job.completedAt = new Date();
        }
        catch (error) {
            job.status = 'failed';
            job.errors.push(error.message);
            job.completedAt = new Date();
        }
    }
}
exports.TransportScrapingService = TransportScrapingService;
exports.transportScrapingService = new TransportScrapingService();
//# sourceMappingURL=transport-scraping-service.js.map