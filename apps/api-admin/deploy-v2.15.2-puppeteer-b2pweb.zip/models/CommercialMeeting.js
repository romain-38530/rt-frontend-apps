"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const CommercialMeetingSchema = new mongoose_1.Schema({
    commercialId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'CrmCommercial',
        required: true
    },
    leadCompanyId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'LeadCompany'
    },
    leadContactId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'LeadContact'
    },
    prospectInfo: {
        companyName: { type: String, required: true },
        contactName: { type: String, required: true },
        email: { type: String, required: true },
        phone: String,
        position: String
    },
    title: { type: String, required: true },
    description: String,
    type: {
        type: String,
        enum: ['presentation', 'demo', 'follow_up', 'closing'],
        default: 'presentation'
    },
    status: {
        type: String,
        enum: ['scheduled', 'confirmed', 'completed', 'cancelled', 'no_show'],
        default: 'scheduled'
    },
    scheduledAt: { type: Date, required: true },
    duration: { type: Number, default: 30 },
    timezone: { type: String, default: 'Europe/Paris' },
    meetingLink: String,
    meetingProvider: {
        type: String,
        enum: ['google_meet', 'zoom', 'teams', 'phone']
    },
    notes: String,
    outcome: String,
    nextSteps: String,
    confirmationEmailSent: { type: Boolean, default: false },
    reminderEmailSent: { type: Boolean, default: false },
    bookingToken: { type: String, unique: true, sparse: true },
    bookedViaEmail: { type: mongoose_1.Schema.Types.ObjectId, ref: 'LeadEmail' },
    bookedAt: { type: Date, default: Date.now },
    cancelledAt: Date,
    cancellationReason: String
}, {
    timestamps: true
});
// Index pour les requêtes fréquentes
CommercialMeetingSchema.index({ commercialId: 1, scheduledAt: 1 });
CommercialMeetingSchema.index({ commercialId: 1, status: 1 });
CommercialMeetingSchema.index({ scheduledAt: 1 });
CommercialMeetingSchema.index({ bookingToken: 1 });
CommercialMeetingSchema.index({ leadCompanyId: 1 });
CommercialMeetingSchema.index({ 'prospectInfo.email': 1 });
exports.default = mongoose_1.default.model('CommercialMeeting', CommercialMeetingSchema);
//# sourceMappingURL=CommercialMeeting.js.map