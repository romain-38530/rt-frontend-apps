"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Contract - Contrats clients
 */
const mongoose_1 = __importStar(require("mongoose"));
const ContractSchema = new mongoose_1.Schema({
    contractNumber: { type: String, required: true, unique: true },
    companyId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Company' },
    companyName: { type: String, required: true },
    contactName: { type: String, required: true },
    contactEmail: { type: String, required: true },
    contactPhone: String,
    commercialId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'CrmCommercial' },
    commercialName: { type: String },
    type: { type: String, enum: ['pack', 'custom', 'individual_modules'], default: 'custom' },
    packCode: String,
    packName: String,
    modules: [{
            moduleCode: { type: String, required: true },
            moduleName: { type: String, required: true },
            monthlyPrice: { type: Number, required: true },
            users: Number
        }],
    pricing: {
        monthlyTotal: { type: Number, required: true },
        setupFeeTotal: { type: Number, default: 0 },
        currency: { type: String, default: 'EUR' },
        billingCycle: { type: String, enum: ['monthly', 'quarterly', 'annual'], default: 'monthly' },
        paymentMethod: { type: String, enum: ['card', 'sepa', 'transfer', 'check'], default: 'sepa' }
    },
    promotions: [{
            promoCode: String,
            promoName: String,
            discountAmount: Number,
            type: String
        }],
    startDate: { type: Date, required: true },
    endDate: Date,
    commitmentMonths: { type: Number, default: 12 },
    autoRenewal: { type: Boolean, default: true },
    renewalNoticeDate: Date,
    status: {
        type: String,
        enum: ['draft', 'pending_signature', 'active', 'suspended', 'terminated', 'expired'],
        default: 'draft'
    },
    signedAt: Date,
    signedBy: String,
    terminatedAt: Date,
    terminationReason: String,
    installation: {
        status: { type: String, enum: ['pending', 'scheduled', 'in_progress', 'completed', 'cancelled'], default: 'pending' },
        scheduledDate: Date,
        completedDate: Date,
        estimatedHours: { type: Number, default: 4 },
        actualHours: Number,
        installerId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User' },
        installerName: String,
        notes: String
    },
    documents: [{
            type: { type: String, enum: ['contract', 'amendment', 'invoice', 'other'] },
            name: String,
            url: String,
            uploadedAt: { type: Date, default: Date.now }
        }],
    internalNotes: String
}, {
    timestamps: true
});
// Index pour recherche
ContractSchema.index({ companyId: 1 });
ContractSchema.index({ commercialId: 1 });
ContractSchema.index({ status: 1 });
ContractSchema.index({ 'installation.status': 1, 'installation.scheduledDate': 1 });
// Generer numero de contrat
ContractSchema.pre('save', async function (next) {
    if (!this.contractNumber) {
        const year = new Date().getFullYear();
        const count = await mongoose_1.default.model('Contract').countDocuments();
        this.contractNumber = `CTR-${year}-${String(count + 1).padStart(5, '0')}`;
    }
    next();
});
exports.default = mongoose_1.default.model('Contract', ContractSchema);
//# sourceMappingURL=Contract.js.map