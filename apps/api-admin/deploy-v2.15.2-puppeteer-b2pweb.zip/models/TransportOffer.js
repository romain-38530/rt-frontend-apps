"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * TransportOffer - Annonces de transport scrapées en continu
 * Stocke les offres/demandes de transport avec routes et transporteurs
 */
const mongoose_1 = __importStar(require("mongoose"));
const TransportOfferSchema = new mongoose_1.Schema({
    externalId: { type: String, required: true },
    source: {
        name: { type: String, enum: ['b2pweb', 'chronotruck', 'timocom', 'teleroute', 'other'], required: true },
        url: String,
        scrapedAt: { type: Date, default: Date.now },
        lastSeenAt: { type: Date, default: Date.now }
    },
    offerType: { type: String, enum: ['offer', 'demand'], default: 'offer' },
    company: {
        name: { type: String, required: true },
        externalId: String,
        transportCompanyId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'TransportCompany' }
    },
    contact: {
        name: String,
        email: String,
        phone: String
    },
    route: {
        origin: {
            city: String,
            postalCode: String,
            department: String,
            country: { type: String, default: 'France' },
            lat: Number,
            lng: Number
        },
        destination: {
            city: String,
            postalCode: String,
            department: String,
            country: { type: String, default: 'France' },
            lat: Number,
            lng: Number
        },
        distance: Number,
        duration: Number
    },
    loadingDate: Date,
    deliveryDate: Date,
    flexibility: String,
    cargo: {
        type: String,
        weight: Number,
        volume: Number,
        length: Number,
        width: Number,
        height: Number,
        quantity: Number,
        description: String,
        adr: Boolean,
        temperature: {
            min: Number,
            max: Number
        }
    },
    vehicle: {
        type: String,
        capacity: Number,
        features: [String]
    },
    price: {
        amount: Number,
        currency: { type: String, default: 'EUR' },
        type: { type: String, enum: ['fixed', 'negotiable', 'on_demand'] },
        perKm: Number
    },
    status: { type: String, enum: ['active', 'expired', 'matched', 'archived'], default: 'active' },
    expiresAt: Date,
    matchedWithShipment: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Shipment' },
    matchScore: Number,
    matchedAt: Date,
    notes: String,
    tags: [String]
}, {
    timestamps: true
});
// Index uniques pour éviter doublons
TransportOfferSchema.index({ externalId: 1, 'source.name': 1 }, { unique: true });
// Index pour recherche
TransportOfferSchema.index({ 'company.name': 'text', 'route.origin.city': 'text', 'route.destination.city': 'text' });
TransportOfferSchema.index({ 'route.origin.department': 1 });
TransportOfferSchema.index({ 'route.destination.department': 1 });
TransportOfferSchema.index({ 'route.origin.country': 1, 'route.destination.country': 1 });
TransportOfferSchema.index({ status: 1 });
TransportOfferSchema.index({ loadingDate: 1 });
TransportOfferSchema.index({ 'source.lastSeenAt': 1 });
TransportOfferSchema.index({ 'company.transportCompanyId': 1 });
exports.default = mongoose_1.default.model('TransportOffer', TransportOfferSchema);
//# sourceMappingURL=TransportOffer.js.map