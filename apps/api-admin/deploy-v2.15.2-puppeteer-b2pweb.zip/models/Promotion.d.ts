/**
 * Promotion - Offres promotionnelles
 */
import mongoose, { Document } from 'mongoose';
export interface IPromotion extends Document {
    promoCode: string;
    promoName: string;
    description: string;
    type: 'percentage' | 'fixed_amount' | 'free_months' | 'free_setup' | 'bundle_discount';
    value: {
        percentage?: number;
        fixedAmount?: number;
        freeMonths?: number;
        currency?: string;
    };
    applicableTo: {
        type: 'all' | 'modules' | 'packs' | 'specific';
        moduleCodes?: string[];
        packCodes?: string[];
    };
    conditions: {
        minContractMonths?: number;
        minAmount?: number;
        newCustomersOnly?: boolean;
        maxUsesTotal?: number;
        maxUsesPerCustomer?: number;
        requiresCommercialCode?: boolean;
        commercialCodes?: string[];
    };
    isActive: boolean;
    validFrom: Date;
    validUntil: Date;
    usageCount: number;
    totalDiscountGiven: number;
    createdBy: mongoose.Types.ObjectId;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IPromotion, {}, {}, {}, mongoose.Document<unknown, {}, IPromotion, {}, {}> & IPromotion & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Promotion.d.ts.map