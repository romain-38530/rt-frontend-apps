/**
 * TransportOffer - Annonces de transport scrapées en continu
 * Stocke les offres/demandes de transport avec routes et transporteurs
 */
import mongoose, { Document } from 'mongoose';
export interface ITransportOffer extends Document {
    externalId: string;
    source: {
        name: 'b2pweb' | 'chronotruck' | 'timocom' | 'teleroute' | 'other';
        url?: string;
        scrapedAt: Date;
        lastSeenAt: Date;
    };
    offerType: 'offer' | 'demand';
    company: {
        name: string;
        externalId?: string;
        transportCompanyId?: mongoose.Types.ObjectId;
    };
    contact?: {
        name?: string;
        email?: string;
        phone?: string;
    };
    route: {
        origin: {
            city?: string;
            postalCode?: string;
            department?: string;
            country: string;
            lat?: number;
            lng?: number;
        };
        destination: {
            city?: string;
            postalCode?: string;
            department?: string;
            country: string;
            lat?: number;
            lng?: number;
        };
        distance?: number;
        duration?: number;
    };
    loadingDate?: Date;
    deliveryDate?: Date;
    flexibility?: string;
    cargo?: {
        type?: string;
        weight?: number;
        volume?: number;
        length?: number;
        width?: number;
        height?: number;
        quantity?: number;
        description?: string;
        adr?: boolean;
        temperature?: {
            min?: number;
            max?: number;
        };
    };
    vehicle?: {
        type?: string;
        capacity?: number;
        features?: string[];
    };
    price?: {
        amount?: number;
        currency: string;
        type?: 'fixed' | 'negotiable' | 'on_demand';
        perKm?: number;
    };
    status: 'active' | 'expired' | 'matched' | 'archived';
    expiresAt?: Date;
    matchedWithShipment?: mongoose.Types.ObjectId;
    matchScore?: number;
    matchedAt?: Date;
    notes?: string;
    tags: string[];
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ITransportOffer, {}, {}, {}, mongoose.Document<unknown, {}, ITransportOffer, {}, {}> & ITransportOffer & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=TransportOffer.d.ts.map