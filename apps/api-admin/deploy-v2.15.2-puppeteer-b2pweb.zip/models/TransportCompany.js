"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * TransportCompany - Entreprises de transport scrapees pour Affret IA
 */
const mongoose_1 = __importStar(require("mongoose"));
const TransportCompanySchema = new mongoose_1.Schema({
    companyName: { type: String, required: true },
    legalName: String,
    siret: { type: String, index: true },
    siren: { type: String, index: true },
    tvaNumber: String,
    naf: String,
    email: { type: String, index: true },
    phone: String,
    fax: String,
    website: String,
    linkedin: String,
    address: {
        street: String,
        postalCode: String,
        city: String,
        department: String,
        departmentCode: { type: String, index: true },
        region: String,
        country: { type: String, default: 'France' },
        lat: Number,
        lng: Number
    },
    transportInfo: {
        licenseNumber: String,
        licenseType: { type: String, enum: ['light', 'heavy', 'both'] },
        fleetSize: Number,
        employeeCount: Number,
        turnover: Number,
        foundedYear: Number,
        services: [String],
        specializations: [String],
        vehicleTypes: [String],
        operatingZones: [String],
        coveredDepartments: [String],
        coveredCountries: [String]
    },
    mainContact: {
        firstName: String,
        lastName: String,
        position: String,
        email: String,
        phone: String,
        linkedinUrl: String
    },
    source: {
        type: { type: String, enum: ['scraping', 'import', 'manual', 'api'], required: true },
        name: { type: String, required: true },
        url: String,
        scrapedAt: { type: Date, default: Date.now },
        lastUpdated: Date
    },
    enrichment: {
        emailVerified: Boolean,
        emailVerifiedAt: Date,
        phoneVerified: Boolean,
        dataQualityScore: { type: Number, min: 0, max: 100 },
        enrichedAt: Date,
        enrichmentSource: String
    },
    prospectionStatus: {
        type: String,
        enum: ['new', 'to_contact', 'contacted', 'interested', 'not_interested', 'client', 'blacklist'],
        default: 'new'
    },
    addedToLeadPool: { type: Boolean, default: false },
    leadPoolId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'LeadCompany' },
    addedToLeadPoolAt: Date,
    tags: [String],
    notes: String,
    score: { type: Number, min: 0, max: 100 },
    isActive: { type: Boolean, default: true }
}, {
    timestamps: true
});
// Index pour recherche
TransportCompanySchema.index({ companyName: 'text', 'address.city': 'text' });
TransportCompanySchema.index({ 'address.departmentCode': 1, prospectionStatus: 1 });
TransportCompanySchema.index({ 'source.name': 1 });
TransportCompanySchema.index({ addedToLeadPool: 1 });
TransportCompanySchema.index({ score: -1 });
exports.default = mongoose_1.default.model('TransportCompany', TransportCompanySchema);
//# sourceMappingURL=TransportCompany.js.map