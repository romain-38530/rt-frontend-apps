/**
 * ModulePricing - Tarification des modules
 */
import mongoose, { Document } from 'mongoose';
export interface IModulePricing extends Document {
    moduleCode: string;
    moduleName: string;
    description: string;
    category: 'core' | 'transport' | 'logistics' | 'finance' | 'analytics' | 'integration' | 'addon';
    pricing: {
        type: 'flat' | 'per_user' | 'per_transaction' | 'tiered';
        basePrice: number;
        setupFee: number;
        currency: string;
        pricePerUser?: number;
        includedUsers?: number;
        pricePerTransaction?: number;
        includedTransactions?: number;
        tiers?: {
            upTo: number;
            price: number;
        }[];
    };
    installation: {
        estimatedHours: number;
        requiresOnsite: boolean;
        complexity: 'simple' | 'medium' | 'complex';
    };
    isActive: boolean;
    displayOrder: number;
    features: string[];
    dependencies: string[];
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IModulePricing, {}, {}, {}, mongoose.Document<unknown, {}, IModulePricing, {}, {}> & IModulePricing & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=ModulePricing.d.ts.map