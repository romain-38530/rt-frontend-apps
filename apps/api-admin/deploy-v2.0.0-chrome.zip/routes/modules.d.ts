declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=modules.d.ts.map