import mongoose, { Document } from 'mongoose';
export interface IModule extends Document {
    code: string;
    name: string;
    description: string;
    category: string;
    status: 'active' | 'inactive' | 'beta' | 'deprecated';
    version: string;
    pricing: {
        type: 'included' | 'addon' | 'usage';
        price?: number;
        unit?: string;
    };
    dependencies: string[];
    permissions: string[];
    configSchema?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IModule, {}, {}, {}, mongoose.Document<unknown, {}, IModule, {}, {}> & IModule & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Module.d.ts.map