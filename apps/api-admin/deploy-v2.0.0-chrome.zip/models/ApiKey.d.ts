import mongoose, { Document } from 'mongoose';
export interface IApiKey extends Document {
    name: string;
    key: string;
    keyHash: string;
    companyId: mongoose.Types.ObjectId;
    permissions: string[];
    rateLimit: number;
    status: 'active' | 'revoked' | 'expired';
    lastUsedAt?: Date;
    expiresAt?: Date;
    createdBy: mongoose.Types.ObjectId;
    revokedAt?: Date;
    revokedBy?: mongoose.Types.ObjectId;
    createdAt: Date;
}
declare const _default: mongoose.Model<IApiKey, {}, {}, {}, mongoose.Document<unknown, {}, IApiKey, {}, {}> & IApiKey & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=ApiKey.d.ts.map