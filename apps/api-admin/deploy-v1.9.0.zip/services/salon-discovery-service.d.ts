/**
 * Salon Discovery Service - Recherche automatique de salons Transport & Logistique
 * Utilise des sources web pour trouver des salons a scraper
 */
type Browser = any;
interface DiscoveredSalon {
    nom: string;
    edition?: string;
    lieu?: string;
    pays: string;
    dateDebut?: string;
    dateFin?: string;
    url?: string;
    urlListeExposants?: string;
    description?: string;
    source: string;
    confiance: number;
}
interface DiscoveryConfig {
    maxResults?: number;
    countries?: string[];
    year?: number;
    keywords?: string[];
}
declare class SalonDiscoveryService {
    private browser;
    initBrowser(): Promise<Browser>;
    closeBrowser(): Promise<void>;
    /**
     * Retourne les salons connus de la base de donnees interne
     */
    getKnownSalons(config?: DiscoveryConfig): DiscoveredSalon[];
    /**
     * Recherche de nouveaux salons via Google
     */
    discoverSalonsFromWeb(config?: DiscoveryConfig): Promise<DiscoveredSalon[]>;
    /**
     * Valider et enrichir un salon decouvert
     */
    validateAndEnrichSalon(salon: DiscoveredSalon): Promise<DiscoveredSalon | null>;
    /**
     * Recherche complete: salons connus + decouverte web
     */
    discoverAll(config?: DiscoveryConfig): Promise<{
        known: DiscoveredSalon[];
        discovered: DiscoveredSalon[];
        total: number;
    }>;
    /**
     * Parser un resultat de recherche en salon
     */
    private parseSalonFromSearch;
    /**
     * Nettoyer le nom du salon
     */
    private cleanSalonName;
    /**
     * Deviner le pays depuis l'URL
     */
    private guessCountryFromUrl;
}
declare const _default: SalonDiscoveryService;
export default _default;
export { DiscoveredSalon, DiscoveryConfig };
//# sourceMappingURL=salon-discovery-service.d.ts.map