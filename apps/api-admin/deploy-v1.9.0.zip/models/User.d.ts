import mongoose, { Document } from 'mongoose';
export interface IUser extends Document {
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
    avatar?: string;
    companyId: mongoose.Types.ObjectId;
    roles: string[];
    permissions: string[];
    status: 'active' | 'inactive' | 'pending' | 'suspended' | 'deleted';
    lastLoginAt?: Date;
    passwordResetToken?: string;
    passwordResetExpires?: Date;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IUser, {}, {}, {}, mongoose.Document<unknown, {}, IUser, {}, {}> & IUser & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=User.d.ts.map