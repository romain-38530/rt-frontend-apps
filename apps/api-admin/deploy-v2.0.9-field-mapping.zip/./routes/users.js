"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const User_1 = __importDefault(require("../models/User"));
const AuditLog_1 = __importDefault(require("../models/AuditLog"));
const Company_1 = __importDefault(require("../models/Company"));
const uuid_1 = require("uuid");
const router = (0, express_1.Router)();
// List users
router.get('/', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, role, companyId, search } = req.query;
        const query = {};
        if (status)
            query.status = status;
        if (role)
            query.roles = role;
        if (companyId)
            query.companyId = companyId;
        if (search) {
            query.$or = [
                { email: { $regex: search, $options: 'i' } },
                { firstName: { $regex: search, $options: 'i' } },
                { lastName: { $regex: search, $options: 'i' } }
            ];
        }
        const total = await User_1.default.countDocuments(query);
        const users = await User_1.default.find(query)
            .populate('companyId', 'name')
            .sort({ createdAt: -1 })
            .skip((Number(page) - 1) * Number(limit))
            .limit(Number(limit));
        res.json({
            success: true,
            data: users,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                totalPages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Get user
router.get('/:id', async (req, res) => {
    try {
        const user = await User_1.default.findById(req.params.id).populate('companyId', 'name');
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        res.json({ success: true, data: user });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Create user
router.post('/', async (req, res) => {
    try {
        const { email, firstName, lastName, companyId, roles, phone } = req.body;
        const existingUser = await User_1.default.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ success: false, error: 'Email already exists' });
        }
        const company = await Company_1.default.findById(companyId);
        if (!company) {
            return res.status(400).json({ success: false, error: 'Company not found' });
        }
        const user = new User_1.default({
            email,
            firstName,
            lastName,
            companyId,
            roles: roles || ['viewer'],
            phone,
            status: 'pending'
        });
        await user.save();
        // Audit log
        await AuditLog_1.default.create({
            userId: req.user.id,
            userName: `${req.user.email}`,
            companyId: req.user.companyId || companyId,
            companyName: company.name,
            action: 'create',
            resource: 'user',
            resourceId: user._id.toString(),
            newValue: { email, firstName, lastName, roles },
            ipAddress: req.ip || 'unknown',
            userAgent: req.headers['user-agent'] || 'unknown'
        });
        res.status(201).json({ success: true, data: user });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Update user
router.put('/:id', async (req, res) => {
    try {
        const user = await User_1.default.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        const oldValue = user.toObject();
        const updates = req.body;
        delete updates.email; // Email cannot be changed
        Object.assign(user, updates);
        await user.save();
        res.json({ success: true, data: user });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Delete user
router.delete('/:id', async (req, res) => {
    try {
        const user = await User_1.default.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        user.status = 'deleted';
        await user.save();
        res.json({ success: true, message: 'User deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Activate user
router.post('/:id/activate', async (req, res) => {
    try {
        const user = await User_1.default.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        user.status = 'active';
        await user.save();
        res.json({ success: true, data: user });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Deactivate user
router.post('/:id/deactivate', async (req, res) => {
    try {
        const user = await User_1.default.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        user.status = 'inactive';
        await user.save();
        res.json({ success: true, data: user });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Reset password
router.post('/:id/reset-password', async (req, res) => {
    try {
        const user = await User_1.default.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        user.passwordResetToken = (0, uuid_1.v4)();
        user.passwordResetExpires = new Date(Date.now() + 3600000); // 1 hour
        await user.save();
        // TODO: Send email with reset link
        res.json({ success: true, message: 'Password reset email sent' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Get user activity
router.get('/:id/activity', async (req, res) => {
    try {
        const { page = 1, limit = 50 } = req.query;
        const total = await AuditLog_1.default.countDocuments({ userId: req.params.id });
        const logs = await AuditLog_1.default.find({ userId: req.params.id })
            .sort({ timestamp: -1 })
            .skip((Number(page) - 1) * Number(limit))
            .limit(Number(limit));
        res.json({
            success: true,
            data: logs,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                totalPages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Update user roles
router.put('/:id/roles', async (req, res) => {
    try {
        const { roles } = req.body;
        const user = await User_1.default.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        user.roles = roles;
        await user.save();
        res.json({ success: true, data: user });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
exports.default = router;
//# sourceMappingURL=users.js.map