"use strict";
/**
 * Hunter.io API Service
 * Recherche et validation d'emails
 */
Object.defineProperty(exports, "__esModule", { value: true });
const HUNTER_API_URL = 'https://api.hunter.io/v2';
const HUNTER_API_KEY = process.env.HUNTER_API_KEY || '';
class HunterService {
    async makeRequest(endpoint, params = {}) {
        if (!HUNTER_API_KEY) {
            console.error('[HunterService] API key not configured');
            return null;
        }
        try {
            const url = new URL(`${HUNTER_API_URL}${endpoint}`);
            url.searchParams.set('api_key', HUNTER_API_KEY);
            for (const [key, value] of Object.entries(params)) {
                if (value)
                    url.searchParams.set(key, value);
            }
            const response = await fetch(url.toString());
            if (!response.ok) {
                const errorText = await response.text();
                console.error(`[HunterService] API error ${response.status}: ${errorText}`);
                return null;
            }
            const result = await response.json();
            return result.data;
        }
        catch (error) {
            console.error('[HunterService] Request failed:', error);
            return null;
        }
    }
    /**
     * Rechercher tous les emails d'un domaine
     */
    async domainSearch(domain, options) {
        const params = { domain };
        if (options?.department)
            params.department = options.department;
        if (options?.seniority)
            params.seniority = options.seniority;
        if (options?.limit)
            params.limit = String(options.limit);
        return this.makeRequest('/domain-search', params);
    }
    /**
     * Vérifier la validité d'un email
     */
    async verifyEmail(email) {
        return this.makeRequest('/email-verifier', { email });
    }
    /**
     * Trouver l'email d'une personne à partir de son nom et domaine
     */
    async findEmail(params) {
        const queryParams = {
            domain: params.domain,
            first_name: params.firstName,
            last_name: params.lastName
        };
        if (params.company)
            queryParams.company = params.company;
        return this.makeRequest('/email-finder', queryParams);
    }
    /**
     * Mapper le statut Hunter vers notre format
     */
    mapEmailStatus(hunterStatus) {
        const statusMap = {
            'valid': 'VALID',
            'invalid': 'INVALID',
            'accept_all': 'CATCH_ALL',
            'webmail': 'VALID',
            'disposable': 'DISPOSABLE',
            'unknown': 'UNKNOWN'
        };
        return statusMap[hunterStatus?.toLowerCase()] || 'UNKNOWN';
    }
    /**
     * Rechercher des contacts supply chain pour un domaine
     */
    async searchSupplyChainContacts(domain) {
        // Rechercher dans les départements pertinents
        const departments = ['logistics', 'operations', 'supply chain', 'procurement'];
        const allEmails = [];
        for (const dept of departments) {
            const result = await this.domainSearch(domain, {
                department: dept,
                seniority: 'senior',
                limit: 10
            });
            if (result?.emails) {
                allEmails.push(...result.emails);
            }
        }
        // Dédupliquer par email
        const uniqueEmails = allEmails.filter((email, index, self) => index === self.findIndex(e => e.value === email.value));
        return uniqueEmails;
    }
    /**
     * Vérifier plusieurs emails en batch
     */
    async verifyEmailsBatch(emails) {
        const results = new Map();
        // Hunter n'a pas d'endpoint batch, on fait les requêtes séquentiellement avec un délai
        for (const email of emails) {
            const result = await this.verifyEmail(email);
            if (result) {
                results.set(email, result);
            }
            // Respecter le rate limit
            await new Promise(resolve => setTimeout(resolve, 200));
        }
        return results;
    }
}
exports.default = new HunterService();
//# sourceMappingURL=hunter-service.js.map