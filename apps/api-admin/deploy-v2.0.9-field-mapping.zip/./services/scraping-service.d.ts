/**
 * Scraping Service - Collecte des exposants de salons professionnels
 * Utilise Puppeteer pour le scraping dynamique et Cheerio pour le HTML statique
 */
type Browser = any;
export interface ScrapedCompany {
    raisonSociale: string;
    siteWeb?: string;
    pays?: string;
    ville?: string;
    numeroStand?: string;
    secteurActivite?: string;
    descriptionActivite?: string;
    telephone?: string;
    email?: string;
    urlPageExposant?: string;
}
export interface SalonAdapter {
    name: string;
    baseUrl: string;
    scrape: (browser: Browser, config: AdapterConfig) => Promise<ScrapedCompany[]>;
}
export interface AdapterConfig {
    url: string;
    maxPages?: number;
    delay?: number;
    filters?: Record<string, string>;
}
export interface ScrapingResult {
    success: boolean;
    companies: ScrapedCompany[];
    totalScraped: number;
    errors: string[];
    duration: number;
}
declare class ScrapingService {
    private browser;
    private adapters;
    constructor();
    registerAdapter(adapter: SalonAdapter): void;
    getAvailableAdapters(): string[];
    initBrowser(): Promise<Browser>;
    closeBrowser(): Promise<void>;
    scrapeUrl(url: string, adapterName: string, config?: Partial<AdapterConfig>): Promise<ScrapingResult>;
    static cleanText(text: string | undefined): string;
    static extractDomain(url: string | undefined): string | undefined;
    static guessCountry(text: string): string;
}
declare const _default: ScrapingService;
export default _default;
export { ScrapingService };
//# sourceMappingURL=scraping-service.d.ts.map