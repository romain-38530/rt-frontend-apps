declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=subscriptions.d.ts.map