import mongoose, { Document } from 'mongoose';
export interface ICrmCommercial extends Document {
    firstName: string;
    lastName: string;
    email: string;
    telephone?: string;
    type: 'internal' | 'external';
    status: 'active' | 'inactive' | 'on_leave';
    region?: string;
    specialisation?: string[];
    objectifMensuel?: number;
    linkedinUrl?: string;
    avatar?: string;
    notes?: string;
    dateEmbauche?: Date;
    accessCode: string;
    passwordHash?: string;
    tempPassword?: string;
    mustChangePassword: boolean;
    lastLogin?: Date;
    loginAttempts: number;
    lockedUntil?: Date;
    commissionConfig: {
        tauxConversion: number;
        tauxSignature: number;
        tauxRecurrent: number;
        bonusObjectif: number;
    };
    stats: {
        leadsAssignes: number;
        leadsConverts: number;
        leadsEnCours: number;
        tauxConversion: number;
        commissionsTotal: number;
        commissionsPending: number;
    };
    createdAt: Date;
    updatedAt: Date;
    comparePassword(password: string): Promise<boolean>;
    generateAccessCode(): string;
}
declare const _default: mongoose.Model<ICrmCommercial, {}, {}, {}, mongoose.Document<unknown, {}, ICrmCommercial, {}, {}> & ICrmCommercial & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=CrmCommercial.d.ts.map