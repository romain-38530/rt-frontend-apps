"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * InstallationPlanning - Planning des installations clients
 * Systeme partage entre manager et commerciaux avec validation email
 */
const mongoose_1 = __importStar(require("mongoose"));
const InstallationPlanningSchema = new mongoose_1.Schema({
    contractId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Contract', required: true },
    contractNumber: { type: String, required: true },
    companyId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Company' },
    companyName: { type: String, required: true },
    contactName: { type: String, required: true },
    contactEmail: { type: String, required: true },
    contactPhone: String,
    title: { type: String, required: true },
    description: String,
    proposedSlots: [{
            date: { type: Date, required: true },
            startTime: { type: String, required: true },
            endTime: { type: String, required: true },
            duration: { type: Number, required: true }
        }],
    confirmedSlot: {
        date: Date,
        startTime: String,
        endTime: String,
        duration: Number
    },
    assignedTo: {
        type: { type: String, enum: ['commercial', 'technician', 'manager'], default: 'technician' },
        userId: { type: mongoose_1.Schema.Types.ObjectId },
        userName: String
    },
    commercialId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'CrmCommercial', required: true },
    commercialName: { type: String, required: true },
    approvedBy: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User' },
    approvedByName: String,
    approvedAt: Date,
    status: {
        type: String,
        enum: ['draft', 'proposed', 'pending_client', 'pending_manager', 'confirmed', 'in_progress', 'completed', 'cancelled', 'rescheduled'],
        default: 'draft'
    },
    validation: {
        clientToken: { type: String, required: true },
        clientValidatedAt: Date,
        clientSelectedSlot: Number,
        managerValidatedAt: Date,
        emailsSent: [{
                type: { type: String, enum: ['proposal', 'confirmation', 'reminder', 'cancellation'] },
                sentAt: Date,
                to: String
            }]
    },
    installationConfig: {
        type: { type: String, enum: ['remote', 'onsite', 'hybrid'], default: 'remote' },
        estimatedDuration: { type: Number, default: 120 },
        phases: [{
                name: String,
                duration: Number,
                description: String,
                completed: { type: Boolean, default: false },
                completedAt: Date
            }],
        requirements: [String],
        meetingLink: String,
        address: String
    },
    feedback: {
        rating: { type: Number, min: 1, max: 5 },
        comment: String,
        submittedAt: Date
    },
    internalNotes: String,
    clientNotes: String,
    reminders: [{
            type: { type: String, enum: ['24h', '1h', 'custom'] },
            scheduledFor: Date,
            sent: { type: Boolean, default: false },
            sentAt: Date
        }]
}, {
    timestamps: true
});
// Index
InstallationPlanningSchema.index({ contractId: 1 });
InstallationPlanningSchema.index({ commercialId: 1 });
InstallationPlanningSchema.index({ status: 1 });
InstallationPlanningSchema.index({ 'confirmedSlot.date': 1 });
InstallationPlanningSchema.index({ 'validation.clientToken': 1 });
InstallationPlanningSchema.index({ 'assignedTo.userId': 1 });
exports.default = mongoose_1.default.model('InstallationPlanning', InstallationPlanningSchema);
//# sourceMappingURL=InstallationPlanning.js.map