import mongoose, { Document } from 'mongoose';
export interface ISubscription extends Document {
    companyId: mongoose.Types.ObjectId;
    plan: 'free' | 'starter' | 'professional' | 'enterprise' | 'custom';
    status: 'active' | 'trial' | 'past_due' | 'cancelled' | 'suspended';
    billingCycle: 'monthly' | 'quarterly' | 'yearly';
    price: number;
    currency: string;
    modules: string[];
    limits: {
        users: number;
        orders: number;
        storage: number;
        apiCalls: number;
    };
    usage: {
        users: number;
        orders: number;
        storage: number;
        apiCalls: number;
    };
    startDate: Date;
    endDate: Date;
    trialEndDate?: Date;
    autoRenew: boolean;
    stripeCustomerId?: string;
    stripeSubscriptionId?: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ISubscription, {}, {}, {}, mongoose.Document<unknown, {}, ISubscription, {}, {}> & ISubscription & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Subscription.d.ts.map