import mongoose, { Document } from 'mongoose';
export interface ICommercialAvailability extends Document {
    commercialId: mongoose.Types.ObjectId;
    weeklySchedule: {
        dayOfWeek: number;
        slots: {
            startTime: string;
            endTime: string;
        }[];
        isActive: boolean;
    }[];
    exceptions: {
        date: Date;
        type: 'unavailable' | 'custom';
        customSlots?: {
            startTime: string;
            endTime: string;
        }[];
        reason?: string;
    }[];
    meetingDuration: number;
    bufferTime: number;
    maxDaysInAdvance: number;
    timezone: string;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICommercialAvailability, {}, {}, {}, mongoose.Document<unknown, {}, ICommercialAvailability, {}, {}> & ICommercialAvailability & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=CommercialAvailability.d.ts.map