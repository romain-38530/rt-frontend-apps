/**
 * Contract - Contrats clients
 */
import mongoose, { Document } from 'mongoose';
export interface IContract extends Document {
    contractNumber: string;
    companyId: mongoose.Types.ObjectId;
    companyName: string;
    contactName: string;
    contactEmail: string;
    contactPhone?: string;
    commercialId: mongoose.Types.ObjectId;
    commercialName: string;
    type: 'pack' | 'custom' | 'individual_modules';
    packCode?: string;
    packName?: string;
    modules: {
        moduleCode: string;
        moduleName: string;
        monthlyPrice: number;
        users?: number;
    }[];
    pricing: {
        monthlyTotal: number;
        setupFeeTotal: number;
        currency: string;
        billingCycle: 'monthly' | 'quarterly' | 'annual';
        paymentMethod: 'card' | 'sepa' | 'transfer' | 'check';
    };
    promotions: {
        promoCode: string;
        promoName: string;
        discountAmount: number;
        type: string;
    }[];
    startDate: Date;
    endDate?: Date;
    commitmentMonths: number;
    autoRenewal: boolean;
    renewalNoticeDate?: Date;
    status: 'draft' | 'pending_signature' | 'active' | 'suspended' | 'terminated' | 'expired';
    signedAt?: Date;
    signedBy?: string;
    terminatedAt?: Date;
    terminationReason?: string;
    installation: {
        status: 'pending' | 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
        scheduledDate?: Date;
        completedDate?: Date;
        estimatedHours: number;
        actualHours?: number;
        installerId?: mongoose.Types.ObjectId;
        installerName?: string;
        notes?: string;
    };
    documents: {
        type: 'contract' | 'amendment' | 'invoice' | 'other';
        name: string;
        url: string;
        uploadedAt: Date;
    }[];
    internalNotes: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IContract, {}, {}, {}, mongoose.Document<unknown, {}, IContract, {}, {}> & IContract & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Contract.d.ts.map