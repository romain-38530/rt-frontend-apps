"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const LeadContactSchema = new mongoose_1.Schema({
    entrepriseId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'LeadCompany', required: true },
    // Identité
    civilite: String,
    prenom: String,
    nom: { type: String, required: true },
    poste: String,
    seniority: {
        type: String,
        enum: ['director', 'vp', 'manager', 'senior', 'entry', 'unknown'],
        default: 'unknown'
    },
    // Coordonnées
    email: { type: String, lowercase: true },
    emailStatus: {
        type: String,
        enum: ['UNKNOWN', 'VALID', 'INVALID', 'CATCH_ALL', 'DISPOSABLE', 'RISKY'],
        default: 'UNKNOWN'
    },
    telephoneDirect: String,
    linkedinUrl: String,
    // Enrichissement
    sourceEnrichissement: {
        type: String,
        enum: ['APOLLO', 'HUNTER', 'LEMLIST', 'MANUAL', 'SCRAPING']
    },
    apolloPersonId: String,
    hunterData: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    lemlistData: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    dateEnrichissement: Date,
    // Prospection
    statutContact: {
        type: String,
        enum: ['NEW', 'CONTACTED', 'INTERESTED', 'MEETING_SCHEDULED', 'CONVERTED', 'OPTED_OUT', 'BOUNCED'],
        default: 'NEW'
    },
    estContactPrincipal: { type: Boolean, default: false },
    optOut: { type: Boolean, default: false },
    dateOptOut: Date
}, {
    timestamps: true
});
LeadContactSchema.index({ entrepriseId: 1 });
LeadContactSchema.index({ email: 1 });
LeadContactSchema.index({ statutContact: 1 });
LeadContactSchema.index({ entrepriseId: 1, estContactPrincipal: 1 });
LeadContactSchema.index({ nom: 'text', prenom: 'text', poste: 'text' });
LeadContactSchema.index({ emailStatus: 1 });
LeadContactSchema.index({ seniority: 1 });
exports.default = mongoose_1.default.model('LeadContact', LeadContactSchema);
//# sourceMappingURL=LeadContact.js.map