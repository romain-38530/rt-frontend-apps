declare const router: import("express-serve-static-core").Router;
export declare const publicInstallationRoutes: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=manager.d.ts.map