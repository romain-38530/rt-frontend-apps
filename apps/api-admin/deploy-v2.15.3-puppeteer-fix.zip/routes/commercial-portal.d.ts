declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=commercial-portal.d.ts.map