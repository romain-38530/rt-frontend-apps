"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Routes API pour le scraping d'entreprises de transport
 * Scraping continu B2PWeb avec enregistrement des routes
 */
const express_1 = require("express");
const transport_scraping_service_1 = require("../services/transport-scraping-service");
const TransportCompany_1 = __importDefault(require("../models/TransportCompany"));
const TransportOffer_1 = __importDefault(require("../models/TransportOffer"));
const multer_1 = __importDefault(require("multer"));
const router = (0, express_1.Router)();
const upload = (0, multer_1.default)({ storage: multer_1.default.memoryStorage() });
// ============================================
// CONFIGURATION & STATUS
// ============================================
/**
 * GET /config - Configuration du scraping
 */
router.get('/config', async (_req, res) => {
    try {
        const config = transport_scraping_service_1.transportScrapingService.getConfig();
        const isAuthenticated = transport_scraping_service_1.transportScrapingService.isB2PWebAuthenticated();
        res.json({
            success: true,
            data: {
                ...config,
                b2pwebAuthenticated: isAuthenticated,
                b2pwebCredentials: config.b2pwebCredentials ? { username: config.b2pwebCredentials.username } : null
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * PUT /config - Mettre à jour la configuration
 */
router.put('/config', async (req, res) => {
    try {
        const config = transport_scraping_service_1.transportScrapingService.updateConfig(req.body);
        res.json({ success: true, data: config });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// STATISTIQUES
// ============================================
/**
 * GET /stats - Statistiques des entreprises
 */
router.get('/stats', async (_req, res) => {
    try {
        const stats = await transport_scraping_service_1.transportScrapingService.getStats();
        res.json({ success: true, data: stats });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /stats/offers - Statistiques des offres
 */
router.get('/stats/offers', async (_req, res) => {
    try {
        const stats = await transport_scraping_service_1.transportScrapingService.getOffersStats();
        res.json({ success: true, data: stats });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// AUTHENTIFICATION B2PWEB
// ============================================
/**
 * POST /b2pweb/auth - Authentification B2PWeb
 */
router.post('/b2pweb/auth', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).json({
                success: false,
                error: 'Username et password requis'
            });
        }
        const result = await transport_scraping_service_1.transportScrapingService.authenticateB2PWeb(username, password);
        res.json(result);
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /b2pweb/status - Statut d'authentification B2PWeb
 */
router.get('/b2pweb/status', async (_req, res) => {
    try {
        res.json({
            success: true,
            data: {
                authenticated: transport_scraping_service_1.transportScrapingService.isB2PWebAuthenticated()
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// JOBS DE SCRAPING
// ============================================
/**
 * GET /jobs - Liste des jobs de scraping
 */
router.get('/jobs', async (_req, res) => {
    try {
        const jobs = transport_scraping_service_1.transportScrapingService.getAllJobs();
        res.json({ success: true, data: jobs });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /jobs/:id - Statut d'un job
 */
router.get('/jobs/:id', async (req, res) => {
    try {
        const job = transport_scraping_service_1.transportScrapingService.getJobStatus(req.params.id);
        if (!job) {
            return res.status(404).json({ success: false, error: 'Job non trouvé' });
        }
        res.json({ success: true, data: job });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /jobs/:id/stop - Arrêter un job
 */
router.post('/jobs/:id/stop', async (req, res) => {
    try {
        const success = transport_scraping_service_1.transportScrapingService.stopJob(req.params.id);
        if (!success) {
            return res.status(404).json({ success: false, error: 'Job non trouvé' });
        }
        res.json({ success: true, message: 'Job arrêté' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// SCRAPING CONTINU
// ============================================
/**
 * POST /scrape/continuous/start - Démarrer le scraping continu
 */
router.post('/scrape/continuous/start', async (req, res) => {
    try {
        const { intervalMinutes } = req.body;
        const job = await transport_scraping_service_1.transportScrapingService.startContinuousScraping(intervalMinutes);
        res.json({
            success: true,
            data: job,
            message: `Scraping continu démarré (intervalle: ${job.interval} minutes)`
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /scrape/continuous/stop - Arrêter le scraping continu
 */
router.post('/scrape/continuous/stop', async (_req, res) => {
    try {
        const jobs = transport_scraping_service_1.transportScrapingService.getAllJobs();
        const continuousJob = jobs.find(j => j.type === 'continuous' && j.isActive);
        if (!continuousJob) {
            return res.status(404).json({ success: false, error: 'Aucun scraping continu actif' });
        }
        transport_scraping_service_1.transportScrapingService.stopJob(continuousJob.id);
        res.json({ success: true, message: 'Scraping continu arrêté' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// OFFRES DE TRANSPORT
// ============================================
/**
 * GET /offers - Liste des offres avec filtres
 */
router.get('/offers', async (req, res) => {
    try {
        const { search, originDepartment, destinationDepartment, originCity, destinationCity, vehicleType, dateFrom, dateTo, status, companyId, page, limit } = req.query;
        const result = await transport_scraping_service_1.transportScrapingService.searchOffers({
            search: search,
            originDepartment: originDepartment,
            destinationDepartment: destinationDepartment,
            originCity: originCity,
            destinationCity: destinationCity,
            vehicleType: vehicleType,
            dateFrom: dateFrom ? new Date(dateFrom) : undefined,
            dateTo: dateTo ? new Date(dateTo) : undefined,
            status: status,
            companyId: companyId,
            page: page ? parseInt(page) : undefined,
            limit: limit ? parseInt(limit) : undefined
        });
        res.json({ success: true, data: result });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /offers/:id - Détail d'une offre
 */
router.get('/offers/:id', async (req, res) => {
    try {
        const offer = await TransportOffer_1.default.findById(req.params.id)
            .populate('company.transportCompanyId');
        if (!offer) {
            return res.status(404).json({ success: false, error: 'Offre non trouvée' });
        }
        res.json({ success: true, data: offer });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * DELETE /offers/:id - Supprimer une offre
 */
router.delete('/offers/:id', async (req, res) => {
    try {
        const offer = await TransportOffer_1.default.findByIdAndDelete(req.params.id);
        if (!offer) {
            return res.status(404).json({ success: false, error: 'Offre non trouvée' });
        }
        res.json({ success: true, message: 'Offre supprimée' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /offers/cleanup - Nettoyer les offres expirées
 */
router.post('/offers/cleanup', async (req, res) => {
    try {
        const { daysOld = 7 } = req.body;
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - daysOld);
        const result = await TransportOffer_1.default.updateMany({
            status: 'active',
            'source.lastSeenAt': { $lt: cutoffDate }
        }, { status: 'expired' });
        res.json({
            success: true,
            data: { markedExpired: result.modifiedCount },
            message: `${result.modifiedCount} offres marquées comme expirées`
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// IMPORT CSV
// ============================================
/**
 * POST /import/csv - Import depuis fichier CSV
 */
router.post('/import/csv', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, error: 'Fichier CSV requis' });
        }
        const sourceName = req.body.sourceName || 'csv-import';
        const csvContent = req.file.buffer.toString('utf-8');
        const delimiter = req.body.delimiter || ';';
        // Parser le CSV manuellement
        const lines = csvContent.split('\n').filter(line => line.trim());
        if (lines.length < 2) {
            return res.status(400).json({ success: false, error: 'Fichier CSV vide ou invalide' });
        }
        const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^"|"$/g, ''));
        const records = lines.slice(1).map(line => {
            const values = line.split(delimiter).map(v => v.trim().replace(/^"|"$/g, ''));
            const record = {};
            headers.forEach((header, index) => {
                record[header] = values[index] || '';
            });
            return record;
        });
        // Mapper les colonnes
        const data = records.map((row) => ({
            companyName: row['companyName'] || row['Nom'] || row['Entreprise'] || row['Raison sociale'] || row['name'],
            email: row['email'] || row['Email'] || row['Mail'],
            phone: row['phone'] || row['Telephone'] || row['Tel'] || row['Phone'],
            city: row['city'] || row['Ville'] || row['City'],
            postalCode: row['postalCode'] || row['Code postal'] || row['CP'],
            services: row['services'] || row['Services'],
            vehicleTypes: row['vehicleTypes'] || row['Vehicules'] || row['Types vehicules'],
            siret: row['siret'] || row['SIRET']
        })).filter((r) => r.companyName);
        const job = transport_scraping_service_1.transportScrapingService.createScrapingJob('csv-import', 'companies', { sourceName });
        // Lancer l'import en arrière-plan
        transport_scraping_service_1.transportScrapingService.importFromCSV(job.id, data, sourceName);
        res.json({
            success: true,
            data: job,
            message: `Import CSV lancé: ${data.length} lignes détectées`
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// GESTION DES ENTREPRISES
// ============================================
/**
 * GET /companies - Liste des entreprises avec filtres
 */
router.get('/companies', async (req, res) => {
    try {
        const { search, status, source, department, hasEmail, addedToLeadPool, page, limit } = req.query;
        const result = await transport_scraping_service_1.transportScrapingService.searchCompanies({
            search: search,
            status: status,
            source: source,
            department: department,
            hasEmail: hasEmail === 'true' ? true : hasEmail === 'false' ? false : undefined,
            addedToLeadPool: addedToLeadPool === 'true' ? true : addedToLeadPool === 'false' ? false : undefined,
            page: page ? parseInt(page) : undefined,
            limit: limit ? parseInt(limit) : undefined
        });
        res.json({ success: true, data: result });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /companies/:id - Détail d'une entreprise
 */
router.get('/companies/:id', async (req, res) => {
    try {
        const company = await TransportCompany_1.default.findById(req.params.id);
        if (!company) {
            return res.status(404).json({ success: false, error: 'Entreprise non trouvée' });
        }
        res.json({ success: true, data: company });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /companies/:id/routes - Routes d'une entreprise
 */
router.get('/companies/:id/routes', async (req, res) => {
    try {
        const result = await transport_scraping_service_1.transportScrapingService.getCompanyRoutes(req.params.id);
        res.json({ success: true, data: result });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * GET /companies/:id/offers - Offres d'une entreprise
 */
router.get('/companies/:id/offers', async (req, res) => {
    try {
        const { page, limit } = req.query;
        const result = await transport_scraping_service_1.transportScrapingService.searchOffers({
            companyId: req.params.id,
            page: page ? parseInt(page) : undefined,
            limit: limit ? parseInt(limit) : undefined
        });
        res.json({ success: true, data: result });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * PUT /companies/:id - Mettre à jour une entreprise
 */
router.put('/companies/:id', async (req, res) => {
    try {
        const company = await TransportCompany_1.default.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true, runValidators: true });
        if (!company) {
            return res.status(404).json({ success: false, error: 'Entreprise non trouvée' });
        }
        res.json({ success: true, data: company });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * DELETE /companies/:id - Supprimer une entreprise
 */
router.delete('/companies/:id', async (req, res) => {
    try {
        const success = await transport_scraping_service_1.transportScrapingService.deleteCompany(req.params.id);
        if (!success) {
            return res.status(404).json({ success: false, error: 'Entreprise non trouvée' });
        }
        res.json({ success: true, message: 'Entreprise supprimée' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /companies/:id/status - Mettre à jour le statut de prospection
 */
router.post('/companies/:id/status', async (req, res) => {
    try {
        const { status, notes } = req.body;
        if (!status) {
            return res.status(400).json({ success: false, error: 'Statut requis' });
        }
        const company = await transport_scraping_service_1.transportScrapingService.updateProspectionStatus(req.params.id, status, notes);
        if (!company) {
            return res.status(404).json({ success: false, error: 'Entreprise non trouvée' });
        }
        res.json({ success: true, data: company });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /companies/add-to-lead-pool - Ajouter au Lead Pool
 */
router.post('/companies/add-to-lead-pool', async (req, res) => {
    try {
        const { companyIds } = req.body;
        if (!companyIds || !Array.isArray(companyIds) || companyIds.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'Liste de companyIds requise'
            });
        }
        const result = await transport_scraping_service_1.transportScrapingService.addToLeadPool(companyIds);
        res.json({
            success: true,
            data: result,
            message: `${result.success} entreprises ajoutées au Lead Pool`
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
/**
 * POST /companies/bulk-action - Actions en masse
 */
router.post('/companies/bulk-action', async (req, res) => {
    try {
        const { action, companyIds, data } = req.body;
        if (!companyIds || !Array.isArray(companyIds) || companyIds.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'Liste de companyIds requise'
            });
        }
        let result = { success: 0, failed: 0 };
        switch (action) {
            case 'updateStatus':
                for (const id of companyIds) {
                    try {
                        await transport_scraping_service_1.transportScrapingService.updateProspectionStatus(id, data.status, data.notes);
                        result.success++;
                    }
                    catch (e) {
                        result.failed++;
                    }
                }
                break;
            case 'addToLeadPool':
                result = await transport_scraping_service_1.transportScrapingService.addToLeadPool(companyIds);
                break;
            case 'delete':
                for (const id of companyIds) {
                    try {
                        await transport_scraping_service_1.transportScrapingService.deleteCompany(id);
                        result.success++;
                    }
                    catch (e) {
                        result.failed++;
                    }
                }
                break;
            case 'addTags':
                for (const id of companyIds) {
                    try {
                        await TransportCompany_1.default.findByIdAndUpdate(id, {
                            $addToSet: { tags: { $each: data.tags } }
                        });
                        result.success++;
                    }
                    catch (e) {
                        result.failed++;
                    }
                }
                break;
            default:
                return res.status(400).json({ success: false, error: 'Action non reconnue' });
        }
        res.json({
            success: true,
            data: result,
            message: `Action "${action}" effectuée sur ${result.success} entreprises`
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// CREATION MANUELLE
// ============================================
/**
 * POST /companies - Créer une entreprise manuellement
 */
router.post('/companies', async (req, res) => {
    try {
        const company = new TransportCompany_1.default({
            ...req.body,
            source: {
                type: 'manual',
                name: 'backoffice',
                scrapedAt: new Date()
            },
            isActive: true
        });
        await company.save();
        res.status(201).json({ success: true, data: company });
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// EXPORT
// ============================================
/**
 * GET /export/csv - Export CSV
 */
router.get('/export/csv', async (req, res) => {
    try {
        const { status, source, department } = req.query;
        const csv = await transport_scraping_service_1.transportScrapingService.exportToCSV({
            status: status,
            source: source,
            department: department
        });
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename=transport-companies-${Date.now()}.csv`);
        res.send(csv);
    }
    catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=transport-scraping.js.map