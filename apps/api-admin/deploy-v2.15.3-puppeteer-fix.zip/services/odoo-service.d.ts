/**
 * Odoo API Service
 * Connexion a Odoo via JSON-RPC
 */
interface OdooConfig {
    url: string;
    db: string;
    username: string;
    password: string;
}
interface OdooSearchParams {
    model: string;
    domain?: any[];
    fields?: string[];
    limit?: number;
    offset?: number;
    order?: string;
}
interface OdooCreateParams {
    model: string;
    values: Record<string, any>;
}
interface OdooUpdateParams {
    model: string;
    ids: number[];
    values: Record<string, any>;
}
declare class OdooService {
    private config;
    private uid;
    constructor();
    /**
     * Verifier si le service est configure
     */
    isConfigured(): boolean;
    /**
     * Appel JSON-RPC generique
     */
    private jsonRpc;
    /**
     * Authentification - obtenir l'UID utilisateur
     */
    authenticate(): Promise<number>;
    /**
     * Executer une methode sur un modele Odoo
     */
    private execute;
    /**
     * Rechercher des enregistrements
     */
    search(params: OdooSearchParams): Promise<number[]>;
    /**
     * Lire des enregistrements par IDs
     */
    read(model: string, ids: number[], fields?: string[]): Promise<any[]>;
    /**
     * Rechercher et lire en une seule requete
     */
    searchRead(params: OdooSearchParams): Promise<any[]>;
    /**
     * Creer un enregistrement
     */
    create(params: OdooCreateParams): Promise<number>;
    /**
     * Mettre a jour des enregistrements
     */
    update(params: OdooUpdateParams): Promise<boolean>;
    /**
     * Supprimer des enregistrements
     */
    delete(model: string, ids: number[]): Promise<boolean>;
    /**
     * Compter les enregistrements
     */
    count(model: string, domain?: any[]): Promise<number>;
    /**
     * Recuperer les clients (res.partner)
     * Note: Utilise is_company=true et customer=true (ou active=true) pour compatibilite Odoo 12+
     */
    getCustomers(options?: {
        limit?: number;
        offset?: number;
        search?: string;
    }): Promise<any[]>;
    /**
     * Recuperer les produits (product.product)
     */
    getProducts(options?: {
        limit?: number;
        offset?: number;
        search?: string;
        active?: boolean;
    }): Promise<any[]>;
    /**
     * Recuperer les commandes de vente (sale.order)
     */
    getSaleOrders(options?: {
        limit?: number;
        offset?: number;
        state?: string;
        partnerId?: number;
    }): Promise<any[]>;
    /**
     * Recuperer les factures (account.move)
     */
    getInvoices(options?: {
        limit?: number;
        offset?: number;
        state?: string;
        partnerId?: number;
    }): Promise<any[]>;
    /**
     * Creer un client dans Odoo
     */
    createCustomer(data: {
        name: string;
        email?: string;
        phone?: string;
        street?: string;
        city?: string;
        zip?: string;
        countryCode?: string;
        vat?: string;
        website?: string;
    }): Promise<number>;
    /**
     * Synchroniser un lead CRM vers Odoo
     */
    syncLeadToOdoo(lead: {
        companyName: string;
        contactName?: string;
        email?: string;
        phone?: string;
        city?: string;
        description?: string;
    }): Promise<number>;
    /**
     * Obtenir la configuration (sans password)
     */
    getConfig(): Record<string, unknown>;
}
declare const _default: OdooService;
export default _default;
export { OdooConfig, OdooSearchParams, OdooCreateParams, OdooUpdateParams };
//# sourceMappingURL=odoo-service.d.ts.map