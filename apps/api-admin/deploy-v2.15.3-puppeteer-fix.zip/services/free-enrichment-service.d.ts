/**
 * Free Enrichment Service - Enrichit les leads par des methodes gratuites
 * - Google Search pour trouver site web/adresse
 * - Scraping du site web de l'entreprise
 * - API SIRENE pour entreprises francaises
 */
interface EnrichmentResult {
    companyId: string;
    success: boolean;
    fieldsEnriched: string[];
    source: string;
    error?: string;
}
interface EnrichmentStats {
    processed: number;
    enriched: number;
    errors: number;
    sources: Record<string, number>;
}
declare class FreeEnrichmentService {
    /**
     * Enrichir une entreprise par son site web (scraper la page contact/about)
     */
    enrichFromWebsite(company: any): Promise<EnrichmentResult>;
    /**
     * Extraire les infos de contact d'une page
     */
    private extractContactInfo;
    /**
     * Enrichir via API SIRENE (entreprises francaises)
     */
    enrichFromSirene(company: any): Promise<EnrichmentResult>;
    /**
     * Rechercher le site web via Google (methode de secours)
     */
    findWebsiteViaGoogle(company: any): Promise<EnrichmentResult>;
    /**
     * Enrichissement complet d'un batch d'entreprises
     */
    enrichBatch(batchSize?: number): Promise<EnrichmentStats>;
}
declare const _default: FreeEnrichmentService;
export default _default;
//# sourceMappingURL=free-enrichment-service.d.ts.map