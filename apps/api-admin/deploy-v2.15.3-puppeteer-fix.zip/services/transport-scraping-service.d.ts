import { ITransportCompany } from '../models/TransportCompany';
import { ITransportOffer } from '../models/TransportOffer';
interface ScrapingJob {
    id: string;
    source: string;
    type: 'companies' | 'offers' | 'continuous';
    status: 'pending' | 'running' | 'completed' | 'failed' | 'stopped';
    startedAt?: Date;
    completedAt?: Date;
    lastRunAt?: Date;
    nextRunAt?: Date;
    totalFound: number;
    totalImported: number;
    totalUpdated: number;
    totalDuplicates: number;
    errors: string[];
    filters?: Record<string, any>;
    interval?: number;
    isActive: boolean;
}
interface B2PWebCredentials {
    username: string;
    password: string;
}
interface ScrapingConfig {
    b2pwebEnabled: boolean;
    b2pwebCredentials?: B2PWebCredentials;
    intervalMinutes: number;
    maxOffersPerRun: number;
}
export declare class TransportScrapingService {
    private b2pwebClient;
    private b2pwebToken;
    private b2pwebCookies;
    private isAuthenticated;
    private browser;
    private page;
    constructor();
    getConfig(): ScrapingConfig;
    updateConfig(config: Partial<ScrapingConfig>): ScrapingConfig;
    authenticateB2PWeb(username: string, password: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    closeBrowser(): Promise<void>;
    isB2PWebAuthenticated(): boolean;
    createScrapingJob(source: string, type: ScrapingJob['type'], filters?: Record<string, any>): ScrapingJob;
    getJobStatus(jobId: string): ScrapingJob | undefined;
    getAllJobs(): ScrapingJob[];
    stopJob(jobId: string): boolean;
    startContinuousScraping(intervalMinutes?: number): Promise<ScrapingJob>;
    private runOffersScraping;
    private scrapeOffersWithPuppeteer;
    private processOffer;
    private parseB2PWebOffer;
    private upsertTransportCompany;
    getOffersStats(): Promise<{
        total: number;
        active: number;
        bySource: Record<string, number>;
        byOriginDepartment: Record<string, number>;
        byDestinationDepartment: Record<string, number>;
        topRoutes: Array<{
            origin: string;
            destination: string;
            count: number;
        }>;
        lastScrapedAt?: Date;
    }>;
    searchOffers(filters: {
        search?: string;
        originDepartment?: string;
        destinationDepartment?: string;
        originCity?: string;
        destinationCity?: string;
        vehicleType?: string;
        dateFrom?: Date;
        dateTo?: Date;
        status?: string;
        companyId?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        offers: ITransportOffer[];
        total: number;
        pages: number;
    }>;
    getCompanyRoutes(companyId: string): Promise<{
        routes: Array<{
            origin: {
                city?: string;
                department?: string;
            };
            destination: {
                city?: string;
                department?: string;
            };
            count: number;
            lastSeen: Date;
        }>;
        totalOffers: number;
    }>;
    getStats(): Promise<{
        total: number;
        bySource: Record<string, number>;
        byStatus: Record<string, number>;
        byDepartment: Record<string, number>;
        addedToLeadPool: number;
        withEmail: number;
        withPhone: number;
    }>;
    searchCompanies(filters: {
        search?: string;
        status?: string;
        source?: string;
        department?: string;
        hasEmail?: boolean;
        addedToLeadPool?: boolean;
        page?: number;
        limit?: number;
    }): Promise<{
        companies: ITransportCompany[];
        total: number;
        pages: number;
    }>;
    addToLeadPool(companyIds: string[]): Promise<{
        success: number;
        failed: number;
    }>;
    updateProspectionStatus(companyId: string, status: ITransportCompany['prospectionStatus'], notes?: string): Promise<ITransportCompany | null>;
    deleteCompany(companyId: string): Promise<boolean>;
    exportToCSV(filters?: {
        status?: string;
        source?: string;
        department?: string;
    }): Promise<string>;
    importFromCSV(jobId: string, data: Array<{
        companyName: string;
        email?: string;
        phone?: string;
        city?: string;
        postalCode?: string;
        services?: string;
        vehicleTypes?: string;
        siret?: string;
    }>, sourceName: string): Promise<void>;
}
export declare const transportScrapingService: TransportScrapingService;
export {};
//# sourceMappingURL=transport-scraping-service.d.ts.map