"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const CrmCommercialSchema = new mongoose_1.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    telephone: String,
    type: {
        type: String,
        enum: ['internal', 'external'],
        default: 'internal'
    },
    status: {
        type: String,
        enum: ['active', 'inactive', 'on_leave'],
        default: 'active'
    },
    region: String,
    specialisation: [String],
    objectifMensuel: { type: Number, default: 50 },
    linkedinUrl: String,
    avatar: String,
    notes: String,
    dateEmbauche: Date,
    // Authentification portail commercial
    accessCode: { type: String, unique: true, sparse: true },
    passwordHash: String,
    tempPassword: String,
    mustChangePassword: { type: Boolean, default: true },
    lastLogin: Date,
    loginAttempts: { type: Number, default: 0 },
    lockedUntil: Date,
    commissionConfig: {
        tauxConversion: { type: Number, default: 50 }, // 50 EUR par lead converti
        tauxSignature: { type: Number, default: 200 }, // 200 EUR par contrat signe
        tauxRecurrent: { type: Number, default: 5 }, // 5% sur revenu recurrent
        bonusObjectif: { type: Number, default: 500 } // 500 EUR si objectif atteint
    },
    stats: {
        leadsAssignes: { type: Number, default: 0 },
        leadsConverts: { type: Number, default: 0 },
        leadsEnCours: { type: Number, default: 0 },
        tauxConversion: { type: Number, default: 0 },
        commissionsTotal: { type: Number, default: 0 },
        commissionsPending: { type: Number, default: 0 }
    }
}, {
    timestamps: true
});
// Generer un code d'acces unique
CrmCommercialSchema.methods.generateAccessCode = function () {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'COM-';
    for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
};
// Comparer le mot de passe
CrmCommercialSchema.methods.comparePassword = async function (password) {
    if (!this.passwordHash)
        return false;
    return bcryptjs_1.default.compare(password, this.passwordHash);
};
// Hash le mot de passe avant sauvegarde
CrmCommercialSchema.pre('save', async function (next) {
    if (this.isModified('tempPassword') && this.tempPassword) {
        this.passwordHash = await bcryptjs_1.default.hash(this.tempPassword, 10);
    }
    // Generer accessCode si pas present
    if (!this.accessCode) {
        let code;
        let exists = true;
        while (exists) {
            code = 'COM-';
            const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
            for (let i = 0; i < 6; i++) {
                code += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            exists = await mongoose_1.default.model('CrmCommercial').exists({ accessCode: code });
        }
        this.accessCode = code;
    }
    next();
});
CrmCommercialSchema.index({ email: 1 });
CrmCommercialSchema.index({ accessCode: 1 });
CrmCommercialSchema.index({ status: 1 });
CrmCommercialSchema.index({ type: 1 });
exports.default = mongoose_1.default.model('CrmCommercial', CrmCommercialSchema);
//# sourceMappingURL=CrmCommercial.js.map