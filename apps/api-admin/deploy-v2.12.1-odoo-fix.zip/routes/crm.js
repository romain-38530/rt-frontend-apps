"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * CRM Routes - Lead Generation & Management
 */
const express_1 = require("express");
const LeadSalon_1 = __importDefault(require("../models/LeadSalon"));
const LeadCompany_1 = __importDefault(require("../models/LeadCompany"));
const LeadContact_1 = __importDefault(require("../models/LeadContact"));
const LeadEmail_1 = __importDefault(require("../models/LeadEmail"));
const LeadEmailTemplate_1 = __importDefault(require("../models/LeadEmailTemplate"));
const LeadInteraction_1 = __importDefault(require("../models/LeadInteraction"));
const CrmCommercial_1 = __importDefault(require("../models/CrmCommercial"));
const CrmCommission_1 = __importDefault(require("../models/CrmCommission"));
const lemlist_service_1 = __importDefault(require("../services/lemlist-service"));
const email_service_1 = __importDefault(require("../services/email-service"));
const scraping_service_1 = __importStar(require("../services/scraping-service"));
const salon_discovery_service_1 = __importDefault(require("../services/salon-discovery-service"));
const lead_enrichment_service_1 = __importDefault(require("../services/lead-enrichment-service"));
const odoo_service_1 = __importDefault(require("../services/odoo-service"));
const CommercialMeeting_1 = __importDefault(require("../models/CommercialMeeting"));
const CommercialAvailability_1 = __importDefault(require("../models/CommercialAvailability"));
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// Apply auth middleware to all routes except webhook
router.use((req, res, next) => {
    // Allow webhook without auth
    if (req.path === '/emails/webhook' || req.path === '/migrate-to-pool' || req.path === '/enrich-existing-leads' || req.path === '/leads/sial' || req.path === '/enrich-pool' || req.path === '/cleanup-products' || req.path.startsWith('/odoo/')) {
        return next();
    }
    return (0, auth_1.authenticateAdmin)(req, res, next);
});
// ==================== DASHBOARD ====================
router.get('/dashboard', async (req, res) => {
    try {
        const now = new Date();
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const [totalCompanies, totalContacts, companiesThisWeek, contactsThisWeek, emailsSent, emailsOpened, companiesByStatus, companiesByCountry, recentInteractions] = await Promise.all([
            LeadCompany_1.default.countDocuments(),
            LeadContact_1.default.countDocuments(),
            LeadCompany_1.default.countDocuments({ createdAt: { $gte: weekAgo } }),
            LeadContact_1.default.countDocuments({ createdAt: { $gte: weekAgo } }),
            LeadEmail_1.default.countDocuments({ dateEnvoi: { $gte: monthAgo } }),
            LeadEmail_1.default.countDocuments({ dateEnvoi: { $gte: monthAgo }, statutEnvoi: 'OPENED' }),
            LeadCompany_1.default.aggregate([
                { $group: { _id: '$statutProspection', count: { $sum: 1 } } }
            ]),
            LeadCompany_1.default.aggregate([
                { $group: { _id: '$adresse.pays', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ]),
            LeadInteraction_1.default.find()
                .sort({ createdAt: -1 })
                .limit(20)
                .populate('entrepriseId', 'raisonSociale')
                .populate('contactId', 'prenom nom')
        ]);
        const openRate = emailsSent > 0 ? ((emailsOpened / emailsSent) * 100).toFixed(1) : 0;
        res.json({
            stats: {
                totalCompanies,
                totalContacts,
                companiesThisWeek,
                contactsThisWeek,
                emailsSent,
                emailsOpened,
                openRate: `${openRate}%`
            },
            companiesByStatus,
            companiesByCountry,
            recentInteractions
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== MIGRATION - Temporaire pour ajouter tous les leads au pool ====================
router.post('/migrate-to-pool', async (_req, res) => {
    try {
        // Mettre tous les leads qui ne sont pas dans le pool
        const result = await LeadCompany_1.default.updateMany({ inPool: { $ne: true }, commercialAssigneId: { $exists: false } }, { $set: { inPool: true, dateAddedToPool: new Date(), prioritePool: 3 } });
        res.json({ success: true, modified: result.modifiedCount, matched: result.matchedCount });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Route pour enrichir les leads existants avec adresses, tel, email depuis leurs pages exposant
router.post('/enrich-existing-leads', async (_req, res) => {
    try {
        const leadsToEnrich = await LeadCompany_1.default.find({
            urlPageExposant: { $exists: true, $ne: null },
            $or: [
                { 'adresse.ligne1': { $exists: false } },
                { 'adresse.ligne1': null },
                { telephone: { $exists: false } },
                { emailGenerique: { $exists: false } }
            ]
        }).limit(50);
        if (leadsToEnrich.length === 0) {
            return res.json({ success: true, message: 'Aucun lead a enrichir', enriched: 0 });
        }
        console.log('[CRM] Enriching ' + leadsToEnrich.length + ' existing leads...');
        const browser = await scraping_service_1.default.initBrowser();
        const page = await browser.newPage();
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        let enrichedCount = 0;
        for (const lead of leadsToEnrich) {
            try {
                await page.goto(lead.urlPageExposant, { waitUntil: 'networkidle2', timeout: 20000 });
                await new Promise(r => setTimeout(r, 2000));
                const details = await page.evaluate(() => {
                    const result = {};
                    // Adresse
                    const addrEl = document.querySelector('[class*="address"], [class*="adresse"], .contact-info');
                    if (addrEl?.textContent) {
                        const lines = addrEl.textContent.trim().split('\n').map((l) => l.trim()).filter((l) => l);
                        for (const line of lines) {
                            const cpMatch = line.match(/(\d{5})\s+(.+)/);
                            if (cpMatch) {
                                result.codePostal = cpMatch[1];
                                result.ville = cpMatch[2];
                            }
                            else if (!result.rue && line.length > 5 && line.length < 100)
                                result.rue = line;
                        }
                    }
                    // Tel
                    const telEl = document.querySelector('a[href^="tel:"]');
                    if (telEl)
                        result.telephone = telEl.getAttribute('href')?.replace('tel:', '');
                    // Email
                    const emailEl = document.querySelector('a[href^="mailto:"]');
                    if (emailEl)
                        result.email = emailEl.getAttribute('href')?.replace('mailto:', '');
                    // Produits
                    const produits = [];
                    document.querySelectorAll('[class*="product"], [class*="category"]').forEach((el) => {
                        const t = el.textContent?.trim();
                        if (t && t.length > 2 && t.length < 100)
                            produits.push(t);
                    });
                    if (produits.length > 0)
                        result.produits = produits.slice(0, 10);
                    return result;
                });
                const updateData = {};
                if (details.rue)
                    updateData['adresse.ligne1'] = details.rue;
                if (details.codePostal)
                    updateData['adresse.codePostal'] = details.codePostal;
                if (details.ville)
                    updateData['adresse.ville'] = details.ville;
                if (details.telephone)
                    updateData.telephone = details.telephone;
                if (details.email)
                    updateData.emailGenerique = details.email;
                if (details.produits)
                    updateData.produits = details.produits;
                if (Object.keys(updateData).length > 0) {
                    await LeadCompany_1.default.findByIdAndUpdate(lead._id, { $set: updateData });
                    enrichedCount++;
                }
                await new Promise(r => setTimeout(r, 500));
            }
            catch (e) {
                console.error('[CRM] Error enriching:', e.message);
            }
        }
        await page.close();
        res.json({ success: true, total: leadsToEnrich.length, enriched: enrichedCount });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Route pour supprimer tous les leads d'un salon (pour re-scraper)
router.delete('/leads/by-salon/:salonId', async (req, res) => {
    try {
        const { salonId } = req.params;
        const result = await LeadCompany_1.default.deleteMany({ salonSourceId: salonId });
        res.json({ success: true, deleted: result.deletedCount });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Route pour supprimer tous les leads SIAL
router.delete('/leads/sial', async (req, res) => {
    try {
        // Trouver les salons SIAL
        const sialSalons = await LeadSalon_1.default.find({ nom: /SIAL/i });
        const salonIds = sialSalons.map(s => s._id);
        const result = await LeadCompany_1.default.deleteMany({ salonSourceId: { $in: salonIds } });
        res.json({ success: true, deleted: result.deletedCount, salons: sialSalons.length });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Trigger SIAL scraping (public route for testing)
router.post('/leads/sial', async (req, res) => {
    try {
        // Find SIAL salon
        const salon = await LeadSalon_1.default.findOne({ nom: /SIAL/i, urlListeExposants: { $exists: true, $ne: '' } });
        if (!salon)
            return res.status(404).json({ error: 'No SIAL salon found with exhibitor URL' });
        // Update status
        salon.statutScraping = 'EN_COURS';
        salon.derniereExecution = new Date();
        await salon.save();
        // Start scraping with SIAL adapter
        const result = await scraping_service_1.default.scrapeUrl(salon.urlListeExposants, 'SIAL', {
            maxPages: 50,
            delay: 2000
        });
        if (result.success && result.companies.length > 0) {
            let created = 0;
            let duplicates = 0;
            for (const company of result.companies) {
                try {
                    const escapedName = company.raisonSociale.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    const existingCompany = await LeadCompany_1.default.findOne({
                        $or: [
                            { raisonSociale: { $regex: `^${escapedName}$`, $options: 'i' } },
                            ...(company.siteWeb ? [{ siteWeb: { $regex: company.siteWeb.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' } }] : [])
                        ]
                    });
                    if (existingCompany) {
                        duplicates++;
                        continue;
                    }
                    const paysValue = company.pays || scraping_service_1.ScrapingService.guessCountry(company.raisonSociale + ' ' + (company.ville || '')) || 'France';
                    await LeadCompany_1.default.create({
                        raisonSociale: company.raisonSociale,
                        siteWeb: company.siteWeb,
                        adresse: {
                            ligne1: company.rue,
                            ville: company.ville,
                            codePostal: company.codePostal,
                            pays: paysValue
                        },
                        produits: company.produits,
                        telephone: company.telephone,
                        emailGenerique: company.email,
                        secteurActivite: company.secteurActivite || 'Agroalimentaire',
                        descriptionActivite: company.descriptionActivite,
                        salonSourceId: salon._id,
                        urlPageExposant: company.urlPageExposant,
                        numeroStand: company.numeroStand,
                        statutProspection: 'NEW',
                        inPool: true,
                        dateAddedToPool: new Date(),
                        prioritePool: 3
                    });
                    created++;
                }
                catch (companyError) {
                    console.error(`[SIAL] Error creating company ${company.raisonSociale}:`, companyError.message);
                }
            }
            salon.statutScraping = 'TERMINE';
            salon.nbExposantsCollectes = (salon.nbExposantsCollectes || 0) + created;
            await salon.save();
            res.json({
                success: true,
                salon: salon.nom,
                created,
                duplicates,
                scraped: result.totalScraped,
                duration: result.duration
            });
        }
        else {
            salon.statutScraping = 'ERREUR';
            await salon.save();
            res.json({
                success: false,
                error: result.errors.join(', '),
                scraped: result.totalScraped
            });
        }
    }
    catch (error) {
        console.error('[SIAL Scrape Error]', error);
        res.status(500).json({ error: error.message });
    }
});
// Enrichissement par vagues de 50 entreprises
// Appeler plusieurs fois jusqu'a completion
router.post('/enrich-pool', async (req, res) => {
    const BATCH_SIZE = 50;
    try {
        // Trouver les entreprises qui ont une URL mais pas d'adresse enrichie
        const companiesNeedingEnrichment = await LeadCompany_1.default.find({
            inPool: true,
            urlPageExposant: { $exists: true, $ne: '' },
            $or: [
                { 'adresse.ville': { $exists: false } },
                { 'adresse.ville': '' },
                { 'adresse.ville': null }
            ]
        }).limit(BATCH_SIZE);
        if (companiesNeedingEnrichment.length === 0) {
            // Compter le total pour le rapport
            const totalInPool = await LeadCompany_1.default.countDocuments({ inPool: true });
            const totalWithAddress = await LeadCompany_1.default.countDocuments({
                inPool: true,
                'adresse.ville': { $exists: true, $ne: '' }
            });
            return res.json({
                success: true,
                message: 'Toutes les entreprises sont enrichies!',
                enriched: 0,
                totalInPool,
                totalWithAddress,
                remaining: 0,
                progress: '100%'
            });
        }
        // Lancer Puppeteer pour l'enrichissement (utiliser Chrome systeme sur EB)
        const puppeteer = await Promise.resolve().then(() => __importStar(require('puppeteer')));
        const launchOptions = {
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
        };
        // Use system Chrome on Linux (Elastic Beanstalk)
        if (process.platform === 'linux') {
            launchOptions.executablePath = '/usr/bin/google-chrome-stable';
        }
        const browser = await puppeteer.default.launch(launchOptions);
        const page = await browser.newPage();
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        let enrichedCount = 0;
        const errors = [];
        for (const company of companiesNeedingEnrichment) {
            try {
                console.log(`[Enrich Pool] ${enrichedCount + 1}/${companiesNeedingEnrichment.length}: ${company.raisonSociale}`);
                await page.goto(company.urlPageExposant, { waitUntil: 'domcontentloaded', timeout: 30000 });
                await new Promise(r => setTimeout(r, 2000));
                const details = await page.evaluate(() => {
                    const result = {};
                    const contentText = document.body.innerText;
                    // Methode 1: Code postal francais (5 chiffres) + Ville
                    const cpVilleMatch = contentText.match(/(\d{5})\s+([A-Z][A-Za-zÀ-ÿ\s-]+?)(?:\s*[,\n]|$)/);
                    if (cpVilleMatch) {
                        result.codePostal = cpVilleMatch[1];
                        result.ville = cpVilleMatch[2].trim();
                    }
                    // Methode 2: Chercher "City:" ou "Ville:" explicite
                    if (!result.ville) {
                        const cityMatch = contentText.match(/(?:City|Ville|Ciudad|Stadt)[:\s]+([A-Za-zÀ-ÿ\s-]+?)(?:[,\n]|$)/i);
                        if (cityMatch)
                            result.ville = cityMatch[1].trim();
                    }
                    // Methode 3: Chercher ville apres pays (format: Pays - Ville)
                    if (!result.ville) {
                        const paysVilleMatch = contentText.match(/(?:France|Germany|Turkey|Vietnam|China|USA|UAE|Lithuania|Belgium|Italy|Spain|UK|Netherlands)\s*[-,]\s*([A-Za-zÀ-ÿ\s-]+?)(?:[,\n]|$)/i);
                        if (paysVilleMatch)
                            result.ville = paysVilleMatch[1].trim();
                    }
                    // Methode 4: Chercher n'importe quel format "Localisation: ..."
                    if (!result.ville) {
                        const locMatch = contentText.match(/(?:Location|Localisation|Address|Adresse)[:\s]+([^\n]{5,50})/i);
                        if (locMatch) {
                            result.ville = locMatch[1].trim().split(',')[0].trim();
                        }
                    }
                    // Pays - liste etendue incluant pays internationaux
                    const paysPatterns = [
                        'France', 'Germany', 'Allemagne', 'Italy', 'Italie', 'Spain', 'Espagne',
                        'Belgium', 'Belgique', 'Vietnam', 'China', 'Chine', 'USA', 'United States',
                        'Turkey', 'Turquie', 'Lithuania', 'Lituanie', 'United Arab Emirates', 'UAE',
                        'Abu Dhabi', 'Netherlands', 'Pays-Bas', 'United Kingdom', 'UK', 'Royaume-Uni',
                        'Poland', 'Pologne', 'Portugal', 'Greece', 'Grèce', 'Japan', 'Japon',
                        'South Korea', 'Corée', 'Thailand', 'Thaïlande', 'Indonesia', 'Indonésie',
                        'Brazil', 'Brésil', 'Argentina', 'Argentine', 'Mexico', 'Mexique'
                    ];
                    for (const pays of paysPatterns) {
                        if (contentText.includes(pays)) {
                            result.pays = pays;
                            break;
                        }
                    }
                    // Telephone
                    const telLink = document.querySelector('a[href^="tel:"]');
                    if (telLink) {
                        result.telephone = telLink.getAttribute('href')?.replace('tel:', '').replace(/[\s.-]/g, '');
                    }
                    // Email
                    const emailLink = document.querySelector('a[href^="mailto:"]');
                    if (emailLink) {
                        result.email = emailLink.getAttribute('href')?.replace('mailto:', '').split('?')[0];
                    }
                    // Site web
                    const webLinks = Array.from(document.querySelectorAll('a[href^="http"]'));
                    for (const link of webLinks) {
                        const href = link.href;
                        if (href && !href.includes('sial') && !href.includes('comexposium') && !href.includes('linkedin') && !href.includes('facebook')) {
                            result.siteWeb = href;
                            break;
                        }
                    }
                    return result;
                });
                // Mettre a jour en base
                const updateData = {};
                if (details.ville)
                    updateData['adresse.ville'] = details.ville;
                if (details.codePostal)
                    updateData['adresse.codePostal'] = details.codePostal;
                if (details.pays)
                    updateData['adresse.pays'] = details.pays;
                if (details.telephone && !company.telephone)
                    updateData.telephone = details.telephone;
                if (details.email && !company.emailGenerique)
                    updateData.emailGenerique = details.email;
                if (details.siteWeb && !company.siteWeb)
                    updateData.siteWeb = details.siteWeb;
                if (Object.keys(updateData).length > 0) {
                    await LeadCompany_1.default.findByIdAndUpdate(company._id, { $set: updateData });
                    enrichedCount++;
                }
                await new Promise(r => setTimeout(r, 500));
            }
            catch (e) {
                errors.push(`${company.raisonSociale}: ${e.message}`);
            }
        }
        await browser.close();
        // Stats finales
        const totalNeedingEnrichment = await LeadCompany_1.default.countDocuments({
            inPool: true,
            urlPageExposant: { $exists: true, $ne: '' },
            $or: [
                { 'adresse.ville': { $exists: false } },
                { 'adresse.ville': '' }
            ]
        });
        const totalInPool = await LeadCompany_1.default.countDocuments({ inPool: true });
        const totalWithAddress = await LeadCompany_1.default.countDocuments({
            inPool: true,
            'adresse.ville': { $exists: true, $ne: '' }
        });
        res.json({
            success: true,
            enriched: enrichedCount,
            batch: companiesNeedingEnrichment.length,
            remaining: totalNeedingEnrichment,
            totalInPool,
            totalWithAddress,
            progress: `${Math.round((totalWithAddress / totalInPool) * 100)}%`,
            errors: errors.slice(0, 5),
            message: totalNeedingEnrichment > 0
                ? `Vague terminee! ${totalNeedingEnrichment} entreprises restantes. Relancez dans 2 minutes.`
                : 'Toutes les entreprises sont enrichies!'
        });
    }
    catch (error) {
        console.error('[Enrich Pool Error]', error);
        res.status(500).json({ error: error.message });
    }
});
// ==================== SALONS ====================
router.get('/salons', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, pays, search } = req.query;
        const filter = {};
        if (status)
            filter.statutScraping = status;
        if (pays)
            filter.pays = pays;
        if (search)
            filter.nom = { $regex: search, $options: 'i' };
        const skip = (Number(page) - 1) * Number(limit);
        const [salons, total] = await Promise.all([
            LeadSalon_1.default.find(filter).sort({ dateDebut: -1 }).skip(skip).limit(Number(limit)),
            LeadSalon_1.default.countDocuments(filter)
        ]);
        res.json({ success: true, salons, data: salons, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/salons', async (req, res) => {
    try {
        console.log('[CRM] Creating salon:', JSON.stringify(req.body));
        // Map frontend field names to model field names
        const salonData = {
            nom: req.body.nom,
            edition: req.body.edition,
            pays: req.body.pays,
            lieu: req.body.lieu,
            ville: req.body.ville,
            urlSalon: req.body.url || req.body.urlSalon,
            urlListeExposants: req.body.urlListeExposants,
            dateDebut: req.body.dateDebut || undefined,
            dateFin: req.body.dateFin || undefined,
            adaptateurConfig: req.body.adaptateur ? { type: req.body.adaptateur } : req.body.adaptateurConfig,
            categorie: req.body.categorie,
            sourceDecouverte: req.body.sourceDecouverte
        };
        const salon = new LeadSalon_1.default(salonData);
        await salon.save();
        res.status(201).json({ success: true, salon });
    }
    catch (error) {
        console.error('[CRM] Salon creation error:', error);
        const errorMessage = error.message || (error.errors ? Object.values(error.errors).map((e) => e.message).join(', ') : 'Erreur inconnue');
        res.status(400).json({ success: false, error: errorMessage });
    }
});
router.get('/salons/:id', async (req, res) => {
    try {
        const salon = await LeadSalon_1.default.findById(req.params.id);
        if (!salon)
            return res.status(404).json({ error: 'Salon not found' });
        res.json(salon);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put('/salons/:id', async (req, res) => {
    try {
        const salon = await LeadSalon_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!salon)
            return res.status(404).json({ error: 'Salon not found' });
        res.json(salon);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Lancer le scraping d'un salon
router.post('/salons/:id/scrape', async (req, res) => {
    try {
        const salon = await LeadSalon_1.default.findById(req.params.id);
        if (!salon)
            return res.status(404).json({ error: 'Salon not found' });
        if (!salon.urlListeExposants) {
            return res.status(400).json({ error: 'URL des exposants non configuree pour ce salon' });
        }
        // Mettre a jour le statut
        salon.statutScraping = 'EN_COURS';
        salon.derniereExecution = new Date();
        await salon.save();
        // Determiner l'adaptateur
        const adaptateurConfig = salon.adaptateurConfig || {};
        const adapterName = adaptateurConfig.type || 'Generic';
        const config = {
            maxPages: adaptateurConfig.maxPages || 10,
            delay: adaptateurConfig.delay || 2000
        };
        // Lancer le scraping
        const result = await scraping_service_1.default.scrapeUrl(salon.urlListeExposants, adapterName, config);
        if (result.success && result.companies.length > 0) {
            // Creer les entreprises
            let created = 0;
            let duplicates = 0;
            for (const company of result.companies) {
                try {
                    // Escape special regex characters in company name
                    const escapedName = company.raisonSociale.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    // Verifier si l'entreprise existe deja (par nom ou site web)
                    const existingCompany = await LeadCompany_1.default.findOne({
                        $or: [
                            { raisonSociale: { $regex: `^${escapedName}$`, $options: 'i' } },
                            ...(company.siteWeb ? [{ siteWeb: { $regex: company.siteWeb.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' } }] : [])
                        ]
                    });
                    if (existingCompany) {
                        duplicates++;
                        continue;
                    }
                    // Creer la nouvelle entreprise
                    const paysValue = company.pays || scraping_service_1.ScrapingService.guessCountry(company.raisonSociale + ' ' + (company.ville || '')) || 'France';
                    await LeadCompany_1.default.create({
                        raisonSociale: company.raisonSociale,
                        siteWeb: company.siteWeb,
                        adresse: {
                            ligne1: company.rue,
                            ville: company.ville,
                            codePostal: company.codePostal,
                            pays: paysValue
                        },
                        produits: company.produits,
                        telephone: company.telephone,
                        emailGenerique: company.email,
                        secteurActivite: company.secteurActivite || 'Agroalimentaire',
                        descriptionActivite: company.descriptionActivite,
                        salonSourceId: salon._id,
                        urlPageExposant: company.urlPageExposant,
                        numeroStand: company.numeroStand,
                        statutProspection: 'NEW',
                        // Automatiquement ajouter au pool de leads
                        inPool: true,
                        dateAddedToPool: new Date(),
                        prioritePool: 3 // Priorite moyenne par defaut
                    });
                    created++;
                }
                catch (companyError) {
                    console.error(`[CRM] Error creating company ${company.raisonSociale}:`, companyError.message);
                    // Continue with next company instead of failing entire scraping
                }
            }
            // Mettre a jour le salon
            salon.statutScraping = 'TERMINE';
            salon.nbExposantsCollectes = (salon.nbExposantsCollectes || 0) + created;
            await salon.save();
            // Log scraping result (logged in salon model, no need for separate interaction)
            console.log(`[CRM] Scraping ${salon.nom}: ${created} nouvelles entreprises, ${duplicates} doublons, duree: ${result.duration}ms`);
            // AUTO-ENRICHISSEMENT: Lancer l'enrichissement en arriere-plan
            let enrichmentStatus = { enrichmentStarted: false, message: '' };
            if (created > 0) {
                try {
                    enrichmentStatus = await lead_enrichment_service_1.default.postScrapingEnrichment(salon._id.toString(), Math.min(created, 30));
                    console.log(`[CRM] Post-scraping enrichment: ${enrichmentStatus.message}`);
                }
                catch (e) {
                    console.error('[CRM] Post-scraping enrichment error:', e);
                }
                // AUTO-POOL: Ajouter au pool les entreprises avec site web
                try {
                    const poolResult = await LeadCompany_1.default.updateMany({
                        salonSourceId: salon._id,
                        siteWeb: { $exists: true, $ne: '' },
                        inPool: { $ne: true },
                        commercialAssigneId: { $exists: false }
                    }, {
                        $set: {
                            inPool: true,
                            dateAddedToPool: new Date(),
                            prioritePool: 3
                        }
                    });
                    console.log(`[CRM] Added ${poolResult.modifiedCount} companies to pool`);
                }
                catch (e) {
                    console.error('[CRM] Auto-pool error:', e);
                }
            }
            res.json({
                success: true,
                totalScraped: result.totalScraped,
                companiesCreated: created,
                duplicatesSkipped: duplicates,
                duration: result.duration,
                enrichment: enrichmentStatus
            });
        }
        else {
            salon.statutScraping = 'ERREUR';
            await salon.save();
            res.status(400).json({
                success: false,
                error: result.errors.join(', ') || 'Aucune entreprise trouvee',
                duration: result.duration
            });
        }
    }
    catch (error) {
        // Mettre a jour le statut en cas d'erreur
        try {
            await LeadSalon_1.default.findByIdAndUpdate(req.params.id, { statutScraping: 'ERREUR' });
        }
        catch { }
        res.status(500).json({ error: error.message });
    }
});
// Obtenir les adaptateurs disponibles
router.get('/scraping/adapters', async (req, res) => {
    try {
        const adapters = scraping_service_1.default.getAvailableAdapters();
        res.json({
            adapters: adapters.map(name => ({
                name,
                description: getAdapterDescription(name)
            }))
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Test de scraping (sans sauvegarde)
router.post('/scraping/test', async (req, res) => {
    try {
        const { url, adapter = 'Generic', maxPages = 3 } = req.body;
        if (!url) {
            return res.status(400).json({ error: 'URL requise' });
        }
        const result = await scraping_service_1.default.scrapeUrl(url, adapter, { maxPages });
        res.json({
            success: result.success,
            companies: result.companies.slice(0, 10), // Apercu des 10 premiers
            totalScraped: result.totalScraped,
            errors: result.errors,
            duration: result.duration
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
function getAdapterDescription(name) {
    const descriptions = {
        'SITL': 'Salon International du Transport et de la Logistique (Paris)',
        'TransportLogistic': 'Transport Logistic Munich',
        'Generic': 'Adaptateur generique pour sites avec liste d\'exposants standard'
    };
    return descriptions[name] || 'Adaptateur personnalise';
}
// ==================== COMPANIES ====================
router.get('/companies', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, pays, secteur, search, commercialId, salonId } = req.query;
        const filter = {};
        if (status)
            filter.statutProspection = status;
        if (pays)
            filter['adresse.pays'] = pays;
        if (secteur)
            filter.secteurActivite = secteur;
        if (commercialId)
            filter.commercialAssigneId = commercialId;
        if (salonId)
            filter.salonSourceId = salonId;
        if (search) {
            filter.$or = [
                { raisonSociale: { $regex: search, $options: 'i' } },
                { siteWeb: { $regex: search, $options: 'i' } }
            ];
        }
        const skip = (Number(page) - 1) * Number(limit);
        const [companies, total] = await Promise.all([
            LeadCompany_1.default.find(filter)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('salonSourceId', 'nom')
                .populate('commercialAssigneId', 'firstName lastName'),
            LeadCompany_1.default.countDocuments(filter)
        ]);
        res.json({ data: companies, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/companies', async (req, res) => {
    try {
        const company = new LeadCompany_1.default(req.body);
        await company.save();
        // Créer interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            typeInteraction: 'CREATION',
            description: 'Entreprise créée',
            createdBy: 'system'
        });
        res.status(201).json(company);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.get('/companies/:id', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id)
            .populate('salonSourceId', 'nom')
            .populate('commercialAssigneId', 'firstName lastName email');
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        // Récupérer contacts et interactions
        const [contacts, interactions, emails] = await Promise.all([
            LeadContact_1.default.find({ entrepriseId: company._id }).sort({ estContactPrincipal: -1 }),
            LeadInteraction_1.default.find({ entrepriseId: company._id }).sort({ createdAt: -1 }).limit(50),
            LeadEmail_1.default.find({ entrepriseId: company._id }).sort({ dateEnvoi: -1 }).limit(20)
        ]);
        res.json({ company, contacts, interactions, emails });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put('/companies/:id', async (req, res) => {
    try {
        const oldCompany = await LeadCompany_1.default.findById(req.params.id);
        const company = await LeadCompany_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        // Log changement de statut
        if (oldCompany && oldCompany.statutProspection !== company.statutProspection) {
            await LeadInteraction_1.default.create({
                entrepriseId: company._id,
                typeInteraction: 'CHANGEMENT_STATUT',
                description: `Statut: ${oldCompany.statutProspection} → ${company.statutProspection}`,
                createdBy: 'admin'
            });
        }
        res.json(company);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Enrichir une entreprise (methodes gratuites + Lemlist optionnel)
router.post('/companies/:id/enrich', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id);
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        const fieldsEnriched = [];
        let source = 'none';
        // 1. D'abord essayer SIRENE pour les entreprises francaises
        if (!company.adresse?.pays || ['France', 'FR', 'Italia', 'IT', 'Italy'].includes(company.adresse?.pays || '')) {
            try {
                const searchQuery = encodeURIComponent(company.raisonSociale);
                const sireneResponse = await fetch(`https://recherche-entreprises.api.gouv.fr/search?q=${searchQuery}&per_page=1`, { headers: { 'Accept': 'application/json' } });
                if (sireneResponse.ok) {
                    const data = await sireneResponse.json();
                    if (data.results && data.results.length > 0) {
                        const entreprise = data.results[0];
                        const siege = entreprise.siege;
                        if (siege?.siret && !company.siret) {
                            company.siret = siege.siret;
                            fieldsEnriched.push('siret');
                        }
                        if (siege?.adresse && !company.adresse?.ligne1) {
                            if (!company.adresse)
                                company.adresse = { pays: 'France' };
                            company.adresse.ligne1 = siege.adresse;
                            fieldsEnriched.push('adresse');
                        }
                        if (siege?.code_postal && !company.adresse?.codePostal) {
                            if (!company.adresse)
                                company.adresse = { pays: 'France' };
                            company.adresse.codePostal = siege.code_postal;
                            fieldsEnriched.push('codePostal');
                        }
                        if (siege?.libelle_commune && !company.adresse?.ville) {
                            if (!company.adresse)
                                company.adresse = { pays: 'France' };
                            company.adresse.ville = siege.libelle_commune;
                            fieldsEnriched.push('ville');
                        }
                        if (entreprise.activite_principale && !company.secteurActivite) {
                            company.secteurActivite = entreprise.activite_principale;
                            fieldsEnriched.push('secteurActivite');
                        }
                        if (fieldsEnriched.length > 0) {
                            source = 'sirene';
                            await company.save();
                        }
                    }
                }
            }
            catch (e) {
                console.log('[Enrich] SIRENE error:', e);
            }
        }
        // 2. Si site web disponible, scraper pour plus d'infos
        if (company.siteWeb) {
            try {
                const puppeteer = await Promise.resolve().then(() => __importStar(require('puppeteer')));
                const launchOptions = {
                    headless: true,
                    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
                };
                if (process.platform === 'linux') {
                    launchOptions.executablePath = '/usr/bin/google-chrome-stable';
                }
                const browser = await puppeteer.default.launch(launchOptions);
                const page = await browser.newPage();
                await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
                const baseUrl = company.siteWeb.startsWith('http') ? company.siteWeb : `https://${company.siteWeb}`;
                await page.goto(baseUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });
                // Extraire infos de la page
                const data = await page.evaluate(() => {
                    const result = {};
                    const text = document.body.innerText;
                    const html = document.body.innerHTML;
                    // Email
                    const emailMatch = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
                    if (emailMatch && !emailMatch[0].includes('example') && !emailMatch[0].includes('sentry')) {
                        result.email = emailMatch[0];
                    }
                    // Telephone
                    const telPatterns = [
                        /(?:Tel|Phone|Telephone|T)[.:\s]*(\+?[\d\s.-]{10,20})/i,
                        /(\+33[\s.-]?\d[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2})/,
                        /(\+39[\s.-]?\d{2,3}[\s.-]?\d{6,7})/,
                        /(0[1-9][\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2})/
                    ];
                    for (const pattern of telPatterns) {
                        const match = text.match(pattern);
                        if (match) {
                            result.telephone = match[1].replace(/[\s.-]/g, '');
                            break;
                        }
                    }
                    // Adresse
                    const adresseMatch = text.match(/(\d{1,3}[,\s]+(?:rue|avenue|boulevard|place|via|viale|piazza|corso)[^,\n]{5,50})/i);
                    if (adresseMatch)
                        result.adresse = adresseMatch[1].trim();
                    const cpVilleMatch = text.match(/(\d{5})\s+([A-Z][A-Za-zÀ-ÿ\s-]+?)(?:\s*[,\n]|$)/);
                    if (cpVilleMatch) {
                        result.codePostal = cpVilleMatch[1];
                        result.ville = cpVilleMatch[2].trim();
                    }
                    // LinkedIn
                    const linkedinMatch = html.match(/href=["'](https?:\/\/(?:www\.)?linkedin\.com\/company\/[^"']+)["']/i);
                    if (linkedinMatch)
                        result.linkedin = linkedinMatch[1];
                    return result;
                });
                await browser.close();
                // Mettre a jour
                if (data.email && !company.emailGenerique) {
                    company.emailGenerique = data.email;
                    fieldsEnriched.push('email');
                }
                if (data.telephone && !company.telephone) {
                    company.telephone = data.telephone;
                    fieldsEnriched.push('telephone');
                }
                if (data.adresse && !company.adresse?.ligne1) {
                    if (!company.adresse)
                        company.adresse = { pays: 'France' };
                    company.adresse.ligne1 = data.adresse;
                    fieldsEnriched.push('adresse');
                }
                if (data.ville && !company.adresse?.ville) {
                    if (!company.adresse)
                        company.adresse = { pays: 'France' };
                    company.adresse.ville = data.ville;
                    fieldsEnriched.push('ville');
                }
                if (data.codePostal && !company.adresse?.codePostal) {
                    if (!company.adresse)
                        company.adresse = { pays: 'France' };
                    company.adresse.codePostal = data.codePostal;
                    fieldsEnriched.push('codePostal');
                }
                if (data.linkedin && !company.linkedinCompanyUrl) {
                    company.linkedinCompanyUrl = data.linkedin;
                    fieldsEnriched.push('linkedin');
                }
                if (fieldsEnriched.length > 0) {
                    source = source === 'sirene' ? 'sirene+website' : 'website';
                    await company.save();
                }
            }
            catch (e) {
                console.log('[Enrich] Website scraping error:', e);
            }
        }
        // 3. Optionnel: Lemlist pour les contacts (si domaine disponible)
        let contactsCreated = 0;
        if (company.siteWeb) {
            try {
                let domain;
                try {
                    domain = new URL(company.siteWeb.startsWith('http') ? company.siteWeb : `https://${company.siteWeb}`).hostname.replace('www.', '');
                }
                catch {
                    domain = company.siteWeb.replace('www.', '').split('/')[0];
                }
                const { company: enrichedCompany, contacts } = await lemlist_service_1.default.enrichCompany(domain);
                if (enrichedCompany) {
                    company.lemlistData = enrichedCompany;
                    company.dateEnrichissement = new Date();
                    if (enrichedCompany.linkedinUrl && !company.linkedinCompanyUrl) {
                        company.linkedinCompanyUrl = enrichedCompany.linkedinUrl;
                        fieldsEnriched.push('linkedin');
                    }
                    await company.save();
                }
                for (const lemlistContact of contacts) {
                    if (!lemlistContact.email)
                        continue;
                    const existingContact = await LeadContact_1.default.findOne({
                        entrepriseId: company._id,
                        email: lemlistContact.email.toLowerCase()
                    });
                    if (!existingContact) {
                        await LeadContact_1.default.create({
                            entrepriseId: company._id,
                            prenom: lemlistContact.firstName,
                            nom: lemlistContact.lastName,
                            poste: lemlistContact.position,
                            email: lemlistContact.email.toLowerCase(),
                            emailStatus: lemlist_service_1.default.mapEmailStatus(lemlistContact.enrichmentStatus),
                            linkedinUrl: lemlistContact.linkedinUrl,
                            telephoneDirect: lemlistContact.phone,
                            seniority: lemlist_service_1.default.mapSeniority(lemlistContact.position),
                            sourceEnrichissement: 'LEMLIST',
                            dateEnrichissement: new Date()
                        });
                        contactsCreated++;
                    }
                }
            }
            catch (e) {
                console.log('[Enrich] Lemlist error:', e);
            }
        }
        // Mettre a jour le statut
        if (fieldsEnriched.length > 0) {
            company.statutProspection = 'ENRICHED';
            await company.save();
        }
        // Log interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            typeInteraction: 'ENRICHISSEMENT',
            description: `Enrichissement (${source}): ${fieldsEnriched.length} champs, ${contactsCreated} contacts`,
            metadata: { source, fieldsEnriched, contactsCreated },
            createdBy: 'system'
        });
        // Recharger avec populate
        const updatedCompany = await LeadCompany_1.default.findById(company._id)
            .populate('salonSourceId', 'nom')
            .populate('commercialAssigneId', 'firstName lastName email');
        res.json({
            success: true,
            company: updatedCompany,
            fieldsEnriched,
            contactsCreated,
            source
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Enrichir une entreprise - GRATUIT (SIRENE + Website scraping)
router.post('/companies/:id/enrich-free', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id);
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        const fieldsEnriched = [];
        let source = 'none';
        // 1. SIRENE pour les entreprises (fonctionne meme pour certaines entreprises etrangeres)
        try {
            const searchQuery = encodeURIComponent(company.raisonSociale);
            const sireneResponse = await fetch(`https://recherche-entreprises.api.gouv.fr/search?q=${searchQuery}&per_page=1`, { headers: { 'Accept': 'application/json' } });
            if (sireneResponse.ok) {
                const data = await sireneResponse.json();
                if (data.results && data.results.length > 0) {
                    const entreprise = data.results[0];
                    const siege = entreprise.siege;
                    if (siege?.siret && !company.siret) {
                        company.siret = siege.siret;
                        fieldsEnriched.push('siret');
                    }
                    if (siege?.adresse && !company.adresse?.ligne1) {
                        if (!company.adresse)
                            company.adresse = { pays: 'France' };
                        company.adresse.ligne1 = siege.adresse;
                        fieldsEnriched.push('adresse');
                    }
                    if (siege?.code_postal && !company.adresse?.codePostal) {
                        if (!company.adresse)
                            company.adresse = { pays: 'France' };
                        company.adresse.codePostal = siege.code_postal;
                        fieldsEnriched.push('codePostal');
                    }
                    if (siege?.libelle_commune && !company.adresse?.ville) {
                        if (!company.adresse)
                            company.adresse = { pays: 'France' };
                        company.adresse.ville = siege.libelle_commune;
                        fieldsEnriched.push('ville');
                    }
                    if (entreprise.activite_principale && !company.secteurActivite) {
                        company.secteurActivite = entreprise.activite_principale;
                        fieldsEnriched.push('secteurActivite');
                    }
                    if (fieldsEnriched.length > 0) {
                        source = 'sirene';
                        await company.save();
                    }
                }
            }
        }
        catch (e) {
            console.log('[Enrich-Free] SIRENE error:', e);
        }
        // 2. Si site web disponible, scraper pour plus d'infos
        if (company.siteWeb) {
            try {
                const puppeteer = await Promise.resolve().then(() => __importStar(require('puppeteer')));
                const launchOptions = {
                    headless: true,
                    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
                };
                if (process.platform === 'linux') {
                    launchOptions.executablePath = '/usr/bin/google-chrome-stable';
                }
                const browser = await puppeteer.default.launch(launchOptions);
                const page = await browser.newPage();
                await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
                const baseUrl = company.siteWeb.startsWith('http') ? company.siteWeb : `https://${company.siteWeb}`;
                await page.goto(baseUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });
                const data = await page.evaluate(() => {
                    const result = {};
                    const text = document.body.innerText;
                    const html = document.body.innerHTML;
                    const emailMatch = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
                    if (emailMatch && !emailMatch[0].includes('example') && !emailMatch[0].includes('sentry')) {
                        result.email = emailMatch[0];
                    }
                    const telPatterns = [
                        /(?:Tel|Phone|Telephone|T)[.:\s]*(\+?[\d\s.-]{10,20})/i,
                        /(\+33[\s.-]?\d[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2})/,
                        /(\+39[\s.-]?\d{2,3}[\s.-]?\d{6,7})/,
                        /(0[1-9][\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2})/
                    ];
                    for (const pattern of telPatterns) {
                        const match = text.match(pattern);
                        if (match) {
                            result.telephone = match[1].replace(/[\s.-]/g, '');
                            break;
                        }
                    }
                    const adresseMatch = text.match(/(\d{1,3}[,\s]+(?:rue|avenue|boulevard|place|via|viale|piazza|corso)[^,\n]{5,50})/i);
                    if (adresseMatch)
                        result.adresse = adresseMatch[1].trim();
                    const cpVilleMatch = text.match(/(\d{5})\s+([A-Z][A-Za-zÀ-ÿ\s-]+?)(?:\s*[,\n]|$)/);
                    if (cpVilleMatch) {
                        result.codePostal = cpVilleMatch[1];
                        result.ville = cpVilleMatch[2].trim();
                    }
                    const linkedinMatch = html.match(/href=["'](https?:\/\/(?:www\.)?linkedin\.com\/company\/[^"']+)["']/i);
                    if (linkedinMatch)
                        result.linkedin = linkedinMatch[1];
                    return result;
                });
                await browser.close();
                if (data.email && !company.emailGenerique) {
                    company.emailGenerique = data.email;
                    fieldsEnriched.push('email');
                }
                if (data.telephone && !company.telephone) {
                    company.telephone = data.telephone;
                    fieldsEnriched.push('telephone');
                }
                if (data.adresse && !company.adresse?.ligne1) {
                    if (!company.adresse)
                        company.adresse = { pays: 'France' };
                    company.adresse.ligne1 = data.adresse;
                    fieldsEnriched.push('adresse');
                }
                if (data.ville && !company.adresse?.ville) {
                    if (!company.adresse)
                        company.adresse = { pays: 'France' };
                    company.adresse.ville = data.ville;
                    fieldsEnriched.push('ville');
                }
                if (data.codePostal && !company.adresse?.codePostal) {
                    if (!company.adresse)
                        company.adresse = { pays: 'France' };
                    company.adresse.codePostal = data.codePostal;
                    fieldsEnriched.push('codePostal');
                }
                if (data.linkedin && !company.linkedinCompanyUrl) {
                    company.linkedinCompanyUrl = data.linkedin;
                    fieldsEnriched.push('linkedin');
                }
                if (fieldsEnriched.length > 0) {
                    source = source === 'sirene' ? 'sirene+website' : 'website';
                    await company.save();
                }
            }
            catch (e) {
                console.log('[Enrich-Free] Website scraping error:', e);
            }
        }
        if (fieldsEnriched.length > 0) {
            company.statutProspection = 'ENRICHED';
            await company.save();
        }
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            typeInteraction: 'ENRICHISSEMENT',
            description: `Enrichissement gratuit (${source}): ${fieldsEnriched.length} champs`,
            metadata: { source, fieldsEnriched },
            createdBy: 'system'
        });
        const updatedCompany = await LeadCompany_1.default.findById(company._id)
            .populate('salonSourceId', 'nom')
            .populate('commercialAssigneId', 'firstName lastName email');
        res.json({
            success: true,
            company: updatedCompany,
            fieldsEnriched,
            source
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Enrichir une entreprise - PAYANT (Lemlist)
router.post('/companies/:id/enrich-paid', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id);
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        if (!company.siteWeb) {
            return res.status(400).json({ error: 'Site web requis pour enrichissement Lemlist' });
        }
        let domain;
        try {
            domain = new URL(company.siteWeb.startsWith('http') ? company.siteWeb : `https://${company.siteWeb}`).hostname.replace('www.', '');
        }
        catch {
            domain = company.siteWeb.replace('www.', '').split('/')[0];
        }
        const { company: enrichedCompany, contacts } = await lemlist_service_1.default.enrichCompany(domain);
        const fieldsEnriched = [];
        if (enrichedCompany) {
            company.lemlistData = enrichedCompany;
            company.dateEnrichissement = new Date();
            if (enrichedCompany.linkedinUrl && !company.linkedinCompanyUrl) {
                company.linkedinCompanyUrl = enrichedCompany.linkedinUrl;
                fieldsEnriched.push('linkedin');
            }
            company.statutProspection = 'ENRICHED';
            await company.save();
        }
        const createdContacts = [];
        for (const lemlistContact of contacts) {
            // Skip si pas de nom
            if (!lemlistContact.firstName && !lemlistContact.lastName)
                continue;
            // Verifier si contact existe deja (par email OU par nom+linkedin)
            let existingContact = null;
            if (lemlistContact.email) {
                existingContact = await LeadContact_1.default.findOne({
                    entrepriseId: company._id,
                    email: lemlistContact.email.toLowerCase()
                });
            }
            if (!existingContact && lemlistContact.linkedinUrl) {
                existingContact = await LeadContact_1.default.findOne({
                    entrepriseId: company._id,
                    linkedinUrl: lemlistContact.linkedinUrl
                });
            }
            if (!existingContact && lemlistContact.firstName && lemlistContact.lastName) {
                existingContact = await LeadContact_1.default.findOne({
                    entrepriseId: company._id,
                    prenom: lemlistContact.firstName,
                    nom: lemlistContact.lastName
                });
            }
            if (!existingContact) {
                const contact = await LeadContact_1.default.create({
                    entrepriseId: company._id,
                    prenom: lemlistContact.firstName,
                    nom: lemlistContact.lastName,
                    poste: lemlistContact.position,
                    email: lemlistContact.email ? lemlistContact.email.toLowerCase() : undefined,
                    emailStatus: lemlistContact.email ? lemlist_service_1.default.mapEmailStatus(lemlistContact.enrichmentStatus) : 'UNKNOWN',
                    linkedinUrl: lemlistContact.linkedinUrl,
                    telephoneDirect: lemlistContact.phone,
                    seniority: lemlist_service_1.default.mapSeniority(lemlistContact.position),
                    sourceEnrichissement: 'LEMLIST',
                    dateEnrichissement: new Date()
                });
                createdContacts.push(contact);
            }
        }
        if (createdContacts.length > 0) {
            const hasMainContact = await LeadContact_1.default.findOne({
                entrepriseId: company._id,
                estContactPrincipal: true
            });
            if (!hasMainContact) {
                createdContacts[0].estContactPrincipal = true;
                await createdContacts[0].save();
            }
        }
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            typeInteraction: 'ENRICHISSEMENT',
            description: `Enrichissement Lemlist: ${createdContacts.length} contacts trouves`,
            metadata: { domain, contactsCount: createdContacts.length },
            createdBy: 'system'
        });
        const updatedCompany = await LeadCompany_1.default.findById(company._id)
            .populate('salonSourceId', 'nom')
            .populate('commercialAssigneId', 'firstName lastName email');
        res.json({
            success: true,
            company: updatedCompany,
            contactsCreated: createdContacts.length,
            contacts: createdContacts
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Assigner un commercial
router.post('/companies/:id/assign', async (req, res) => {
    try {
        const { commercialId } = req.body;
        const company = await LeadCompany_1.default.findByIdAndUpdate(req.params.id, {
            commercialAssigneId: commercialId,
            dateAssignation: new Date()
        }, { new: true }).populate('commercialAssigneId', 'firstName lastName');
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            commercialId,
            typeInteraction: 'ASSIGNATION',
            description: 'Commercial assigné',
            createdBy: 'admin'
        });
        res.json(company);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Nettoyer les faux leads (produits au lieu d'entreprises)
router.post('/cleanup-products', async (req, res) => {
    try {
        // Patterns de produits a supprimer
        const productPatterns = [
            /\d+\s*(g|kg|ml|cl|l|oz|lb|pcs)\b/i, // Quantites
            /^(confiture|chocolat|biscuit|gateau|pain|fromage|vin|huile|sauce|soupe|jus|the|cafe|miel|sucre)/i,
            /\b(rhubarbe|noix|noisette|amande|pistache|fraise|framboise|cerise|pomme|poire|orange|citron|vanille|caramel)\b.*\b(extra|bio|premium|deluxe)\b/i,
        ];
        // Trouver toutes les entreprises dans le pool
        const allCompanies = await LeadCompany_1.default.find({ inPool: true });
        const toDelete = [];
        for (const company of allCompanies) {
            const name = company.raisonSociale.toLowerCase();
            for (const pattern of productPatterns) {
                if (pattern.test(name)) {
                    toDelete.push(company._id.toString());
                    break;
                }
            }
        }
        // Supprimer les faux leads
        if (toDelete.length > 0) {
            await LeadCompany_1.default.deleteMany({ _id: { $in: toDelete } });
            await LeadContact_1.default.deleteMany({ entrepriseId: { $in: toDelete } });
        }
        res.json({
            success: true,
            deleted: toDelete.length,
            message: `${toDelete.length} faux leads (produits) supprimes`
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Supprimer une entreprise
router.delete('/companies/:id', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id);
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        // Supprimer les contacts associes
        await LeadContact_1.default.deleteMany({ entrepriseId: company._id });
        await LeadInteraction_1.default.deleteMany({ entrepriseId: company._id });
        await LeadEmail_1.default.deleteMany({ entrepriseId: company._id });
        // Supprimer l'entreprise
        await LeadCompany_1.default.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: 'Entreprise supprimee' });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== CONTACTS ====================
router.get('/contacts', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, emailStatus, entrepriseId, search } = req.query;
        const filter = {};
        if (status)
            filter.statutContact = status;
        if (emailStatus)
            filter.emailStatus = emailStatus;
        if (entrepriseId)
            filter.entrepriseId = entrepriseId;
        if (search) {
            filter.$or = [
                { nom: { $regex: search, $options: 'i' } },
                { prenom: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } },
                { poste: { $regex: search, $options: 'i' } }
            ];
        }
        const skip = (Number(page) - 1) * Number(limit);
        const [contacts, total] = await Promise.all([
            LeadContact_1.default.find(filter)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('entrepriseId', 'raisonSociale'),
            LeadContact_1.default.countDocuments(filter)
        ]);
        res.json({ data: contacts, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/contacts', async (req, res) => {
    try {
        const contact = new LeadContact_1.default(req.body);
        await contact.save();
        res.status(201).json(contact);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.get('/contacts/:id', async (req, res) => {
    try {
        const contact = await LeadContact_1.default.findById(req.params.id)
            .populate('entrepriseId');
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        const emails = await LeadEmail_1.default.find({ contactId: contact._id }).sort({ dateEnvoi: -1 });
        res.json({ contact, emails });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put('/contacts/:id', async (req, res) => {
    try {
        const contact = await LeadContact_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        res.json(contact);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Verifier email via Lemlist
router.post('/contacts/:id/verify-email', async (req, res) => {
    try {
        const contact = await LeadContact_1.default.findById(req.params.id);
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        if (!contact.email)
            return res.status(400).json({ error: 'No email to verify' });
        const result = await lemlist_service_1.default.verifyEmail(contact.email);
        if (result) {
            contact.emailStatus = lemlist_service_1.default.mapEmailStatus(result.status);
            contact.lemlistData = { verification: result };
            await contact.save();
        }
        res.json({ success: true, contact, verification: result });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== EMAILS ====================
router.get('/emails', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, type, contactId, entrepriseId } = req.query;
        const filter = {};
        if (status)
            filter.statutEnvoi = status;
        if (type)
            filter.typeEmail = type;
        if (contactId)
            filter.contactId = contactId;
        if (entrepriseId)
            filter.entrepriseId = entrepriseId;
        const skip = (Number(page) - 1) * Number(limit);
        const [emails, total] = await Promise.all([
            LeadEmail_1.default.find(filter)
                .sort({ dateEnvoi: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('contactId', 'prenom nom email')
                .populate('entrepriseId', 'raisonSociale'),
            LeadEmail_1.default.countDocuments(filter)
        ]);
        res.json({ data: emails, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Envoyer un email
router.post('/emails/send', async (req, res) => {
    try {
        const { contactId, templateId, customSubject, customHtml, variables } = req.body;
        const contact = await LeadContact_1.default.findById(contactId).populate('entrepriseId');
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        if (!contact.email)
            return res.status(400).json({ error: 'Contact has no email' });
        if (contact.optOut)
            return res.status(400).json({ error: 'Contact opted out' });
        let subject = customSubject;
        let html = customHtml;
        // Si template, récupérer le contenu
        if (templateId) {
            const template = await LeadEmailTemplate_1.default.findOne({ code: templateId, actif: true });
            if (!template)
                return res.status(404).json({ error: 'Template not found' });
            subject = template.sujetTemplate;
            html = template.corpsHtmlTemplate;
        }
        // Préparer les variables
        const company = contact.entrepriseId;
        const emailVariables = {
            prenom: contact.prenom || '',
            nom: contact.nom || '',
            poste: contact.poste || '',
            entreprise: company?.raisonSociale || '',
            ...variables
        };
        // Créer l'entrée email
        const leadEmail = new LeadEmail_1.default({
            contactId: contact._id,
            entrepriseId: company?._id,
            typeEmail: templateId ? 'PRESENTATION' : 'MANUEL',
            templateId,
            sujet: subject,
            corpsHtml: html,
            langue: 'fr',
            expediteurEmail: 'commerce@symphonia-controltower.com',
            expediteurNom: 'Equipe Commerciale SYMPHONI.A',
            statutEnvoi: 'PENDING'
        });
        await leadEmail.save();
        // Envoyer via SMTP OVH
        const result = await email_service_1.default.sendTemplateEmail({
            to: contact.email,
            templateHtml: html,
            templateSubject: subject,
            variables: emailVariables
        });
        if (result && result.success) {
            leadEmail.mailgunMessageId = result.id; // Keep field for tracking
            leadEmail.dateEnvoi = new Date();
            leadEmail.statutEnvoi = 'SENT';
            await leadEmail.save();
            // Mettre à jour le contact
            contact.statutContact = 'CONTACTED';
            await contact.save();
            // Log interaction
            await LeadInteraction_1.default.create({
                entrepriseId: company?._id,
                contactId: contact._id,
                typeInteraction: 'EMAIL_ENVOYE',
                emailId: leadEmail._id,
                description: `Email envoyé: ${subject}`,
                createdBy: 'system'
            });
            res.json({ success: true, email: leadEmail, mailgunId: result.id });
        }
        else {
            leadEmail.statutEnvoi = 'FAILED';
            await leadEmail.save();
            res.status(500).json({ error: 'Failed to send email' });
        }
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Webhook Email Tracking (for future use)
router.post('/emails/webhook', async (req, res) => {
    try {
        const { event, messageId, timestamp, url, deliveryStatus } = req.body;
        if (!event || !messageId)
            return res.status(400).json({ error: 'Invalid webhook payload' });
        const email = await LeadEmail_1.default.findOne({ mailgunMessageId: { $regex: messageId } });
        if (!email)
            return res.status(200).json({ received: true });
        // Mettre a jour selon l'evenement
        const status = email_service_1.default.mapEventToStatus(event);
        const eventTime = timestamp ? new Date(timestamp * 1000) : new Date();
        switch (event) {
            case 'delivered':
                email.dateDelivered = eventTime;
                email.statutEnvoi = 'DELIVERED';
                break;
            case 'opened':
                email.dateOpened = email.dateOpened || eventTime;
                email.nbOpens += 1;
                email.statutEnvoi = 'OPENED';
                await LeadInteraction_1.default.create({
                    entrepriseId: email.entrepriseId,
                    contactId: email.contactId,
                    typeInteraction: 'EMAIL_OUVERT',
                    emailId: email._id,
                    createdBy: 'webhook'
                });
                break;
            case 'clicked':
                email.dateClicked = email.dateClicked || eventTime;
                email.nbClicks += 1;
                if (url)
                    email.linksClicked.push(url);
                email.statutEnvoi = 'CLICKED';
                await LeadInteraction_1.default.create({
                    entrepriseId: email.entrepriseId,
                    contactId: email.contactId,
                    typeInteraction: 'EMAIL_CLICKED',
                    emailId: email._id,
                    metadata: { url },
                    createdBy: 'webhook'
                });
                break;
            case 'bounced':
            case 'failed':
                email.statutEnvoi = 'BOUNCED';
                email.bounceType = deliveryStatus?.code?.toString();
                email.bounceMessage = deliveryStatus?.message;
                // Marquer le contact comme bounced
                await LeadContact_1.default.findByIdAndUpdate(email.contactId, {
                    emailStatus: 'INVALID',
                    statutContact: 'BOUNCED'
                });
                break;
            case 'complained':
                email.statutEnvoi = 'COMPLAINED';
                await LeadContact_1.default.findByIdAndUpdate(email.contactId, { optOut: true, dateOptOut: new Date() });
                break;
            case 'unsubscribed':
                email.statutEnvoi = 'UNSUBSCRIBED';
                await LeadContact_1.default.findByIdAndUpdate(email.contactId, { optOut: true, dateOptOut: new Date() });
                break;
        }
        await email.save();
        res.status(200).json({ received: true });
    }
    catch (error) {
        console.error('[CRM Webhook Error]', error);
        res.status(500).json({ error: error.message });
    }
});
// ==================== TEMPLATES ====================
router.get('/templates', async (req, res) => {
    try {
        const { type, langue, actif } = req.query;
        const filter = {};
        if (type)
            filter.typeEmail = type;
        if (langue)
            filter.langue = langue;
        if (actif !== undefined)
            filter.actif = actif === 'true';
        const templates = await LeadEmailTemplate_1.default.find(filter).sort({ typeEmail: 1, langue: 1 });
        res.json(templates);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/templates', async (req, res) => {
    try {
        const template = new LeadEmailTemplate_1.default(req.body);
        await template.save();
        res.status(201).json(template);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.put('/templates/:id', async (req, res) => {
    try {
        const template = await LeadEmailTemplate_1.default.findByIdAndUpdate(req.params.id, { ...req.body, version: (req.body.version || 1) + 1 }, { new: true });
        if (!template)
            return res.status(404).json({ error: 'Template not found' });
        res.json(template);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// ==================== INTERACTIONS (Notes) ====================
router.post('/interactions', async (req, res) => {
    try {
        const interaction = new LeadInteraction_1.default(req.body);
        await interaction.save();
        res.status(201).json(interaction);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// ==================== SALON DISCOVERY ====================
// Obtenir les salons connus + decouvrir de nouveaux
router.get('/discovery/salons', async (req, res) => {
    try {
        const { year, countries, discover } = req.query;
        const config = {
            year: year ? Number(year) : new Date().getFullYear(),
            countries: countries ? String(countries).split(',') : []
        };
        // Par defaut, retourner uniquement les salons connus
        if (discover !== 'true') {
            const known = salon_discovery_service_1.default.getKnownSalons(config);
            return res.json({
                success: true,
                known,
                discovered: [],
                total: known.length
            });
        }
        // Recherche complete avec decouverte web
        const result = await salon_discovery_service_1.default.discoverAll(config);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Importer un salon decouvert dans la base
router.post('/discovery/import', async (req, res) => {
    try {
        const { salon } = req.body;
        if (!salon || !salon.nom || !salon.pays) {
            return res.status(400).json({ error: 'Salon invalide (nom et pays requis)' });
        }
        // Verifier si le salon existe deja
        const existing = await LeadSalon_1.default.findOne({
            nom: { $regex: new RegExp(salon.nom, 'i') },
            edition: salon.edition
        });
        if (existing) {
            return res.status(400).json({ error: 'Ce salon existe deja', salonId: existing._id });
        }
        // Creer le salon
        const newSalon = await LeadSalon_1.default.create({
            nom: salon.nom,
            edition: salon.edition,
            pays: salon.pays,
            lieu: salon.lieu,
            url: salon.url,
            urlListeExposants: salon.urlListeExposants,
            descriptionActivite: salon.description,
            adaptateur: 'Generic',
            statutScraping: 'A_SCRAPER',
            sourceDecouverte: salon.source
        });
        res.status(201).json({ success: true, salon: newSalon });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== ENRICHISSEMENT AUTOMATIQUE ====================
// Enrichir une entreprise specifique
router.post('/enrichment/company/:id', async (req, res) => {
    try {
        const result = await lead_enrichment_service_1.default.enrichCompany(req.params.id);
        res.json({
            success: result.errors.length === 0,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Enrichir toutes les entreprises d'un salon
router.post('/enrichment/salon/:salonId', async (req, res) => {
    try {
        const { limit = 50 } = req.body;
        const result = await lead_enrichment_service_1.default.enrichSalonCompanies(req.params.salonId, limit);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Enrichir les nouvelles entreprises (batch)
router.post('/enrichment/batch', async (req, res) => {
    try {
        const { limit = 20 } = req.body;
        const result = await lead_enrichment_service_1.default.enrichNewCompanies(limit);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== POOL DE LEADS (COMMERCIAUX) ====================
// Obtenir les leads du pool (disponibles pour les commerciaux)
router.get('/pool', async (req, res) => {
    try {
        const { page = 1, limit = 20, pays, ville, departement, secteur, minScore, priorite, hasContacts, search } = req.query;
        const filter = {
            inPool: true,
            commercialAssigneId: { $exists: false }
        };
        if (pays)
            filter['adresse.pays'] = pays;
        if (ville)
            filter['adresse.ville'] = { $regex: ville, $options: 'i' };
        if (departement)
            filter['adresse.codePostal'] = { $regex: `^${departement}` };
        if (secteur)
            filter.secteurActivite = secteur;
        if (minScore)
            filter.scoreLead = { $gte: Number(minScore) };
        if (priorite)
            filter.prioritePool = Number(priorite);
        if (hasContacts === 'true')
            filter.nbContactsEnrichis = { $gt: 0 };
        if (search) {
            filter.$or = [
                { raisonSociale: { $regex: search, $options: 'i' } },
                { siteWeb: { $regex: search, $options: 'i' } },
                { descriptionActivite: { $regex: search, $options: 'i' } }
            ];
        }
        const skip = (Number(page) - 1) * Number(limit);
        const [leads, total, stats] = await Promise.all([
            LeadCompany_1.default.find(filter)
                .sort({ prioritePool: -1, scoreLead: -1, dateAddedToPool: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('salonSourceId', 'nom'),
            LeadCompany_1.default.countDocuments(filter),
            LeadCompany_1.default.aggregate([
                { $match: { inPool: true, commercialAssigneId: { $exists: false } } },
                {
                    $group: {
                        _id: null,
                        totalLeads: { $sum: 1 },
                        avgScore: { $avg: '$scoreLead' },
                        withContacts: { $sum: { $cond: [{ $gt: ['$nbContactsEnrichis', 0] }, 1, 0] } },
                        byPriority: {
                            $push: {
                                priorite: '$prioritePool',
                                count: 1
                            }
                        }
                    }
                }
            ])
        ]);
        // Stats par pays
        const byCountry = await LeadCompany_1.default.aggregate([
            { $match: { inPool: true, commercialAssigneId: { $exists: false } } },
            { $group: { _id: '$adresse.pays', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 10 }
        ]);
        res.json({
            data: leads,
            total,
            page: Number(page),
            limit: Number(limit),
            stats: stats[0] || { totalLeads: 0, avgScore: 0, withContacts: 0 },
            byCountry
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Ajouter des leads au pool
router.post('/pool/add', async (req, res) => {
    try {
        const { companyIds, salonId, criteria, priorite = 3 } = req.body;
        let filter = {};
        if (companyIds && companyIds.length > 0) {
            filter._id = { $in: companyIds };
        }
        else if (salonId) {
            filter.salonSourceId = salonId;
        }
        else if (criteria) {
            // Criteres dynamiques: pays, hasWebsite, hasContacts, minScore
            if (criteria.pays)
                filter['adresse.pays'] = criteria.pays;
            if (criteria.hasWebsite)
                filter.siteWeb = { $exists: true, $ne: '' };
            if (criteria.hasContacts)
                filter.nbContactsEnrichis = { $gt: 0 };
            if (criteria.minScore)
                filter.scoreLead = { $gte: criteria.minScore };
            if (criteria.statut)
                filter.statutProspection = criteria.statut;
        }
        else {
            return res.status(400).json({ error: 'Specifiez companyIds, salonId ou criteria' });
        }
        // Exclure ceux deja dans le pool ou deja assignes
        filter.inPool = { $ne: true };
        filter.commercialAssigneId = { $exists: false };
        const result = await LeadCompany_1.default.updateMany(filter, {
            $set: {
                inPool: true,
                dateAddedToPool: new Date(),
                prioritePool: priorite
            }
        });
        res.json({
            success: true,
            addedToPool: result.modifiedCount
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Retirer des leads du pool
router.post('/pool/remove', async (req, res) => {
    try {
        const { companyIds } = req.body;
        if (!companyIds || companyIds.length === 0) {
            return res.status(400).json({ error: 'companyIds requis' });
        }
        const result = await LeadCompany_1.default.updateMany({ _id: { $in: companyIds }, commercialAssigneId: { $exists: false } }, { $set: { inPool: false }, $unset: { dateAddedToPool: 1, prioritePool: 1 } });
        res.json({
            success: true,
            removedFromPool: result.modifiedCount
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// S'affecter un lead (pour un commercial)
router.post('/pool/claim/:companyId', async (req, res) => {
    try {
        const { commercialId, commercialName } = req.body;
        if (!commercialId) {
            return res.status(400).json({ error: 'commercialId requis' });
        }
        // Verifier que le lead est disponible
        const company = await LeadCompany_1.default.findOne({
            _id: req.params.companyId,
            inPool: true,
            commercialAssigneId: { $exists: false }
        });
        if (!company) {
            return res.status(400).json({ error: 'Lead non disponible ou deja assigne' });
        }
        // Affecter le lead
        company.commercialAssigneId = commercialId;
        company.dateAssignation = new Date();
        company.inPool = false;
        company.statutProspection = 'IN_PROGRESS';
        await company.save();
        // Logger l'interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            commercialId,
            typeInteraction: 'ASSIGNATION',
            description: `Lead reclame par ${commercialName || commercialId}`,
            createdBy: commercialId
        });
        // Recuperer les contacts pour ce lead
        const contacts = await LeadContact_1.default.find({ entrepriseId: company._id });
        res.json({
            success: true,
            company,
            contacts,
            message: 'Lead assigne avec succes'
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Liberer un lead (le remettre dans le pool)
router.post('/pool/release/:companyId', async (req, res) => {
    try {
        const { commercialId, reason } = req.body;
        const company = await LeadCompany_1.default.findById(req.params.companyId);
        if (!company) {
            return res.status(404).json({ error: 'Lead non trouve' });
        }
        // Verifier que le commercial est bien assigne
        if (company.commercialAssigneId?.toString() !== commercialId) {
            return res.status(403).json({ error: 'Vous n\'etes pas assigne a ce lead' });
        }
        // Liberer le lead
        company.commercialAssigneId = undefined;
        company.dateAssignation = undefined;
        company.inPool = true;
        company.dateAddedToPool = new Date();
        company.statutProspection = 'ENRICHED';
        await company.save();
        // Logger l'interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            commercialId,
            typeInteraction: 'RELEASE',
            description: `Lead libere. Raison: ${reason || 'Non specifiee'}`,
            createdBy: commercialId
        });
        res.json({
            success: true,
            message: 'Lead remis dans le pool'
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Obtenir mes leads (pour un commercial)
router.get('/pool/my-leads/:commercialId', async (req, res) => {
    try {
        const { page = 1, limit = 20, status } = req.query;
        const filter = {
            commercialAssigneId: req.params.commercialId
        };
        if (status)
            filter.statutProspection = status;
        const skip = (Number(page) - 1) * Number(limit);
        const [leads, total, stats] = await Promise.all([
            LeadCompany_1.default.find(filter)
                .sort({ dateAssignation: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('salonSourceId', 'nom'),
            LeadCompany_1.default.countDocuments(filter),
            LeadCompany_1.default.aggregate([
                { $match: { commercialAssigneId: req.params.commercialId } },
                {
                    $group: {
                        _id: '$statutProspection',
                        count: { $sum: 1 }
                    }
                }
            ])
        ]);
        // Recuperer les contacts pour chaque lead
        const leadsWithContacts = await Promise.all(leads.map(async (lead) => {
            const contacts = await LeadContact_1.default.find({ entrepriseId: lead._id })
                .select('prenom nom email poste emailStatus')
                .limit(5);
            return {
                ...lead.toObject(),
                contacts
            };
        }));
        res.json({
            data: leadsWithContacts,
            total,
            page: Number(page),
            limit: Number(limit),
            statsByStatus: stats.reduce((acc, s) => {
                acc[s._id] = s.count;
                return acc;
            }, {})
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Stats du pool
router.get('/pool/stats', async (req, res) => {
    try {
        const [poolStats, byCountry, bySector, topCommercials] = await Promise.all([
            LeadCompany_1.default.aggregate([
                {
                    $facet: {
                        total: [{ $count: 'count' }],
                        inPool: [{ $match: { inPool: true, commercialAssigneId: { $exists: false } } }, { $count: 'count' }],
                        assigned: [{ $match: { commercialAssigneId: { $exists: true } } }, { $count: 'count' }],
                        withContacts: [{ $match: { nbContactsEnrichis: { $gt: 0 } } }, { $count: 'count' }],
                        avgScore: [{ $group: { _id: null, avg: { $avg: '$scoreLead' } } }]
                    }
                }
            ]),
            LeadCompany_1.default.aggregate([
                { $match: { inPool: true } },
                { $group: { _id: '$adresse.pays', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ]),
            LeadCompany_1.default.aggregate([
                { $match: { inPool: true } },
                { $group: { _id: '$secteurActivite', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ]),
            LeadCompany_1.default.aggregate([
                { $match: { commercialAssigneId: { $exists: true } } },
                { $group: { _id: '$commercialAssigneId', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ])
        ]);
        const stats = poolStats[0];
        res.json({
            total: stats.total[0]?.count || 0,
            inPool: stats.inPool[0]?.count || 0,
            assigned: stats.assigned[0]?.count || 0,
            withContacts: stats.withContacts[0]?.count || 0,
            avgScore: Math.round(stats.avgScore[0]?.avg || 0),
            byCountry,
            bySector,
            topCommercials
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== COMMERCIAUX (EQUIPE CRM) ====================
// Liste des commerciaux
router.get('/commercials', async (req, res) => {
    try {
        const { status, type, search } = req.query;
        const filter = {};
        if (status)
            filter.status = status;
        if (type)
            filter.type = type;
        if (search) {
            filter.$or = [
                { firstName: { $regex: search, $options: 'i' } },
                { lastName: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } }
            ];
        }
        const commercials = await CrmCommercial_1.default.find(filter).sort({ createdAt: -1 });
        // Enrichir avec les leads assignes
        for (const commercial of commercials) {
            const leadsAssignes = await LeadCompany_1.default.countDocuments({ commercialAssigneId: commercial._id });
            const leadsEnCours = await LeadCompany_1.default.countDocuments({
                commercialAssigneId: commercial._id,
                statutProspection: { $in: ['ASSIGNED', 'CONTACTED', 'IN_PROGRESS'] }
            });
            const leadsConverts = await LeadCompany_1.default.countDocuments({
                commercialAssigneId: commercial._id,
                statutProspection: 'CONVERTED'
            });
            commercial.stats.leadsAssignes = leadsAssignes;
            commercial.stats.leadsEnCours = leadsEnCours;
            commercial.stats.leadsConverts = leadsConverts;
            commercial.stats.tauxConversion = leadsAssignes > 0 ? Math.round((leadsConverts / leadsAssignes) * 100) : 0;
            // Commissions
            const commissions = await CrmCommission_1.default.aggregate([
                { $match: { commercialId: commercial._id } },
                { $group: {
                        _id: '$status',
                        total: { $sum: '$montant' }
                    } }
            ]);
            commercial.stats.commissionsTotal = commissions.reduce((sum, c) => sum + (c.total || 0), 0);
            commercial.stats.commissionsPending = commissions.find(c => c._id === 'pending')?.total || 0;
        }
        res.json({ commercials, total: commercials.length });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Creer un commercial
router.post('/commercials', async (req, res) => {
    try {
        // Generer un mot de passe temporaire
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        let tempPassword = '';
        for (let i = 0; i < 8; i++) {
            tempPassword += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        const commercialData = {
            ...req.body,
            tempPassword,
            mustChangePassword: true
        };
        const commercial = await CrmCommercial_1.default.create(commercialData);
        // Envoyer l'email avec les identifiants
        try {
            await email_service_1.default.sendEmail({
                to: commercial.email,
                subject: 'Vos identifiants Portail Commercial - SYMPHONI.A',
                html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #2563eb, #7c3aed); padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
              <h1 style="color: white; margin: 0;">Bienvenue ${commercial.firstName}!</h1>
            </div>
            <div style="background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
              <p>Votre compte commercial a ete cree. Voici vos identifiants de connexion:</p>
              <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
                <p style="margin: 10px 0;"><strong>Code d'acces:</strong> <code style="background: #e5e7eb; padding: 4px 8px; border-radius: 4px;">${commercial.accessCode}</code></p>
                <p style="margin: 10px 0;"><strong>Mot de passe:</strong> <code style="background: #e5e7eb; padding: 4px 8px; border-radius: 4px;">${tempPassword}</code></p>
              </div>
              <p style="color: #dc2626; font-weight: bold;">Vous devrez changer votre mot de passe lors de votre premiere connexion.</p>
              <div style="text-align: center; margin-top: 30px;">
                <a href="https://app.symphonia-controltower.com/commercial/login"
                   style="background: #2563eb; color: white; padding: 12px 30px; border-radius: 6px; text-decoration: none; font-weight: bold;">
                  Acceder au Portail Commercial
                </a>
              </div>
              <p style="margin-top: 30px; color: #6b7280; font-size: 14px;">
                En cas de probleme de connexion, contactez votre administrateur.
              </p>
            </div>
          </div>
        `
            });
        }
        catch (emailError) {
            console.error('Erreur envoi email commercial:', emailError);
        }
        res.status(201).json({
            ...commercial.toObject(),
            tempPassword // Renvoyer le mot de passe temporaire (visible une seule fois)
        });
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Obtenir un commercial
router.get('/commercials/:id', async (req, res) => {
    try {
        const commercial = await CrmCommercial_1.default.findById(req.params.id);
        if (!commercial)
            return res.status(404).json({ error: 'Commercial non trouve' });
        // Leads assignes
        const leads = await LeadCompany_1.default.find({ commercialAssigneId: commercial._id })
            .select('raisonSociale statutProspection scoreLead createdAt')
            .sort({ createdAt: -1 })
            .limit(20);
        // Commissions
        const commissions = await CrmCommission_1.default.find({ commercialId: commercial._id })
            .sort({ createdAt: -1 })
            .limit(20);
        res.json({ commercial, leads, commissions });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Modifier un commercial
router.put('/commercials/:id', async (req, res) => {
    try {
        const commercial = await CrmCommercial_1.default.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true });
        if (!commercial)
            return res.status(404).json({ error: 'Commercial non trouve' });
        res.json(commercial);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Supprimer un commercial
router.delete('/commercials/:id', async (req, res) => {
    try {
        const commercial = await CrmCommercial_1.default.findById(req.params.id);
        if (!commercial)
            return res.status(404).json({ error: 'Commercial non trouve' });
        // Reassigner les leads au pool
        await LeadCompany_1.default.updateMany({ commercialAssigneId: commercial._id }, { $unset: { commercialAssigneId: 1, dateAssignation: 1 } });
        await CrmCommercial_1.default.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: 'Commercial supprime et leads reassignes au pool' });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Stats equipe commerciale
router.get('/commercials-stats', async (req, res) => {
    try {
        const now = new Date();
        const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        const [totalCommerciaux, commerciauxActifs, internes, externes] = await Promise.all([
            CrmCommercial_1.default.countDocuments(),
            CrmCommercial_1.default.countDocuments({ status: 'active' }),
            CrmCommercial_1.default.countDocuments({ type: 'internal', status: 'active' }),
            CrmCommercial_1.default.countDocuments({ type: 'external', status: 'active' })
        ]);
        // Commissions du mois
        const commissionsMonth = await CrmCommission_1.default.aggregate([
            { $match: { periode: currentMonth } },
            { $group: {
                    _id: '$status',
                    total: { $sum: '$montant' },
                    count: { $sum: 1 }
                } }
        ]);
        const commissionsPending = commissionsMonth.find(c => c._id === 'pending')?.total || 0;
        const commissionsPaid = commissionsMonth.find(c => c._id === 'paid')?.total || 0;
        // Top performers
        const topPerformers = await CrmCommercial_1.default.find({ status: 'active' })
            .sort({ 'stats.leadsConverts': -1 })
            .limit(5)
            .select('firstName lastName stats');
        res.json({
            totalCommerciaux,
            commerciauxActifs,
            internes,
            externes,
            commissionsMonth: {
                pending: commissionsPending,
                paid: commissionsPaid,
                total: commissionsPending + commissionsPaid
            },
            topPerformers
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== COMMISSIONS ====================
// Liste des commissions
router.get('/commissions', async (req, res) => {
    try {
        const { commercialId, status, periode, page = 1, limit = 50 } = req.query;
        const filter = {};
        if (commercialId)
            filter.commercialId = commercialId;
        if (status)
            filter.status = status;
        if (periode)
            filter.periode = periode;
        const skip = (Number(page) - 1) * Number(limit);
        const [commissions, total] = await Promise.all([
            CrmCommission_1.default.find(filter)
                .populate('commercialId', 'firstName lastName email type')
                .populate('leadCompanyId', 'raisonSociale')
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(Number(limit)),
            CrmCommission_1.default.countDocuments(filter)
        ]);
        // Totaux par status
        const totals = await CrmCommission_1.default.aggregate([
            { $match: filter },
            { $group: {
                    _id: '$status',
                    total: { $sum: '$montant' },
                    count: { $sum: 1 }
                } }
        ]);
        res.json({
            commissions,
            total,
            page: Number(page),
            limit: Number(limit),
            totals: {
                pending: totals.find(t => t._id === 'pending')?.total || 0,
                validated: totals.find(t => t._id === 'validated')?.total || 0,
                paid: totals.find(t => t._id === 'paid')?.total || 0
            }
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Creer une commission
router.post('/commissions', async (req, res) => {
    try {
        const commission = await CrmCommission_1.default.create(req.body);
        // Mettre a jour les stats du commercial
        if (commission.commercialId) {
            await CrmCommercial_1.default.findByIdAndUpdate(commission.commercialId, {
                $inc: { 'stats.commissionsPending': commission.montant }
            });
        }
        const populated = await CrmCommission_1.default.findById(commission._id)
            .populate('commercialId', 'firstName lastName email')
            .populate('leadCompanyId', 'raisonSociale');
        res.status(201).json(populated);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Valider une commission
router.post('/commissions/:id/validate', async (req, res) => {
    try {
        const commission = await CrmCommission_1.default.findByIdAndUpdate(req.params.id, {
            $set: {
                status: 'validated',
                dateValidation: new Date()
            }
        }, { new: true }).populate('commercialId', 'firstName lastName email');
        if (!commission)
            return res.status(404).json({ error: 'Commission non trouvee' });
        res.json(commission);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Marquer une commission comme payee
router.post('/commissions/:id/pay', async (req, res) => {
    try {
        const commission = await CrmCommission_1.default.findById(req.params.id);
        if (!commission)
            return res.status(404).json({ error: 'Commission non trouvee' });
        commission.status = 'paid';
        commission.datePaiement = new Date();
        await commission.save();
        // Mettre a jour les stats du commercial
        if (commission.commercialId) {
            await CrmCommercial_1.default.findByIdAndUpdate(commission.commercialId, {
                $inc: {
                    'stats.commissionsPending': -commission.montant,
                    'stats.commissionsTotal': commission.montant
                }
            });
        }
        const populated = await CrmCommission_1.default.findById(commission._id)
            .populate('commercialId', 'firstName lastName email');
        res.json(populated);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Annuler une commission
router.post('/commissions/:id/cancel', async (req, res) => {
    try {
        const commission = await CrmCommission_1.default.findById(req.params.id);
        if (!commission)
            return res.status(404).json({ error: 'Commission non trouvee' });
        const oldStatus = commission.status;
        commission.status = 'cancelled';
        await commission.save();
        // Ajuster les stats du commercial si necessaire
        if (commission.commercialId && oldStatus === 'pending') {
            await CrmCommercial_1.default.findByIdAndUpdate(commission.commercialId, {
                $inc: { 'stats.commissionsPending': -commission.montant }
            });
        }
        res.json(commission);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Generer les commissions du mois pour tous les commerciaux
router.post('/commissions/generate-monthly', async (req, res) => {
    try {
        const now = new Date();
        const periode = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        const commerciaux = await CrmCommercial_1.default.find({ status: 'active' });
        const created = [];
        for (const commercial of commerciaux) {
            // Verifier si deja genere
            const existing = await CrmCommission_1.default.findOne({
                commercialId: commercial._id,
                periode,
                type: 'conversion'
            });
            if (existing)
                continue;
            // Compter les leads convertis ce mois
            const leadsConvertisMois = await LeadCompany_1.default.countDocuments({
                commercialAssigneId: commercial._id,
                statutProspection: 'CONVERTED',
                updatedAt: {
                    $gte: new Date(now.getFullYear(), now.getMonth(), 1),
                    $lt: new Date(now.getFullYear(), now.getMonth() + 1, 1)
                }
            });
            if (leadsConvertisMois > 0) {
                const montant = leadsConvertisMois * (commercial.commissionConfig?.tauxConversion || 50);
                const commission = await CrmCommission_1.default.create({
                    commercialId: commercial._id,
                    type: 'conversion',
                    montant,
                    periode,
                    description: `${leadsConvertisMois} leads convertis en ${periode}`
                });
                created.push(commission);
            }
            // Bonus objectif atteint
            if (commercial.objectifMensuel && leadsConvertisMois >= commercial.objectifMensuel) {
                const bonus = await CrmCommission_1.default.create({
                    commercialId: commercial._id,
                    type: 'bonus',
                    montant: commercial.commissionConfig?.bonusObjectif || 500,
                    periode,
                    description: `Bonus objectif atteint (${leadsConvertisMois}/${commercial.objectifMensuel})`
                });
                created.push(bonus);
            }
        }
        res.json({
            success: true,
            periode,
            commissionsCreated: created.length,
            commissions: created
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== MANAGER - SUIVI ACTIVITE COMMERCIAUX ====================
/**
 * GET /manager/commercials/activity - Vue globale de l'activite des commerciaux
 */
router.get('/manager/commercials/activity', async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        const start = startDate ? new Date(startDate) : new Date(new Date().setDate(new Date().getDate() - 30));
        const end = endDate ? new Date(endDate) : new Date();
        // Recuperer tous les commerciaux actifs
        const commercials = await CrmCommercial_1.default.find({ status: 'active' });
        const activityData = await Promise.all(commercials.map(async (commercial) => {
            const [leadsAssignes, leadsConverts, leadsEnCours, leadsPerdus, rdvProgrammes, rdvTermines, rdvAnnules, interactions] = await Promise.all([
                LeadCompany_1.default.countDocuments({
                    commercialAssigneId: commercial._id,
                    dateAssignation: { $gte: start, $lte: end }
                }),
                LeadCompany_1.default.countDocuments({
                    commercialAssigneId: commercial._id,
                    statutProspection: 'CONVERTED',
                    updatedAt: { $gte: start, $lte: end }
                }),
                LeadCompany_1.default.countDocuments({
                    commercialAssigneId: commercial._id,
                    statutProspection: { $in: ['NEW', 'CONTACTED', 'IN_PROGRESS'] }
                }),
                LeadCompany_1.default.countDocuments({
                    commercialAssigneId: commercial._id,
                    statutProspection: 'LOST',
                    updatedAt: { $gte: start, $lte: end }
                }),
                CommercialMeeting_1.default.countDocuments({
                    commercialId: commercial._id,
                    scheduledAt: { $gte: start, $lte: end }
                }),
                CommercialMeeting_1.default.countDocuments({
                    commercialId: commercial._id,
                    status: 'completed',
                    scheduledAt: { $gte: start, $lte: end }
                }),
                CommercialMeeting_1.default.countDocuments({
                    commercialId: commercial._id,
                    status: 'cancelled',
                    scheduledAt: { $gte: start, $lte: end }
                }),
                LeadInteraction_1.default.countDocuments({
                    createdBy: commercial._id.toString(),
                    createdAt: { $gte: start, $lte: end }
                })
            ]);
            const tauxConversion = leadsAssignes > 0 ? Math.round((leadsConverts / leadsAssignes) * 100) : 0;
            const progressionObjectif = commercial.objectifMensuel
                ? Math.round((leadsConverts / commercial.objectifMensuel) * 100)
                : 0;
            return {
                commercial: {
                    id: commercial._id,
                    firstName: commercial.firstName,
                    lastName: commercial.lastName,
                    email: commercial.email,
                    type: commercial.type,
                    region: commercial.region,
                    lastLogin: commercial.lastLogin,
                    objectifMensuel: commercial.objectifMensuel
                },
                stats: {
                    leadsAssignes,
                    leadsConverts,
                    leadsEnCours,
                    leadsPerdus,
                    tauxConversion,
                    progressionObjectif,
                    rdvProgrammes,
                    rdvTermines,
                    rdvAnnules,
                    interactions
                }
            };
        }));
        // Trier par performance (taux de conversion)
        activityData.sort((a, b) => b.stats.tauxConversion - a.stats.tauxConversion);
        // Statistiques globales
        const globalStats = {
            totalCommerciaux: commercials.length,
            totalLeadsAssignes: activityData.reduce((sum, c) => sum + c.stats.leadsAssignes, 0),
            totalLeadsConverts: activityData.reduce((sum, c) => sum + c.stats.leadsConverts, 0),
            totalRdvProgrammes: activityData.reduce((sum, c) => sum + c.stats.rdvProgrammes, 0),
            tauxConversionMoyen: activityData.length > 0
                ? Math.round(activityData.reduce((sum, c) => sum + c.stats.tauxConversion, 0) / activityData.length)
                : 0
        };
        res.json({
            period: { start, end },
            globalStats,
            commercials: activityData
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
/**
 * GET /manager/commercials/:id/detail - Detail activite d'un commercial
 */
router.get('/manager/commercials/:id/detail', async (req, res) => {
    try {
        const { id } = req.params;
        const { startDate, endDate } = req.query;
        const start = startDate ? new Date(startDate) : new Date(new Date().setDate(new Date().getDate() - 30));
        const end = endDate ? new Date(endDate) : new Date();
        const commercial = await CrmCommercial_1.default.findById(id);
        if (!commercial) {
            return res.status(404).json({ error: 'Commercial non trouve' });
        }
        // Leads assignes dans la periode
        const leads = await LeadCompany_1.default.find({
            commercialAssigneId: id,
            dateAssignation: { $gte: start, $lte: end }
        })
            .select('raisonSociale statutProspection dateAssignation scoreLead adresse.ville')
            .sort({ dateAssignation: -1 });
        // Rendez-vous
        const meetings = await CommercialMeeting_1.default.find({
            commercialId: id,
            scheduledAt: { $gte: start, $lte: end }
        })
            .select('title prospectInfo scheduledAt status outcome')
            .sort({ scheduledAt: -1 });
        // Interactions recentes
        const interactions = await LeadInteraction_1.default.find({
            createdBy: id,
            createdAt: { $gte: start, $lte: end }
        })
            .populate('entrepriseId', 'raisonSociale')
            .sort({ createdAt: -1 })
            .limit(50);
        // Commissions
        const commissions = await CrmCommission_1.default.find({
            commercialId: id,
            createdAt: { $gte: start, $lte: end }
        }).sort({ createdAt: -1 });
        // Stats par jour pour graphique
        const dailyStats = [];
        const current = new Date(start);
        while (current <= end) {
            const dayStart = new Date(current);
            dayStart.setHours(0, 0, 0, 0);
            const dayEnd = new Date(current);
            dayEnd.setHours(23, 59, 59, 999);
            const [leadsDay, rdvDay, conversionsDay] = await Promise.all([
                LeadCompany_1.default.countDocuments({
                    commercialAssigneId: id,
                    dateAssignation: { $gte: dayStart, $lte: dayEnd }
                }),
                CommercialMeeting_1.default.countDocuments({
                    commercialId: id,
                    scheduledAt: { $gte: dayStart, $lte: dayEnd }
                }),
                LeadCompany_1.default.countDocuments({
                    commercialAssigneId: id,
                    statutProspection: 'CONVERTED',
                    updatedAt: { $gte: dayStart, $lte: dayEnd }
                })
            ]);
            dailyStats.push({
                date: current.toISOString().split('T')[0],
                leads: leadsDay,
                rdv: rdvDay,
                conversions: conversionsDay
            });
            current.setDate(current.getDate() + 1);
        }
        // Disponibilites configurees
        const availability = await CommercialAvailability_1.default.findOne({ commercialId: id });
        res.json({
            commercial: {
                id: commercial._id,
                firstName: commercial.firstName,
                lastName: commercial.lastName,
                email: commercial.email,
                telephone: commercial.telephone,
                type: commercial.type,
                status: commercial.status,
                region: commercial.region,
                objectifMensuel: commercial.objectifMensuel,
                lastLogin: commercial.lastLogin,
                commissionConfig: commercial.commissionConfig
            },
            period: { start, end },
            leads,
            meetings,
            interactions,
            commissions,
            dailyStats,
            availability: availability ? {
                isActive: availability.isActive,
                meetingDuration: availability.meetingDuration,
                weeklySlots: availability.weeklySchedule.filter(d => d.isActive).length
            } : null
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
/**
 * GET /manager/meetings - Tous les RDV de tous les commerciaux
 */
router.get('/manager/meetings', async (req, res) => {
    try {
        const { startDate, endDate, commercialId, status, page = 1, limit = 50 } = req.query;
        const filter = {};
        if (startDate && endDate) {
            filter.scheduledAt = {
                $gte: new Date(startDate),
                $lte: new Date(endDate)
            };
        }
        if (commercialId)
            filter.commercialId = commercialId;
        if (status)
            filter.status = status;
        const skip = (Number(page) - 1) * Number(limit);
        const [meetings, total] = await Promise.all([
            CommercialMeeting_1.default.find(filter)
                .populate('commercialId', 'firstName lastName email')
                .populate('leadCompanyId', 'raisonSociale')
                .sort({ scheduledAt: -1 })
                .skip(skip)
                .limit(Number(limit)),
            CommercialMeeting_1.default.countDocuments(filter)
        ]);
        // Stats par statut
        const statsByStatus = await CommercialMeeting_1.default.aggregate([
            { $match: filter },
            { $group: { _id: '$status', count: { $sum: 1 } } }
        ]);
        res.json({
            meetings,
            total,
            page: Number(page),
            pages: Math.ceil(total / Number(limit)),
            statsByStatus
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
/**
 * GET /manager/dashboard - Tableau de bord manager complet
 */
router.get('/manager/dashboard', async (req, res) => {
    try {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const startOfWeek = new Date(now);
        startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
        const [totalCommerciaux, commerciauxActifs, leadsPoolDisponibles, leadsAssignesCeMois, leadsConvertsCeMois, rdvCetteSemaine, rdvAujourdhui, topPerformers, rdvAVenir, dernieresConversions] = await Promise.all([
            CrmCommercial_1.default.countDocuments(),
            CrmCommercial_1.default.countDocuments({ status: 'active' }),
            LeadCompany_1.default.countDocuments({ inPool: true, commercialAssigneId: { $exists: false } }),
            LeadCompany_1.default.countDocuments({ dateAssignation: { $gte: startOfMonth } }),
            LeadCompany_1.default.countDocuments({ statutProspection: 'CONVERTED', updatedAt: { $gte: startOfMonth } }),
            CommercialMeeting_1.default.countDocuments({
                scheduledAt: { $gte: startOfWeek },
                status: { $ne: 'cancelled' }
            }),
            CommercialMeeting_1.default.countDocuments({
                scheduledAt: {
                    $gte: new Date(now.setHours(0, 0, 0, 0)),
                    $lte: new Date(now.setHours(23, 59, 59, 999))
                },
                status: { $ne: 'cancelled' }
            }),
            // Top 5 commerciaux par conversions ce mois
            LeadCompany_1.default.aggregate([
                { $match: { statutProspection: 'CONVERTED', updatedAt: { $gte: startOfMonth } } },
                { $group: { _id: '$commercialAssigneId', conversions: { $sum: 1 } } },
                { $sort: { conversions: -1 } },
                { $limit: 5 },
                {
                    $lookup: {
                        from: 'crmcommercials',
                        localField: '_id',
                        foreignField: '_id',
                        as: 'commercial'
                    }
                },
                { $unwind: '$commercial' },
                {
                    $project: {
                        conversions: 1,
                        'commercial.firstName': 1,
                        'commercial.lastName': 1
                    }
                }
            ]),
            // Prochains RDV (5)
            CommercialMeeting_1.default.find({
                scheduledAt: { $gte: new Date() },
                status: 'scheduled'
            })
                .populate('commercialId', 'firstName lastName')
                .sort({ scheduledAt: 1 })
                .limit(5),
            // Dernieres conversions (5)
            LeadCompany_1.default.find({ statutProspection: 'CONVERTED' })
                .select('raisonSociale updatedAt commercialAssigneId')
                .populate('commercialAssigneId', 'firstName lastName')
                .sort({ updatedAt: -1 })
                .limit(5)
        ]);
        // Taux de conversion global
        const totalLeadsAssignes = await LeadCompany_1.default.countDocuments({ commercialAssigneId: { $exists: true } });
        const totalLeadsConverts = await LeadCompany_1.default.countDocuments({ statutProspection: 'CONVERTED' });
        const tauxConversionGlobal = totalLeadsAssignes > 0 ? Math.round((totalLeadsConverts / totalLeadsAssignes) * 100) : 0;
        res.json({
            overview: {
                totalCommerciaux,
                commerciauxActifs,
                leadsPoolDisponibles,
                tauxConversionGlobal
            },
            monthStats: {
                leadsAssignes: leadsAssignesCeMois,
                leadsConverts: leadsConvertsCeMois,
                objectifEquipe: commerciauxActifs * 10, // Estimation
                progression: Math.round((leadsConvertsCeMois / (commerciauxActifs * 10)) * 100)
            },
            meetings: {
                cetteSemaine: rdvCetteSemaine,
                aujourdhui: rdvAujourdhui,
                aVenir: rdvAVenir
            },
            topPerformers,
            dernieresConversions
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== ODOO INTEGRATION ====================
/**
 * GET /odoo/status - Verifier la configuration et connexion Odoo
 */
router.get('/odoo/status', async (_req, res) => {
    try {
        const config = odoo_service_1.default.getConfig();
        if (!odoo_service_1.default.isConfigured()) {
            return res.json({
                configured: false,
                message: 'Odoo non configure - definir ODOO_URL, ODOO_DB, ODOO_USERNAME, ODOO_PASSWORD',
                config
            });
        }
        // Tester la connexion
        try {
            await odoo_service_1.default.authenticate();
            return res.json({
                configured: true,
                connected: true,
                message: 'Connexion Odoo reussie',
                config
            });
        }
        catch (authError) {
            return res.json({
                configured: true,
                connected: false,
                message: `Erreur connexion: ${authError.message}`,
                config
            });
        }
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
/**
 * POST /odoo/sync - Synchroniser les clients Odoo vers la bourse de leads
 */
router.post('/odoo/sync', async (req, res) => {
    try {
        const { limit = 500, offset = 0, forceUpdate = false } = req.body;
        if (!odoo_service_1.default.isConfigured()) {
            return res.status(400).json({
                error: 'Odoo non configure - definir ODOO_URL, ODOO_DB, ODOO_USERNAME, ODOO_PASSWORD'
            });
        }
        console.log(`[Odoo Sync] Demarrage sync - limit: ${limit}, offset: ${offset}, forceUpdate: ${forceUpdate}`);
        // Recuperer les clients depuis Odoo (is_company + active pour compatibilite)
        const odooPartners = await odoo_service_1.default.searchRead({
            model: 'res.partner',
            domain: [
                ['is_company', '=', true],
                ['active', '=', true]
            ],
            fields: [
                'id', 'name', 'email', 'phone', 'mobile', 'street', 'street2', 'city', 'zip',
                'country_id', 'vat', 'website', 'industry_id', 'ref', 'comment'
            ],
            limit,
            offset,
            order: 'create_date desc'
        });
        console.log(`[Odoo Sync] ${odooPartners.length} partenaires recuperes depuis Odoo`);
        const results = {
            total: odooPartners.length,
            created: 0,
            updated: 0,
            skipped: 0,
            errors: []
        };
        for (const partner of odooPartners) {
            try {
                // Verifier si le lead existe deja (par email ou nom)
                const existingLead = await LeadCompany_1.default.findOne({
                    $or: [
                        ...(partner.email ? [{ emailGenerique: partner.email }] : []),
                        { raisonSociale: partner.name }
                    ]
                });
                // Extraire le pays
                let paysName = 'France';
                if (partner.country_id && Array.isArray(partner.country_id) && partner.country_id.length > 1) {
                    paysName = partner.country_id[1]; // [id, name]
                }
                // Extraire le secteur d'activite
                let secteur = '';
                if (partner.industry_id && Array.isArray(partner.industry_id) && partner.industry_id.length > 1) {
                    secteur = partner.industry_id[1];
                }
                const leadData = {
                    raisonSociale: partner.name,
                    emailGenerique: partner.email || undefined,
                    telephone: partner.phone || partner.mobile || undefined,
                    siteWeb: partner.website || undefined,
                    tvaIntracommunautaire: partner.vat || undefined,
                    adresse: {
                        ligne1: partner.street || undefined,
                        ligne2: partner.street2 || undefined,
                        codePostal: partner.zip || undefined,
                        ville: partner.city || undefined,
                        pays: paysName
                    },
                    secteurActivite: secteur || undefined,
                    descriptionActivite: partner.comment || undefined,
                    // Metadata Odoo
                    lemlistData: {
                        odooId: partner.id,
                        odooRef: partner.ref,
                        syncDate: new Date().toISOString(),
                        source: 'odoo'
                    },
                    // Ajouter au pool
                    inPool: true,
                    dateAddedToPool: new Date(),
                    prioritePool: 3,
                    statutProspection: 'NEW',
                    scoreLead: 50 // Score par defaut
                };
                if (existingLead) {
                    if (forceUpdate) {
                        await LeadCompany_1.default.updateOne({ _id: existingLead._id }, { $set: { ...leadData, inPool: existingLead.inPool } });
                        results.updated++;
                    }
                    else {
                        results.skipped++;
                    }
                }
                else {
                    await LeadCompany_1.default.create(leadData);
                    results.created++;
                }
            }
            catch (partnerError) {
                results.errors.push(`${partner.name}: ${partnerError.message}`);
            }
        }
        console.log(`[Odoo Sync] Termine - created: ${results.created}, updated: ${results.updated}, skipped: ${results.skipped}`);
        res.json({
            success: true,
            message: `Synchronisation terminee: ${results.created} crees, ${results.updated} mis a jour, ${results.skipped} ignores`,
            results
        });
    }
    catch (error) {
        console.error('[Odoo Sync] Erreur:', error.message);
        res.status(500).json({ error: error.message });
    }
});
/**
 * POST /odoo/sync-leads - Synchroniser les leads CRM Odoo
 */
router.post('/odoo/sync-leads', async (req, res) => {
    try {
        const { limit = 500, offset = 0 } = req.body;
        if (!odoo_service_1.default.isConfigured()) {
            return res.status(400).json({
                error: 'Odoo non configure'
            });
        }
        console.log(`[Odoo Sync Leads] Demarrage sync CRM leads`);
        // Recuperer les leads CRM depuis Odoo
        const odooLeads = await odoo_service_1.default.searchRead({
            model: 'crm.lead',
            domain: [['type', '=', 'opportunity']],
            fields: [
                'id', 'name', 'partner_name', 'email_from', 'phone', 'mobile',
                'street', 'city', 'zip', 'country_id', 'website', 'description',
                'contact_name', 'function'
            ],
            limit,
            offset,
            order: 'create_date desc'
        });
        console.log(`[Odoo Sync Leads] ${odooLeads.length} leads CRM recuperes`);
        const results = {
            total: odooLeads.length,
            created: 0,
            skipped: 0,
            errors: []
        };
        for (const lead of odooLeads) {
            try {
                const companyName = lead.partner_name || lead.name;
                // Verifier si existe deja
                const existing = await LeadCompany_1.default.findOne({
                    $or: [
                        ...(lead.email_from ? [{ emailGenerique: lead.email_from }] : []),
                        { raisonSociale: companyName }
                    ]
                });
                if (existing) {
                    results.skipped++;
                    continue;
                }
                let paysName = 'France';
                if (lead.country_id && Array.isArray(lead.country_id) && lead.country_id.length > 1) {
                    paysName = lead.country_id[1];
                }
                await LeadCompany_1.default.create({
                    raisonSociale: companyName,
                    emailGenerique: lead.email_from || undefined,
                    telephone: lead.phone || lead.mobile || undefined,
                    siteWeb: lead.website || undefined,
                    adresse: {
                        ligne1: lead.street || undefined,
                        codePostal: lead.zip || undefined,
                        ville: lead.city || undefined,
                        pays: paysName
                    },
                    descriptionActivite: lead.description || undefined,
                    lemlistData: {
                        odooLeadId: lead.id,
                        odooLeadName: lead.name,
                        contactName: lead.contact_name,
                        contactFunction: lead.function,
                        syncDate: new Date().toISOString(),
                        source: 'odoo-crm'
                    },
                    inPool: true,
                    dateAddedToPool: new Date(),
                    prioritePool: 4, // Priorite plus haute pour les leads CRM
                    statutProspection: 'NEW',
                    scoreLead: 60
                });
                results.created++;
            }
            catch (leadError) {
                results.errors.push(`${lead.name}: ${leadError.message}`);
            }
        }
        console.log(`[Odoo Sync Leads] Termine - created: ${results.created}, skipped: ${results.skipped}`);
        res.json({
            success: true,
            message: `Leads CRM synchronises: ${results.created} crees, ${results.skipped} ignores`,
            results
        });
    }
    catch (error) {
        console.error('[Odoo Sync Leads] Erreur:', error.message);
        res.status(500).json({ error: error.message });
    }
});
/**
 * GET /odoo/stats - Statistiques Odoo
 */
router.get('/odoo/stats', async (_req, res) => {
    try {
        if (!odoo_service_1.default.isConfigured()) {
            return res.status(400).json({ error: 'Odoo non configure' });
        }
        const [customers, leads, products, orders] = await Promise.all([
            odoo_service_1.default.count('res.partner', [['is_company', '=', true], ['customer_rank', '>', 0]]),
            odoo_service_1.default.count('crm.lead', [['type', '=', 'opportunity']]),
            odoo_service_1.default.count('product.product', [['active', '=', true]]),
            odoo_service_1.default.count('sale.order', [])
        ]);
        res.json({
            odoo: {
                customers,
                leads,
                products,
                orders
            },
            pool: {
                total: await LeadCompany_1.default.countDocuments({ inPool: true }),
                fromOdoo: await LeadCompany_1.default.countDocuments({ 'lemlistData.source': { $in: ['odoo', 'odoo-crm'] } })
            }
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=crm.js.map