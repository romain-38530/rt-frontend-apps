/**
 * Lemlist API Service
 * Enrichissement de leads, validation emails, recherche contacts
 * Documentation: https://developer.lemlist.com/
 */
interface LemlistEnrichRequest {
    email?: string;
    firstName?: string;
    lastName?: string;
    companyName?: string;
    companyDomain?: string;
    linkedinUrl?: string;
    phone?: string;
}
interface LemlistEnrichResult {
    id: string;
    status: 'pending' | 'processing' | 'done' | 'failed';
    email?: string;
    emailStatus?: 'VALID' | 'INVALID' | 'RISKY' | 'UNKNOWN';
    phone?: string;
    phoneStatus?: string;
    firstName?: string;
    lastName?: string;
    companyName?: string;
    companyDomain?: string;
    linkedinUrl?: string;
    jobTitle?: string;
    location?: string;
    confidence?: number;
    raw?: any;
}
interface LemlistLead {
    _id?: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    companyName?: string;
    phone?: string;
    linkedinUrl?: string;
    position?: string;
    enrichedAt?: string;
    enrichmentStatus?: string;
}
interface LemlistCampaign {
    _id: string;
    name: string;
}
declare class LemlistService {
    private getHeaders;
    private request;
    /**
     * Enrichir un lead (trouver email, telephone, infos LinkedIn)
     */
    enrichLead(data: LemlistEnrichRequest): Promise<LemlistEnrichResult | null>;
    /**
     * Enrichir en masse (jusqu'a 500 entites)
     */
    bulkEnrich(entities: LemlistEnrichRequest[]): Promise<{
        enrichId: string;
    } | null>;
    /**
     * Recuperer le resultat d'un enrichissement
     */
    getEnrichmentResult(enrichId: string): Promise<LemlistEnrichResult | null>;
    /**
     * Trouver l'email d'une personne a partir de son nom et entreprise
     */
    findEmail(firstName: string, lastName: string, companyDomain: string): Promise<{
        email: string;
        status: string;
        confidence: number;
    } | null>;
    /**
     * Verifier un email
     */
    verifyEmail(email: string): Promise<{
        email: string;
        status: string;
        isValid: boolean;
    } | null>;
    /**
     * Trouver des contacts dans une entreprise via le domaine
     */
    findContactsByDomain(domain: string, jobTitles?: string[]): Promise<LemlistLead[]>;
    /**
     * Enrichir une entreprise (trouver infos + contacts cles)
     */
    enrichCompany(domain: string): Promise<{
        company: any;
        contacts: LemlistLead[];
    }>;
    /**
     * Lister les campagnes
     */
    getCampaigns(): Promise<LemlistCampaign[]>;
    /**
     * Ajouter un lead a une campagne
     */
    addLeadToCampaign(campaignId: string, lead: {
        email: string;
        firstName?: string;
        lastName?: string;
        companyName?: string;
        phone?: string;
        linkedinUrl?: string;
        customFields?: Record<string, string>;
    }): Promise<{
        success: boolean;
        leadId?: string;
    }>;
    /**
     * Mettre a jour un lead dans une campagne
     */
    updateLeadInCampaign(campaignId: string, email: string, data: Record<string, any>): Promise<boolean>;
    /**
     * Supprimer un lead d'une campagne
     */
    removeLeadFromCampaign(campaignId: string, email: string): Promise<boolean>;
    /**
     * Obtenir les statistiques d'un lead
     */
    getLeadActivity(campaignId: string, email: string): Promise<any>;
    /**
     * Ajouter a la liste de desabonnement
     */
    unsubscribeEmail(email: string): Promise<boolean>;
    /**
     * Verifier si un email est desabonne
     */
    isUnsubscribed(email: string): Promise<boolean>;
    /**
     * Mapper le statut email Lemlist vers notre format
     */
    mapEmailStatus(status?: string): 'VALID' | 'INVALID' | 'RISKY' | 'UNKNOWN';
    /**
     * Mapper la seniorite
     */
    mapSeniority(title?: string): 'director' | 'vp' | 'manager' | 'senior' | 'entry' | 'unknown';
}
declare const _default: LemlistService;
export default _default;
export { LemlistEnrichRequest, LemlistEnrichResult, LemlistLead };
//# sourceMappingURL=lemlist-service.d.ts.map