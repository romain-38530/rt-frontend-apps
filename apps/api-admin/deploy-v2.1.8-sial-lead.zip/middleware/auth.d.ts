/**
 * Middleware d'authentification Admin
 */
import { Request, Response, NextFunction } from 'express';
export interface AdminUser {
    id: string;
    email: string;
    roles: string[];
    companyId?: string;
}
export interface AuthRequest extends Request {
    user?: AdminUser;
}
export declare const authenticateAdmin: (req: AuthRequest, res: Response, next: NextFunction) => Response<any, Record<string, any>> | undefined;
export declare const requireRole: (...roles: string[]) => (req: AuthRequest, res: Response, next: NextFunction) => Response<any, Record<string, any>> | undefined;
export declare const generateAdminToken: (user: AdminUser) => string;
//# sourceMappingURL=auth.d.ts.map