import mongoose, { Document } from 'mongoose';
export type ProspectionStatus = 'NEW' | 'ENRICHED' | 'CONTACTED' | 'IN_PROGRESS' | 'CONVERTED' | 'LOST' | 'BLACKLISTED';
export interface ILeadCompany extends Document {
    raisonSociale: string;
    formeJuridique?: string;
    siren?: string;
    siret?: string;
    tvaIntracommunautaire?: string;
    adresse: {
        ligne1?: string;
        ligne2?: string;
        codePostal?: string;
        ville?: string;
        pays: string;
    };
    telephone?: string;
    emailGenerique?: string;
    siteWeb?: string;
    linkedinCompanyUrl?: string;
    secteurActivite?: string;
    codeNaf?: string;
    effectifTranche?: string;
    chiffreAffairesTranche?: string;
    descriptionActivite?: string;
    apolloOrgId?: string;
    apolloData?: Record<string, unknown>;
    dateEnrichissementApollo?: Date;
    lemlistData?: Record<string, unknown>;
    dateEnrichissement?: Date;
    salonSourceId?: mongoose.Types.ObjectId;
    urlPageExposant?: string;
    numeroStand?: string;
    statutProspection: ProspectionStatus;
    commercialAssigneId?: mongoose.Types.ObjectId;
    dateAssignation?: Date;
    scoreLead?: number;
    inPool: boolean;
    dateAddedToPool?: Date;
    nbContactsEnrichis?: number;
    lastContactAttempt?: Date;
    prioritePool?: number;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ILeadCompany, {}, {}, {}, mongoose.Document<unknown, {}, ILeadCompany, {}, {}> & ILeadCompany & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=LeadCompany.d.ts.map