"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * CRM Routes - Lead Generation & Management
 */
const express_1 = require("express");
const LeadSalon_1 = __importDefault(require("../models/LeadSalon"));
const LeadCompany_1 = __importDefault(require("../models/LeadCompany"));
const LeadContact_1 = __importDefault(require("../models/LeadContact"));
const LeadEmail_1 = __importDefault(require("../models/LeadEmail"));
const LeadEmailTemplate_1 = __importDefault(require("../models/LeadEmailTemplate"));
const LeadInteraction_1 = __importDefault(require("../models/LeadInteraction"));
const lemlist_service_1 = __importDefault(require("../services/lemlist-service"));
const email_service_1 = __importDefault(require("../services/email-service"));
const scraping_service_1 = __importStar(require("../services/scraping-service"));
const salon_discovery_service_1 = __importDefault(require("../services/salon-discovery-service"));
const lead_enrichment_service_1 = __importDefault(require("../services/lead-enrichment-service"));
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// Apply auth middleware to all routes except webhook
router.use((req, res, next) => {
    // Allow webhook without auth
    if (req.path === '/emails/webhook') {
        return next();
    }
    return (0, auth_1.authenticateAdmin)(req, res, next);
});
// ==================== DASHBOARD ====================
router.get('/dashboard', async (req, res) => {
    try {
        const now = new Date();
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const [totalCompanies, totalContacts, companiesThisWeek, contactsThisWeek, emailsSent, emailsOpened, companiesByStatus, companiesByCountry, recentInteractions] = await Promise.all([
            LeadCompany_1.default.countDocuments(),
            LeadContact_1.default.countDocuments(),
            LeadCompany_1.default.countDocuments({ createdAt: { $gte: weekAgo } }),
            LeadContact_1.default.countDocuments({ createdAt: { $gte: weekAgo } }),
            LeadEmail_1.default.countDocuments({ dateEnvoi: { $gte: monthAgo } }),
            LeadEmail_1.default.countDocuments({ dateEnvoi: { $gte: monthAgo }, statutEnvoi: 'OPENED' }),
            LeadCompany_1.default.aggregate([
                { $group: { _id: '$statutProspection', count: { $sum: 1 } } }
            ]),
            LeadCompany_1.default.aggregate([
                { $group: { _id: '$adresse.pays', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ]),
            LeadInteraction_1.default.find()
                .sort({ createdAt: -1 })
                .limit(20)
                .populate('entrepriseId', 'raisonSociale')
                .populate('contactId', 'prenom nom')
        ]);
        const openRate = emailsSent > 0 ? ((emailsOpened / emailsSent) * 100).toFixed(1) : 0;
        res.json({
            stats: {
                totalCompanies,
                totalContacts,
                companiesThisWeek,
                contactsThisWeek,
                emailsSent,
                emailsOpened,
                openRate: `${openRate}%`
            },
            companiesByStatus,
            companiesByCountry,
            recentInteractions
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== SALONS ====================
router.get('/salons', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, pays, search } = req.query;
        const filter = {};
        if (status)
            filter.statutScraping = status;
        if (pays)
            filter.pays = pays;
        if (search)
            filter.nom = { $regex: search, $options: 'i' };
        const skip = (Number(page) - 1) * Number(limit);
        const [salons, total] = await Promise.all([
            LeadSalon_1.default.find(filter).sort({ dateDebut: -1 }).skip(skip).limit(Number(limit)),
            LeadSalon_1.default.countDocuments(filter)
        ]);
        res.json({ data: salons, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/salons', async (req, res) => {
    try {
        const salon = new LeadSalon_1.default(req.body);
        await salon.save();
        res.status(201).json(salon);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.get('/salons/:id', async (req, res) => {
    try {
        const salon = await LeadSalon_1.default.findById(req.params.id);
        if (!salon)
            return res.status(404).json({ error: 'Salon not found' });
        res.json(salon);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put('/salons/:id', async (req, res) => {
    try {
        const salon = await LeadSalon_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!salon)
            return res.status(404).json({ error: 'Salon not found' });
        res.json(salon);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Lancer le scraping d'un salon
router.post('/salons/:id/scrape', async (req, res) => {
    try {
        const salon = await LeadSalon_1.default.findById(req.params.id);
        if (!salon)
            return res.status(404).json({ error: 'Salon not found' });
        if (!salon.urlListeExposants) {
            return res.status(400).json({ error: 'URL des exposants non configuree pour ce salon' });
        }
        // Mettre a jour le statut
        salon.statutScraping = 'EN_COURS';
        salon.derniereExecution = new Date();
        await salon.save();
        // Determiner l'adaptateur
        const adaptateurConfig = salon.adaptateurConfig || {};
        const adapterName = adaptateurConfig.type || 'Generic';
        const config = {
            maxPages: adaptateurConfig.maxPages || 10,
            delay: adaptateurConfig.delay || 2000
        };
        // Lancer le scraping
        const result = await scraping_service_1.default.scrapeUrl(salon.urlListeExposants, adapterName, config);
        if (result.success && result.companies.length > 0) {
            // Creer les entreprises
            let created = 0;
            let duplicates = 0;
            for (const company of result.companies) {
                // Verifier si l'entreprise existe deja (par nom ou site web)
                const existingCompany = await LeadCompany_1.default.findOne({
                    $or: [
                        { raisonSociale: { $regex: `^${company.raisonSociale}$`, $options: 'i' } },
                        ...(company.siteWeb ? [{ siteWeb: { $regex: company.siteWeb, $options: 'i' } }] : [])
                    ]
                });
                if (existingCompany) {
                    duplicates++;
                    continue;
                }
                // Creer la nouvelle entreprise
                await LeadCompany_1.default.create({
                    raisonSociale: company.raisonSociale,
                    siteWeb: company.siteWeb,
                    adresse: {
                        ville: company.ville,
                        pays: company.pays || scraping_service_1.ScrapingService.guessCountry(company.raisonSociale + ' ' + (company.ville || ''))
                    },
                    telephone: company.telephone,
                    emailGenerique: company.email,
                    secteurActivite: company.secteurActivite || 'Transport & Logistique',
                    descriptionActivite: company.descriptionActivite,
                    salonSourceId: salon._id,
                    urlPageExposant: company.urlPageExposant,
                    numeroStand: company.numeroStand,
                    statutProspection: 'NEW'
                });
                created++;
            }
            // Mettre a jour le salon
            salon.statutScraping = 'TERMINE';
            salon.nbExposantsCollectes = (salon.nbExposantsCollectes || 0) + created;
            await salon.save();
            // Log interaction
            await LeadInteraction_1.default.create({
                typeInteraction: 'SCRAPING',
                description: `Scraping ${salon.nom}: ${created} nouvelles entreprises, ${duplicates} doublons`,
                metadata: {
                    salonId: salon._id,
                    totalScraped: result.totalScraped,
                    created,
                    duplicates,
                    duration: result.duration
                },
                createdBy: 'system'
            });
            // AUTO-ENRICHISSEMENT: Lancer l'enrichissement en arriere-plan
            let enrichmentStatus = { enrichmentStarted: false, message: '' };
            if (created > 0) {
                try {
                    enrichmentStatus = await lead_enrichment_service_1.default.postScrapingEnrichment(salon._id.toString(), Math.min(created, 30));
                    console.log(`[CRM] Post-scraping enrichment: ${enrichmentStatus.message}`);
                }
                catch (e) {
                    console.error('[CRM] Post-scraping enrichment error:', e);
                }
                // AUTO-POOL: Ajouter au pool les entreprises avec site web
                try {
                    const poolResult = await LeadCompany_1.default.updateMany({
                        salonSourceId: salon._id,
                        siteWeb: { $exists: true, $ne: '' },
                        inPool: { $ne: true },
                        commercialAssigneId: { $exists: false }
                    }, {
                        $set: {
                            inPool: true,
                            dateAddedToPool: new Date(),
                            prioritePool: 3
                        }
                    });
                    console.log(`[CRM] Added ${poolResult.modifiedCount} companies to pool`);
                }
                catch (e) {
                    console.error('[CRM] Auto-pool error:', e);
                }
            }
            res.json({
                success: true,
                totalScraped: result.totalScraped,
                companiesCreated: created,
                duplicatesSkipped: duplicates,
                duration: result.duration,
                enrichment: enrichmentStatus
            });
        }
        else {
            salon.statutScraping = 'ERREUR';
            await salon.save();
            res.status(400).json({
                success: false,
                error: result.errors.join(', ') || 'Aucune entreprise trouvee',
                duration: result.duration
            });
        }
    }
    catch (error) {
        // Mettre a jour le statut en cas d'erreur
        try {
            await LeadSalon_1.default.findByIdAndUpdate(req.params.id, { statutScraping: 'ERREUR' });
        }
        catch { }
        res.status(500).json({ error: error.message });
    }
});
// Obtenir les adaptateurs disponibles
router.get('/scraping/adapters', async (req, res) => {
    try {
        const adapters = scraping_service_1.default.getAvailableAdapters();
        res.json({
            adapters: adapters.map(name => ({
                name,
                description: getAdapterDescription(name)
            }))
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Test de scraping (sans sauvegarde)
router.post('/scraping/test', async (req, res) => {
    try {
        const { url, adapter = 'Generic', maxPages = 3 } = req.body;
        if (!url) {
            return res.status(400).json({ error: 'URL requise' });
        }
        const result = await scraping_service_1.default.scrapeUrl(url, adapter, { maxPages });
        res.json({
            success: result.success,
            preview: result.companies.slice(0, 10), // Apercu des 10 premiers
            totalFound: result.totalScraped,
            errors: result.errors,
            duration: result.duration
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
function getAdapterDescription(name) {
    const descriptions = {
        'SITL': 'Salon International du Transport et de la Logistique (Paris)',
        'TransportLogistic': 'Transport Logistic Munich',
        'Generic': 'Adaptateur generique pour sites avec liste d\'exposants standard'
    };
    return descriptions[name] || 'Adaptateur personnalise';
}
// ==================== COMPANIES ====================
router.get('/companies', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, pays, secteur, search, commercialId, salonId } = req.query;
        const filter = {};
        if (status)
            filter.statutProspection = status;
        if (pays)
            filter['adresse.pays'] = pays;
        if (secteur)
            filter.secteurActivite = secteur;
        if (commercialId)
            filter.commercialAssigneId = commercialId;
        if (salonId)
            filter.salonSourceId = salonId;
        if (search) {
            filter.$or = [
                { raisonSociale: { $regex: search, $options: 'i' } },
                { siteWeb: { $regex: search, $options: 'i' } }
            ];
        }
        const skip = (Number(page) - 1) * Number(limit);
        const [companies, total] = await Promise.all([
            LeadCompany_1.default.find(filter)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('salonSourceId', 'nom')
                .populate('commercialAssigneId', 'firstName lastName'),
            LeadCompany_1.default.countDocuments(filter)
        ]);
        res.json({ data: companies, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/companies', async (req, res) => {
    try {
        const company = new LeadCompany_1.default(req.body);
        await company.save();
        // Créer interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            typeInteraction: 'CREATION',
            description: 'Entreprise créée',
            createdBy: 'system'
        });
        res.status(201).json(company);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.get('/companies/:id', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id)
            .populate('salonSourceId', 'nom')
            .populate('commercialAssigneId', 'firstName lastName email');
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        // Récupérer contacts et interactions
        const [contacts, interactions, emails] = await Promise.all([
            LeadContact_1.default.find({ entrepriseId: company._id }).sort({ estContactPrincipal: -1 }),
            LeadInteraction_1.default.find({ entrepriseId: company._id }).sort({ createdAt: -1 }).limit(50),
            LeadEmail_1.default.find({ entrepriseId: company._id }).sort({ dateEnvoi: -1 }).limit(20)
        ]);
        res.json({ company, contacts, interactions, emails });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put('/companies/:id', async (req, res) => {
    try {
        const oldCompany = await LeadCompany_1.default.findById(req.params.id);
        const company = await LeadCompany_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        // Log changement de statut
        if (oldCompany && oldCompany.statutProspection !== company.statutProspection) {
            await LeadInteraction_1.default.create({
                entrepriseId: company._id,
                typeInteraction: 'CHANGEMENT_STATUT',
                description: `Statut: ${oldCompany.statutProspection} → ${company.statutProspection}`,
                createdBy: 'admin'
            });
        }
        res.json(company);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Enrichir une entreprise via Lemlist
router.post('/companies/:id/enrich', async (req, res) => {
    try {
        const company = await LeadCompany_1.default.findById(req.params.id);
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        if (!company.siteWeb) {
            return res.status(400).json({ error: 'No website URL available for enrichment' });
        }
        // Extraire le domaine
        let domain;
        try {
            domain = new URL(company.siteWeb.startsWith('http') ? company.siteWeb : `https://${company.siteWeb}`).hostname.replace('www.', '');
        }
        catch {
            domain = company.siteWeb.replace('www.', '').split('/')[0];
        }
        // Appeler Lemlist pour enrichir l'entreprise et trouver des contacts
        const { company: enrichedCompany, contacts } = await lemlist_service_1.default.enrichCompany(domain);
        if (enrichedCompany) {
            // Mettre a jour l'entreprise
            company.lemlistData = enrichedCompany;
            company.dateEnrichissement = new Date();
            if (enrichedCompany.linkedinUrl)
                company.linkedinCompanyUrl = enrichedCompany.linkedinUrl;
            company.statutProspection = 'ENRICHED';
            await company.save();
        }
        // Creer les contacts
        const createdContacts = [];
        for (const lemlistContact of contacts) {
            if (!lemlistContact.email)
                continue;
            const existingContact = await LeadContact_1.default.findOne({
                entrepriseId: company._id,
                email: lemlistContact.email.toLowerCase()
            });
            if (!existingContact) {
                const contact = await LeadContact_1.default.create({
                    entrepriseId: company._id,
                    prenom: lemlistContact.firstName,
                    nom: lemlistContact.lastName,
                    poste: lemlistContact.position,
                    email: lemlistContact.email.toLowerCase(),
                    emailStatus: lemlist_service_1.default.mapEmailStatus(lemlistContact.enrichmentStatus),
                    linkedinUrl: lemlistContact.linkedinUrl,
                    telephoneDirect: lemlistContact.phone,
                    seniority: lemlist_service_1.default.mapSeniority(lemlistContact.position),
                    sourceEnrichissement: 'LEMLIST',
                    dateEnrichissement: new Date()
                });
                createdContacts.push(contact);
            }
        }
        // Marquer le premier contact comme principal si aucun n'existe
        if (createdContacts.length > 0) {
            const hasMainContact = await LeadContact_1.default.findOne({
                entrepriseId: company._id,
                estContactPrincipal: true
            });
            if (!hasMainContact) {
                createdContacts[0].estContactPrincipal = true;
                await createdContacts[0].save();
            }
        }
        // Log interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            typeInteraction: 'ENRICHISSEMENT',
            description: `Enrichissement Lemlist: ${createdContacts.length} contacts trouves`,
            metadata: { domain, contactsCount: createdContacts.length },
            createdBy: 'system'
        });
        res.json({
            success: true,
            company: enrichedCompany,
            contactsCreated: createdContacts.length,
            contacts: createdContacts
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Assigner un commercial
router.post('/companies/:id/assign', async (req, res) => {
    try {
        const { commercialId } = req.body;
        const company = await LeadCompany_1.default.findByIdAndUpdate(req.params.id, {
            commercialAssigneId: commercialId,
            dateAssignation: new Date()
        }, { new: true }).populate('commercialAssigneId', 'firstName lastName');
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            commercialId,
            typeInteraction: 'ASSIGNATION',
            description: 'Commercial assigné',
            createdBy: 'admin'
        });
        res.json(company);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== CONTACTS ====================
router.get('/contacts', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, emailStatus, entrepriseId, search } = req.query;
        const filter = {};
        if (status)
            filter.statutContact = status;
        if (emailStatus)
            filter.emailStatus = emailStatus;
        if (entrepriseId)
            filter.entrepriseId = entrepriseId;
        if (search) {
            filter.$or = [
                { nom: { $regex: search, $options: 'i' } },
                { prenom: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } },
                { poste: { $regex: search, $options: 'i' } }
            ];
        }
        const skip = (Number(page) - 1) * Number(limit);
        const [contacts, total] = await Promise.all([
            LeadContact_1.default.find(filter)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('entrepriseId', 'raisonSociale'),
            LeadContact_1.default.countDocuments(filter)
        ]);
        res.json({ data: contacts, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/contacts', async (req, res) => {
    try {
        const contact = new LeadContact_1.default(req.body);
        await contact.save();
        res.status(201).json(contact);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.get('/contacts/:id', async (req, res) => {
    try {
        const contact = await LeadContact_1.default.findById(req.params.id)
            .populate('entrepriseId');
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        const emails = await LeadEmail_1.default.find({ contactId: contact._id }).sort({ dateEnvoi: -1 });
        res.json({ contact, emails });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put('/contacts/:id', async (req, res) => {
    try {
        const contact = await LeadContact_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        res.json(contact);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Verifier email via Lemlist
router.post('/contacts/:id/verify-email', async (req, res) => {
    try {
        const contact = await LeadContact_1.default.findById(req.params.id);
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        if (!contact.email)
            return res.status(400).json({ error: 'No email to verify' });
        const result = await lemlist_service_1.default.verifyEmail(contact.email);
        if (result) {
            contact.emailStatus = lemlist_service_1.default.mapEmailStatus(result.status);
            contact.lemlistData = { verification: result };
            await contact.save();
        }
        res.json({ success: true, contact, verification: result });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== EMAILS ====================
router.get('/emails', async (req, res) => {
    try {
        const { page = 1, limit = 20, status, type, contactId, entrepriseId } = req.query;
        const filter = {};
        if (status)
            filter.statutEnvoi = status;
        if (type)
            filter.typeEmail = type;
        if (contactId)
            filter.contactId = contactId;
        if (entrepriseId)
            filter.entrepriseId = entrepriseId;
        const skip = (Number(page) - 1) * Number(limit);
        const [emails, total] = await Promise.all([
            LeadEmail_1.default.find(filter)
                .sort({ dateEnvoi: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('contactId', 'prenom nom email')
                .populate('entrepriseId', 'raisonSociale'),
            LeadEmail_1.default.countDocuments(filter)
        ]);
        res.json({ data: emails, total, page: Number(page), limit: Number(limit) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Envoyer un email
router.post('/emails/send', async (req, res) => {
    try {
        const { contactId, templateId, customSubject, customHtml, variables } = req.body;
        const contact = await LeadContact_1.default.findById(contactId).populate('entrepriseId');
        if (!contact)
            return res.status(404).json({ error: 'Contact not found' });
        if (!contact.email)
            return res.status(400).json({ error: 'Contact has no email' });
        if (contact.optOut)
            return res.status(400).json({ error: 'Contact opted out' });
        let subject = customSubject;
        let html = customHtml;
        // Si template, récupérer le contenu
        if (templateId) {
            const template = await LeadEmailTemplate_1.default.findOne({ code: templateId, actif: true });
            if (!template)
                return res.status(404).json({ error: 'Template not found' });
            subject = template.sujetTemplate;
            html = template.corpsHtmlTemplate;
        }
        // Préparer les variables
        const company = contact.entrepriseId;
        const emailVariables = {
            prenom: contact.prenom || '',
            nom: contact.nom || '',
            poste: contact.poste || '',
            entreprise: company?.raisonSociale || '',
            ...variables
        };
        // Créer l'entrée email
        const leadEmail = new LeadEmail_1.default({
            contactId: contact._id,
            entrepriseId: company?._id,
            typeEmail: templateId ? 'PRESENTATION' : 'MANUEL',
            templateId,
            sujet: subject,
            corpsHtml: html,
            langue: 'fr',
            expediteurEmail: 'commerce@symphonia-controltower.com',
            expediteurNom: 'Equipe Commerciale SYMPHONI.A',
            statutEnvoi: 'PENDING'
        });
        await leadEmail.save();
        // Envoyer via SMTP OVH
        const result = await email_service_1.default.sendTemplateEmail({
            to: contact.email,
            templateHtml: html,
            templateSubject: subject,
            variables: emailVariables
        });
        if (result && result.success) {
            leadEmail.mailgunMessageId = result.id; // Keep field for tracking
            leadEmail.dateEnvoi = new Date();
            leadEmail.statutEnvoi = 'SENT';
            await leadEmail.save();
            // Mettre à jour le contact
            contact.statutContact = 'CONTACTED';
            await contact.save();
            // Log interaction
            await LeadInteraction_1.default.create({
                entrepriseId: company?._id,
                contactId: contact._id,
                typeInteraction: 'EMAIL_ENVOYE',
                emailId: leadEmail._id,
                description: `Email envoyé: ${subject}`,
                createdBy: 'system'
            });
            res.json({ success: true, email: leadEmail, mailgunId: result.id });
        }
        else {
            leadEmail.statutEnvoi = 'FAILED';
            await leadEmail.save();
            res.status(500).json({ error: 'Failed to send email' });
        }
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Webhook Email Tracking (for future use)
router.post('/emails/webhook', async (req, res) => {
    try {
        const { event, messageId, timestamp, url, deliveryStatus } = req.body;
        if (!event || !messageId)
            return res.status(400).json({ error: 'Invalid webhook payload' });
        const email = await LeadEmail_1.default.findOne({ mailgunMessageId: { $regex: messageId } });
        if (!email)
            return res.status(200).json({ received: true });
        // Mettre a jour selon l'evenement
        const status = email_service_1.default.mapEventToStatus(event);
        const eventTime = timestamp ? new Date(timestamp * 1000) : new Date();
        switch (event) {
            case 'delivered':
                email.dateDelivered = eventTime;
                email.statutEnvoi = 'DELIVERED';
                break;
            case 'opened':
                email.dateOpened = email.dateOpened || eventTime;
                email.nbOpens += 1;
                email.statutEnvoi = 'OPENED';
                await LeadInteraction_1.default.create({
                    entrepriseId: email.entrepriseId,
                    contactId: email.contactId,
                    typeInteraction: 'EMAIL_OUVERT',
                    emailId: email._id,
                    createdBy: 'webhook'
                });
                break;
            case 'clicked':
                email.dateClicked = email.dateClicked || eventTime;
                email.nbClicks += 1;
                if (url)
                    email.linksClicked.push(url);
                email.statutEnvoi = 'CLICKED';
                await LeadInteraction_1.default.create({
                    entrepriseId: email.entrepriseId,
                    contactId: email.contactId,
                    typeInteraction: 'EMAIL_CLICKED',
                    emailId: email._id,
                    metadata: { url },
                    createdBy: 'webhook'
                });
                break;
            case 'bounced':
            case 'failed':
                email.statutEnvoi = 'BOUNCED';
                email.bounceType = deliveryStatus?.code?.toString();
                email.bounceMessage = deliveryStatus?.message;
                // Marquer le contact comme bounced
                await LeadContact_1.default.findByIdAndUpdate(email.contactId, {
                    emailStatus: 'INVALID',
                    statutContact: 'BOUNCED'
                });
                break;
            case 'complained':
                email.statutEnvoi = 'COMPLAINED';
                await LeadContact_1.default.findByIdAndUpdate(email.contactId, { optOut: true, dateOptOut: new Date() });
                break;
            case 'unsubscribed':
                email.statutEnvoi = 'UNSUBSCRIBED';
                await LeadContact_1.default.findByIdAndUpdate(email.contactId, { optOut: true, dateOptOut: new Date() });
                break;
        }
        await email.save();
        res.status(200).json({ received: true });
    }
    catch (error) {
        console.error('[CRM Webhook Error]', error);
        res.status(500).json({ error: error.message });
    }
});
// ==================== TEMPLATES ====================
router.get('/templates', async (req, res) => {
    try {
        const { type, langue, actif } = req.query;
        const filter = {};
        if (type)
            filter.typeEmail = type;
        if (langue)
            filter.langue = langue;
        if (actif !== undefined)
            filter.actif = actif === 'true';
        const templates = await LeadEmailTemplate_1.default.find(filter).sort({ typeEmail: 1, langue: 1 });
        res.json(templates);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post('/templates', async (req, res) => {
    try {
        const template = new LeadEmailTemplate_1.default(req.body);
        await template.save();
        res.status(201).json(template);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
router.put('/templates/:id', async (req, res) => {
    try {
        const template = await LeadEmailTemplate_1.default.findByIdAndUpdate(req.params.id, { ...req.body, version: (req.body.version || 1) + 1 }, { new: true });
        if (!template)
            return res.status(404).json({ error: 'Template not found' });
        res.json(template);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// ==================== INTERACTIONS (Notes) ====================
router.post('/interactions', async (req, res) => {
    try {
        const interaction = new LeadInteraction_1.default(req.body);
        await interaction.save();
        res.status(201).json(interaction);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// ==================== SALON DISCOVERY ====================
// Obtenir les salons connus + decouvrir de nouveaux
router.get('/discovery/salons', async (req, res) => {
    try {
        const { year, countries, discover } = req.query;
        const config = {
            year: year ? Number(year) : new Date().getFullYear(),
            countries: countries ? String(countries).split(',') : []
        };
        // Par defaut, retourner uniquement les salons connus
        if (discover !== 'true') {
            const known = salon_discovery_service_1.default.getKnownSalons(config);
            return res.json({
                success: true,
                known,
                discovered: [],
                total: known.length
            });
        }
        // Recherche complete avec decouverte web
        const result = await salon_discovery_service_1.default.discoverAll(config);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Importer un salon decouvert dans la base
router.post('/discovery/import', async (req, res) => {
    try {
        const { salon } = req.body;
        if (!salon || !salon.nom || !salon.pays) {
            return res.status(400).json({ error: 'Salon invalide (nom et pays requis)' });
        }
        // Verifier si le salon existe deja
        const existing = await LeadSalon_1.default.findOne({
            nom: { $regex: new RegExp(salon.nom, 'i') },
            edition: salon.edition
        });
        if (existing) {
            return res.status(400).json({ error: 'Ce salon existe deja', salonId: existing._id });
        }
        // Creer le salon
        const newSalon = await LeadSalon_1.default.create({
            nom: salon.nom,
            edition: salon.edition,
            pays: salon.pays,
            lieu: salon.lieu,
            url: salon.url,
            urlListeExposants: salon.urlListeExposants,
            descriptionActivite: salon.description,
            adaptateur: 'Generic',
            statutScraping: 'A_SCRAPER',
            sourceDecouverte: salon.source
        });
        res.status(201).json({ success: true, salon: newSalon });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== ENRICHISSEMENT AUTOMATIQUE ====================
// Enrichir une entreprise specifique
router.post('/enrichment/company/:id', async (req, res) => {
    try {
        const result = await lead_enrichment_service_1.default.enrichCompany(req.params.id);
        res.json({
            success: result.errors.length === 0,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Enrichir toutes les entreprises d'un salon
router.post('/enrichment/salon/:salonId', async (req, res) => {
    try {
        const { limit = 50 } = req.body;
        const result = await lead_enrichment_service_1.default.enrichSalonCompanies(req.params.salonId, limit);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Enrichir les nouvelles entreprises (batch)
router.post('/enrichment/batch', async (req, res) => {
    try {
        const { limit = 20 } = req.body;
        const result = await lead_enrichment_service_1.default.enrichNewCompanies(limit);
        res.json({
            success: true,
            ...result
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==================== POOL DE LEADS (COMMERCIAUX) ====================
// Obtenir les leads du pool (disponibles pour les commerciaux)
router.get('/pool', async (req, res) => {
    try {
        const { page = 1, limit = 20, pays, secteur, minScore, priorite, hasContacts, search } = req.query;
        const filter = {
            inPool: true,
            commercialAssigneId: { $exists: false }
        };
        if (pays)
            filter['adresse.pays'] = pays;
        if (secteur)
            filter.secteurActivite = secteur;
        if (minScore)
            filter.scoreLead = { $gte: Number(minScore) };
        if (priorite)
            filter.prioritePool = Number(priorite);
        if (hasContacts === 'true')
            filter.nbContactsEnrichis = { $gt: 0 };
        if (search) {
            filter.$or = [
                { raisonSociale: { $regex: search, $options: 'i' } },
                { siteWeb: { $regex: search, $options: 'i' } },
                { descriptionActivite: { $regex: search, $options: 'i' } }
            ];
        }
        const skip = (Number(page) - 1) * Number(limit);
        const [leads, total, stats] = await Promise.all([
            LeadCompany_1.default.find(filter)
                .sort({ prioritePool: -1, scoreLead: -1, dateAddedToPool: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('salonSourceId', 'nom'),
            LeadCompany_1.default.countDocuments(filter),
            LeadCompany_1.default.aggregate([
                { $match: { inPool: true, commercialAssigneId: { $exists: false } } },
                {
                    $group: {
                        _id: null,
                        totalLeads: { $sum: 1 },
                        avgScore: { $avg: '$scoreLead' },
                        withContacts: { $sum: { $cond: [{ $gt: ['$nbContactsEnrichis', 0] }, 1, 0] } },
                        byPriority: {
                            $push: {
                                priorite: '$prioritePool',
                                count: 1
                            }
                        }
                    }
                }
            ])
        ]);
        // Stats par pays
        const byCountry = await LeadCompany_1.default.aggregate([
            { $match: { inPool: true, commercialAssigneId: { $exists: false } } },
            { $group: { _id: '$adresse.pays', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 10 }
        ]);
        res.json({
            data: leads,
            total,
            page: Number(page),
            limit: Number(limit),
            stats: stats[0] || { totalLeads: 0, avgScore: 0, withContacts: 0 },
            byCountry
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Ajouter des leads au pool
router.post('/pool/add', async (req, res) => {
    try {
        const { companyIds, salonId, criteria, priorite = 3 } = req.body;
        let filter = {};
        if (companyIds && companyIds.length > 0) {
            filter._id = { $in: companyIds };
        }
        else if (salonId) {
            filter.salonSourceId = salonId;
        }
        else if (criteria) {
            // Criteres dynamiques: pays, hasWebsite, hasContacts, minScore
            if (criteria.pays)
                filter['adresse.pays'] = criteria.pays;
            if (criteria.hasWebsite)
                filter.siteWeb = { $exists: true, $ne: '' };
            if (criteria.hasContacts)
                filter.nbContactsEnrichis = { $gt: 0 };
            if (criteria.minScore)
                filter.scoreLead = { $gte: criteria.minScore };
            if (criteria.statut)
                filter.statutProspection = criteria.statut;
        }
        else {
            return res.status(400).json({ error: 'Specifiez companyIds, salonId ou criteria' });
        }
        // Exclure ceux deja dans le pool ou deja assignes
        filter.inPool = { $ne: true };
        filter.commercialAssigneId = { $exists: false };
        const result = await LeadCompany_1.default.updateMany(filter, {
            $set: {
                inPool: true,
                dateAddedToPool: new Date(),
                prioritePool: priorite
            }
        });
        res.json({
            success: true,
            addedToPool: result.modifiedCount
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Retirer des leads du pool
router.post('/pool/remove', async (req, res) => {
    try {
        const { companyIds } = req.body;
        if (!companyIds || companyIds.length === 0) {
            return res.status(400).json({ error: 'companyIds requis' });
        }
        const result = await LeadCompany_1.default.updateMany({ _id: { $in: companyIds }, commercialAssigneId: { $exists: false } }, { $set: { inPool: false }, $unset: { dateAddedToPool: 1, prioritePool: 1 } });
        res.json({
            success: true,
            removedFromPool: result.modifiedCount
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// S'affecter un lead (pour un commercial)
router.post('/pool/claim/:companyId', async (req, res) => {
    try {
        const { commercialId, commercialName } = req.body;
        if (!commercialId) {
            return res.status(400).json({ error: 'commercialId requis' });
        }
        // Verifier que le lead est disponible
        const company = await LeadCompany_1.default.findOne({
            _id: req.params.companyId,
            inPool: true,
            commercialAssigneId: { $exists: false }
        });
        if (!company) {
            return res.status(400).json({ error: 'Lead non disponible ou deja assigne' });
        }
        // Affecter le lead
        company.commercialAssigneId = commercialId;
        company.dateAssignation = new Date();
        company.inPool = false;
        company.statutProspection = 'IN_PROGRESS';
        await company.save();
        // Logger l'interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            commercialId,
            typeInteraction: 'ASSIGNATION',
            description: `Lead reclame par ${commercialName || commercialId}`,
            createdBy: commercialId
        });
        // Recuperer les contacts pour ce lead
        const contacts = await LeadContact_1.default.find({ entrepriseId: company._id });
        res.json({
            success: true,
            company,
            contacts,
            message: 'Lead assigne avec succes'
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Liberer un lead (le remettre dans le pool)
router.post('/pool/release/:companyId', async (req, res) => {
    try {
        const { commercialId, reason } = req.body;
        const company = await LeadCompany_1.default.findById(req.params.companyId);
        if (!company) {
            return res.status(404).json({ error: 'Lead non trouve' });
        }
        // Verifier que le commercial est bien assigne
        if (company.commercialAssigneId?.toString() !== commercialId) {
            return res.status(403).json({ error: 'Vous n\'etes pas assigne a ce lead' });
        }
        // Liberer le lead
        company.commercialAssigneId = undefined;
        company.dateAssignation = undefined;
        company.inPool = true;
        company.dateAddedToPool = new Date();
        company.statutProspection = 'ENRICHED';
        await company.save();
        // Logger l'interaction
        await LeadInteraction_1.default.create({
            entrepriseId: company._id,
            commercialId,
            typeInteraction: 'RELEASE',
            description: `Lead libere. Raison: ${reason || 'Non specifiee'}`,
            createdBy: commercialId
        });
        res.json({
            success: true,
            message: 'Lead remis dans le pool'
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Obtenir mes leads (pour un commercial)
router.get('/pool/my-leads/:commercialId', async (req, res) => {
    try {
        const { page = 1, limit = 20, status } = req.query;
        const filter = {
            commercialAssigneId: req.params.commercialId
        };
        if (status)
            filter.statutProspection = status;
        const skip = (Number(page) - 1) * Number(limit);
        const [leads, total, stats] = await Promise.all([
            LeadCompany_1.default.find(filter)
                .sort({ dateAssignation: -1 })
                .skip(skip)
                .limit(Number(limit))
                .populate('salonSourceId', 'nom'),
            LeadCompany_1.default.countDocuments(filter),
            LeadCompany_1.default.aggregate([
                { $match: { commercialAssigneId: req.params.commercialId } },
                {
                    $group: {
                        _id: '$statutProspection',
                        count: { $sum: 1 }
                    }
                }
            ])
        ]);
        // Recuperer les contacts pour chaque lead
        const leadsWithContacts = await Promise.all(leads.map(async (lead) => {
            const contacts = await LeadContact_1.default.find({ entrepriseId: lead._id })
                .select('prenom nom email poste emailStatus')
                .limit(5);
            return {
                ...lead.toObject(),
                contacts
            };
        }));
        res.json({
            data: leadsWithContacts,
            total,
            page: Number(page),
            limit: Number(limit),
            statsByStatus: stats.reduce((acc, s) => {
                acc[s._id] = s.count;
                return acc;
            }, {})
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// Stats du pool
router.get('/pool/stats', async (req, res) => {
    try {
        const [poolStats, byCountry, bySector, topCommercials] = await Promise.all([
            LeadCompany_1.default.aggregate([
                {
                    $facet: {
                        total: [{ $count: 'count' }],
                        inPool: [{ $match: { inPool: true, commercialAssigneId: { $exists: false } } }, { $count: 'count' }],
                        assigned: [{ $match: { commercialAssigneId: { $exists: true } } }, { $count: 'count' }],
                        withContacts: [{ $match: { nbContactsEnrichis: { $gt: 0 } } }, { $count: 'count' }],
                        avgScore: [{ $group: { _id: null, avg: { $avg: '$scoreLead' } } }]
                    }
                }
            ]),
            LeadCompany_1.default.aggregate([
                { $match: { inPool: true } },
                { $group: { _id: '$adresse.pays', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ]),
            LeadCompany_1.default.aggregate([
                { $match: { inPool: true } },
                { $group: { _id: '$secteurActivite', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ]),
            LeadCompany_1.default.aggregate([
                { $match: { commercialAssigneId: { $exists: true } } },
                { $group: { _id: '$commercialAssigneId', count: { $sum: 1 } } },
                { $sort: { count: -1 } },
                { $limit: 10 }
            ])
        ]);
        const stats = poolStats[0];
        res.json({
            total: stats.total[0]?.count || 0,
            inPool: stats.inPool[0]?.count || 0,
            assigned: stats.assigned[0]?.count || 0,
            withContacts: stats.withContacts[0]?.count || 0,
            avgScore: Math.round(stats.avgScore[0]?.avg || 0),
            byCountry,
            bySector,
            topCommercials
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=crm.js.map