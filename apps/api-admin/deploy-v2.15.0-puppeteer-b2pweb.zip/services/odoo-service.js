"use strict";
/**
 * Odoo API Service
 * Connexion a Odoo via JSON-RPC
 */
Object.defineProperty(exports, "__esModule", { value: true });
class OdooService {
    constructor() {
        this.uid = null;
        this.config = {
            url: process.env.ODOO_URL || '',
            db: process.env.ODOO_DB || '',
            username: process.env.ODOO_USERNAME || '',
            password: process.env.ODOO_PASSWORD || ''
        };
        if (this.isConfigured()) {
            console.log(`[OdooService] Configured for ${this.config.url} (db: ${this.config.db})`);
        }
        else {
            console.warn('[OdooService] Not configured - set ODOO_URL, ODOO_DB, ODOO_USERNAME, ODOO_PASSWORD');
        }
    }
    /**
     * Verifier si le service est configure
     */
    isConfigured() {
        return !!(this.config.url && this.config.db && this.config.username && this.config.password);
    }
    /**
     * Appel JSON-RPC generique
     */
    async jsonRpc(endpoint, method, params) {
        const url = `${this.config.url}${endpoint}`;
        const payload = {
            jsonrpc: '2.0',
            method: 'call',
            params: {
                service: method === 'authenticate' ? 'common' : 'object',
                method: method,
                args: params
            },
            id: Date.now()
        };
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();
            if (data.error) {
                throw new Error(data.error.data?.message || data.error.message || 'Erreur Odoo');
            }
            return data.result;
        }
        catch (error) {
            console.error('[OdooService] RPC Error:', error.message);
            throw error;
        }
    }
    /**
     * Authentification - obtenir l'UID utilisateur
     */
    async authenticate() {
        if (!this.isConfigured()) {
            throw new Error('Odoo non configure');
        }
        if (this.uid) {
            return this.uid;
        }
        const result = await this.jsonRpc('/jsonrpc', 'authenticate', [
            this.config.db,
            this.config.username,
            this.config.password,
            {}
        ]);
        if (!result) {
            throw new Error('Authentification Odoo echouee - verifiez les credentials');
        }
        this.uid = result;
        console.log(`[OdooService] Authenticated as UID ${this.uid}`);
        return this.uid;
    }
    /**
     * Executer une methode sur un modele Odoo
     */
    async execute(model, method, args, kwargs = {}) {
        const uid = await this.authenticate();
        return this.jsonRpc('/jsonrpc', 'execute_kw', [
            this.config.db,
            uid,
            this.config.password,
            model,
            method,
            args,
            kwargs
        ]);
    }
    /**
     * Rechercher des enregistrements
     */
    async search(params) {
        const { model, domain = [], limit, offset, order } = params;
        const kwargs = {};
        if (limit)
            kwargs.limit = limit;
        if (offset)
            kwargs.offset = offset;
        if (order)
            kwargs.order = order;
        return this.execute(model, 'search', [domain], kwargs);
    }
    /**
     * Lire des enregistrements par IDs
     */
    async read(model, ids, fields) {
        const kwargs = {};
        if (fields)
            kwargs.fields = fields;
        return this.execute(model, 'read', [ids], kwargs);
    }
    /**
     * Rechercher et lire en une seule requete
     */
    async searchRead(params) {
        const { model, domain = [], fields, limit, offset, order } = params;
        const kwargs = {};
        if (fields)
            kwargs.fields = fields;
        if (limit)
            kwargs.limit = limit;
        if (offset)
            kwargs.offset = offset;
        if (order)
            kwargs.order = order;
        return this.execute(model, 'search_read', [domain], kwargs);
    }
    /**
     * Creer un enregistrement
     */
    async create(params) {
        const { model, values } = params;
        return this.execute(model, 'create', [values]);
    }
    /**
     * Mettre a jour des enregistrements
     */
    async update(params) {
        const { model, ids, values } = params;
        return this.execute(model, 'write', [ids, values]);
    }
    /**
     * Supprimer des enregistrements
     */
    async delete(model, ids) {
        return this.execute(model, 'unlink', [ids]);
    }
    /**
     * Compter les enregistrements
     */
    async count(model, domain = []) {
        return this.execute(model, 'search_count', [domain]);
    }
    // ==================== METHODES METIER ====================
    /**
     * Recuperer les clients (res.partner)
     * Note: Utilise is_company=true et customer=true (ou active=true) pour compatibilite Odoo 12+
     */
    async getCustomers(options = {}) {
        // Filtre de base: entreprises actives
        const domain = [['is_company', '=', true], ['active', '=', true]];
        if (options.search) {
            domain.push('|', '|');
            domain.push(['name', 'ilike', options.search]);
            domain.push(['email', 'ilike', options.search]);
            domain.push(['phone', 'ilike', options.search]);
        }
        return this.searchRead({
            model: 'res.partner',
            domain,
            fields: ['id', 'name', 'email', 'phone', 'street', 'city', 'zip', 'country_id', 'vat', 'website'],
            limit: options.limit || 50,
            offset: options.offset || 0,
            order: 'name asc'
        });
    }
    /**
     * Recuperer les produits (product.product)
     */
    async getProducts(options = {}) {
        const domain = [];
        if (options.active !== undefined) {
            domain.push(['active', '=', options.active]);
        }
        if (options.search) {
            domain.push('|');
            domain.push(['name', 'ilike', options.search]);
            domain.push(['default_code', 'ilike', options.search]);
        }
        return this.searchRead({
            model: 'product.product',
            domain,
            fields: ['id', 'name', 'default_code', 'list_price', 'standard_price', 'qty_available', 'categ_id', 'active'],
            limit: options.limit || 50,
            offset: options.offset || 0,
            order: 'name asc'
        });
    }
    /**
     * Recuperer les commandes de vente (sale.order)
     */
    async getSaleOrders(options = {}) {
        const domain = [];
        if (options.state) {
            domain.push(['state', '=', options.state]);
        }
        if (options.partnerId) {
            domain.push(['partner_id', '=', options.partnerId]);
        }
        return this.searchRead({
            model: 'sale.order',
            domain,
            fields: ['id', 'name', 'partner_id', 'date_order', 'state', 'amount_total', 'currency_id', 'user_id'],
            limit: options.limit || 50,
            offset: options.offset || 0,
            order: 'date_order desc'
        });
    }
    /**
     * Recuperer les factures (account.move)
     */
    async getInvoices(options = {}) {
        const domain = [['move_type', 'in', ['out_invoice', 'out_refund']]];
        if (options.state) {
            domain.push(['state', '=', options.state]);
        }
        if (options.partnerId) {
            domain.push(['partner_id', '=', options.partnerId]);
        }
        return this.searchRead({
            model: 'account.move',
            domain,
            fields: ['id', 'name', 'partner_id', 'invoice_date', 'state', 'amount_total', 'amount_residual', 'currency_id'],
            limit: options.limit || 50,
            offset: options.offset || 0,
            order: 'invoice_date desc'
        });
    }
    /**
     * Creer un client dans Odoo
     */
    async createCustomer(data) {
        const values = {
            name: data.name,
            is_company: true,
            customer: true // Compatible Odoo 12+
        };
        if (data.email)
            values.email = data.email;
        if (data.phone)
            values.phone = data.phone;
        if (data.street)
            values.street = data.street;
        if (data.city)
            values.city = data.city;
        if (data.zip)
            values.zip = data.zip;
        if (data.vat)
            values.vat = data.vat;
        if (data.website)
            values.website = data.website;
        // Chercher le pays par code si fourni
        if (data.countryCode) {
            const countries = await this.searchRead({
                model: 'res.country',
                domain: [['code', '=', data.countryCode.toUpperCase()]],
                fields: ['id'],
                limit: 1
            });
            if (countries.length > 0) {
                values.country_id = countries[0].id;
            }
        }
        return this.create({ model: 'res.partner', values });
    }
    /**
     * Synchroniser un lead CRM vers Odoo
     */
    async syncLeadToOdoo(lead) {
        // Creer une opportunite CRM dans Odoo
        const values = {
            name: `Lead: ${lead.companyName}`,
            partner_name: lead.companyName,
            type: 'opportunity'
        };
        if (lead.contactName)
            values.contact_name = lead.contactName;
        if (lead.email)
            values.email_from = lead.email;
        if (lead.phone)
            values.phone = lead.phone;
        if (lead.city)
            values.city = lead.city;
        if (lead.description)
            values.description = lead.description;
        return this.create({ model: 'crm.lead', values });
    }
    /**
     * Obtenir la configuration (sans password)
     */
    getConfig() {
        return {
            url: this.config.url,
            db: this.config.db,
            username: this.config.username,
            password: this.config.password ? '***configured***' : 'not set',
            configured: this.isConfigured(),
            authenticated: this.uid !== null,
            uid: this.uid
        };
    }
}
exports.default = new OdooService();
//# sourceMappingURL=odoo-service.js.map