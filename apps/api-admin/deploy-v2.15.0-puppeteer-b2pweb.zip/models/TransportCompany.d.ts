/**
 * TransportCompany - Entreprises de transport scrapees pour Affret IA
 */
import mongoose, { Document } from 'mongoose';
export interface ITransportCompany extends Document {
    companyName: string;
    legalName?: string;
    siret?: string;
    siren?: string;
    tvaNumber?: string;
    naf?: string;
    email?: string;
    phone?: string;
    fax?: string;
    website?: string;
    linkedin?: string;
    address: {
        street?: string;
        postalCode?: string;
        city?: string;
        department?: string;
        departmentCode?: string;
        region?: string;
        country: string;
        lat?: number;
        lng?: number;
    };
    transportInfo: {
        licenseNumber?: string;
        licenseType?: 'light' | 'heavy' | 'both';
        fleetSize?: number;
        employeeCount?: number;
        turnover?: number;
        foundedYear?: number;
        services: string[];
        specializations: string[];
        vehicleTypes: string[];
        operatingZones: string[];
        coveredDepartments: string[];
        coveredCountries: string[];
    };
    mainContact?: {
        firstName?: string;
        lastName?: string;
        position?: string;
        email?: string;
        phone?: string;
        linkedinUrl?: string;
    };
    source: {
        type: 'scraping' | 'import' | 'manual' | 'api';
        name: string;
        url?: string;
        scrapedAt: Date;
        lastUpdated?: Date;
    };
    enrichment: {
        emailVerified?: boolean;
        emailVerifiedAt?: Date;
        phoneVerified?: boolean;
        dataQualityScore?: number;
        enrichedAt?: Date;
        enrichmentSource?: string;
    };
    prospectionStatus: 'new' | 'to_contact' | 'contacted' | 'interested' | 'not_interested' | 'client' | 'blacklist';
    addedToLeadPool: boolean;
    leadPoolId?: mongoose.Types.ObjectId;
    addedToLeadPoolAt?: Date;
    tags: string[];
    notes?: string;
    score?: number;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ITransportCompany, {}, {}, {}, mongoose.Document<unknown, {}, ITransportCompany, {}, {}> & ITransportCompany & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=TransportCompany.d.ts.map