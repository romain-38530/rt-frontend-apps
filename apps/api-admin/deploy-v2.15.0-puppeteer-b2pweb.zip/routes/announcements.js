"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Announcement_1 = __importDefault(require("../models/Announcement"));
const router = (0, express_1.Router)();
// List announcements
router.get('/', async (req, res) => {
    try {
        const { page = 1, limit = 20, active } = req.query;
        const query = {};
        if (active !== undefined) {
            query.active = active === 'true';
            if (active === 'true') {
                query.startDate = { $lte: new Date() };
                query.$or = [
                    { endDate: null },
                    { endDate: { $gte: new Date() } }
                ];
            }
        }
        const total = await Announcement_1.default.countDocuments(query);
        const announcements = await Announcement_1.default.find(query)
            .populate('createdBy', 'firstName lastName email')
            .sort({ priority: -1, startDate: -1 })
            .skip((Number(page) - 1) * Number(limit))
            .limit(Number(limit));
        res.json({
            success: true,
            data: announcements,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                totalPages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Create announcement
router.post('/', async (req, res) => {
    try {
        const { title, content, type, target, targetIds, priority, startDate, endDate } = req.body;
        const announcement = new Announcement_1.default({
            title,
            content,
            type: type || 'info',
            target: target || 'all',
            targetIds: targetIds || [],
            priority: priority || 0,
            active: true,
            startDate: startDate ? new Date(startDate) : new Date(),
            endDate: endDate ? new Date(endDate) : undefined,
            createdBy: req.user.id
        });
        await announcement.save();
        res.status(201).json({ success: true, data: announcement });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Update announcement
router.put('/:id', async (req, res) => {
    try {
        const announcement = await Announcement_1.default.findById(req.params.id);
        if (!announcement) {
            return res.status(404).json({ success: false, error: 'Announcement not found' });
        }
        const { title, content, type, target, targetIds, priority, active, startDate, endDate } = req.body;
        if (title)
            announcement.title = title;
        if (content)
            announcement.content = content;
        if (type)
            announcement.type = type;
        if (target)
            announcement.target = target;
        if (targetIds)
            announcement.targetIds = targetIds;
        if (priority !== undefined)
            announcement.priority = priority;
        if (active !== undefined)
            announcement.active = active;
        if (startDate)
            announcement.startDate = new Date(startDate);
        if (endDate !== undefined)
            announcement.endDate = endDate ? new Date(endDate) : undefined;
        await announcement.save();
        res.json({ success: true, data: announcement });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Delete announcement
router.delete('/:id', async (req, res) => {
    try {
        const announcement = await Announcement_1.default.findByIdAndDelete(req.params.id);
        if (!announcement) {
            return res.status(404).json({ success: false, error: 'Announcement not found' });
        }
        res.json({ success: true, message: 'Announcement deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Broadcast notification
router.post('/notifications/broadcast', async (req, res) => {
    try {
        const { title, message, type, channels, target, targetIds, scheduledAt } = req.body;
        // In a real implementation, this would:
        // 1. Create notification records
        // 2. Send via selected channels (email, push, sms, inApp)
        // 3. Handle scheduling if scheduledAt is provided
        res.json({
            success: true,
            message: 'Notification broadcast initiated',
            data: {
                title,
                message,
                type,
                channels,
                target,
                targetIds,
                scheduledAt,
                status: scheduledAt ? 'scheduled' : 'sent'
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
exports.default = router;
//# sourceMappingURL=announcements.js.map