declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=crm.d.ts.map