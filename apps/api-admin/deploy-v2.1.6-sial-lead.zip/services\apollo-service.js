"use strict";
/**
 * Apollo.io API Service
 * Enrichissement des entreprises et recherche de contacts
 */
Object.defineProperty(exports, "__esModule", { value: true });
const APOLLO_API_URL = 'https://api.apollo.io/v1';
const APOLLO_API_KEY = process.env.APOLLO_API_KEY || '';
// Titres de postes recherchés pour supply chain
const SUPPLY_CHAIN_TITLES = [
    'Directeur Supply Chain',
    'VP Supply Chain',
    'Chief Supply Chain Officer',
    'Directeur Logistique',
    'Directeur des Opérations',
    'COO',
    'Directeur Transport',
    'Responsable Supply Chain',
    'Responsable Logistique',
    'Responsable Transport',
    'Supply Chain Manager',
    'Logistics Manager',
    'Directeur des Achats',
    'Head of Supply Chain',
    'Head of Logistics',
    'Operations Director'
];
class ApolloService {
    async makeRequest(endpoint, method = 'GET', body) {
        if (!APOLLO_API_KEY) {
            console.error('[ApolloService] API key not configured');
            return null;
        }
        try {
            const response = await fetch(`${APOLLO_API_URL}${endpoint}`, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache',
                    'X-Api-Key': APOLLO_API_KEY
                },
                body: body ? JSON.stringify(body) : undefined
            });
            if (!response.ok) {
                const errorText = await response.text();
                console.error(`[ApolloService] API error ${response.status}: ${errorText}`);
                return null;
            }
            return await response.json();
        }
        catch (error) {
            console.error('[ApolloService] Request failed:', error);
            return null;
        }
    }
    /**
     * Enrichir une entreprise via son domaine web
     */
    async enrichOrganization(domain) {
        const result = await this.makeRequest('/organizations/enrich', 'POST', { domain });
        return result?.organization || null;
    }
    /**
     * Rechercher des contacts dans une organisation
     */
    async searchPeople(organizationId, titles) {
        const searchTitles = titles || SUPPLY_CHAIN_TITLES;
        const result = await this.makeRequest('/people/search', 'POST', {
            organization_ids: [organizationId],
            person_titles: searchTitles,
            contact_email_status: ['verified', 'guessed'],
            per_page: 25
        });
        return result?.people || [];
    }
    /**
     * Rechercher une personne spécifique
     */
    async matchPerson(params) {
        const result = await this.makeRequest('/people/match', 'POST', {
            first_name: params.firstName,
            last_name: params.lastName,
            organization_name: params.organizationName,
            domain: params.domain,
            reveal_personal_emails: false
        });
        return result?.person || null;
    }
    /**
     * Enrichir une entreprise et trouver ses contacts supply chain
     */
    async enrichCompanyWithContacts(domain) {
        // Étape 1: Enrichir l'organisation
        const organization = await this.enrichOrganization(domain);
        if (!organization) {
            return { organization: null, contacts: [] };
        }
        // Étape 2: Rechercher les contacts
        const contacts = await this.searchPeople(organization.id);
        return { organization, contacts };
    }
    /**
     * Mapper le seniority Apollo vers notre format
     */
    mapSeniority(apolloSeniority) {
        const seniorityMap = {
            'director': 'director',
            'vp': 'vp',
            'c_suite': 'director',
            'manager': 'manager',
            'senior': 'senior',
            'entry': 'entry'
        };
        return seniorityMap[apolloSeniority?.toLowerCase()] || 'unknown';
    }
    /**
     * Mapper le statut email Apollo vers notre format
     */
    mapEmailStatus(apolloStatus) {
        const statusMap = {
            'verified': 'VALID',
            'guessed': 'UNKNOWN',
            'unavailable': 'INVALID',
            'bounced': 'INVALID'
        };
        return statusMap[apolloStatus?.toLowerCase()] || 'UNKNOWN';
    }
}
exports.default = new ApolloService();
//# sourceMappingURL=apollo-service.js.map