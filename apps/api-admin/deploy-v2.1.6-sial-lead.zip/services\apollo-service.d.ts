/**
 * Apollo.io API Service
 * Enrichissement des entreprises et recherche de contacts
 */
interface ApolloOrganization {
    id: string;
    name: string;
    website_url?: string;
    linkedin_url?: string;
    founded_year?: number;
    industry?: string;
    estimated_num_employees?: number;
    phone?: string;
    primary_domain?: string;
    technologies?: string[];
}
interface ApolloPerson {
    id: string;
    first_name: string;
    last_name: string;
    name: string;
    title: string;
    email: string;
    email_status: string;
    linkedin_url?: string;
    phone_numbers?: {
        raw_number: string;
        type: string;
    }[];
    seniority: string;
    organization_id: string;
}
declare class ApolloService {
    private makeRequest;
    /**
     * Enrichir une entreprise via son domaine web
     */
    enrichOrganization(domain: string): Promise<ApolloOrganization | null>;
    /**
     * Rechercher des contacts dans une organisation
     */
    searchPeople(organizationId: string, titles?: string[]): Promise<ApolloPerson[]>;
    /**
     * Rechercher une personne spécifique
     */
    matchPerson(params: {
        firstName: string;
        lastName: string;
        organizationName?: string;
        domain?: string;
    }): Promise<ApolloPerson | null>;
    /**
     * Enrichir une entreprise et trouver ses contacts supply chain
     */
    enrichCompanyWithContacts(domain: string): Promise<{
        organization: ApolloOrganization | null;
        contacts: ApolloPerson[];
    }>;
    /**
     * Mapper le seniority Apollo vers notre format
     */
    mapSeniority(apolloSeniority: string): 'director' | 'vp' | 'manager' | 'senior' | 'entry' | 'unknown';
    /**
     * Mapper le statut email Apollo vers notre format
     */
    mapEmailStatus(apolloStatus: string): 'VALID' | 'INVALID' | 'UNKNOWN' | 'CATCH_ALL';
}
declare const _default: ApolloService;
export default _default;
export { ApolloOrganization, ApolloPerson };
//# sourceMappingURL=apollo-service.d.ts.map