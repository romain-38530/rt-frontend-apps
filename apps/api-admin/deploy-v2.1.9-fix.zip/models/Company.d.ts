import mongoose, { Document } from 'mongoose';
export interface ICompany extends Document {
    name: string;
    legalName: string;
    registrationNumber: string;
    vatNumber?: string;
    type: 'shipper' | 'carrier' | 'broker' | 'warehouse' | 'supplier' | 'recipient';
    address: {
        street: string;
        city: string;
        postalCode: string;
        country: string;
    };
    contact: {
        name: string;
        email: string;
        phone: string;
    };
    status: 'active' | 'pending' | 'suspended' | 'cancelled';
    verified: boolean;
    verifiedAt?: Date;
    verifiedBy?: mongoose.Types.ObjectId;
    subscriptionId?: mongoose.Types.ObjectId;
    modules: string[];
    settings: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICompany, {}, {}, {}, mongoose.Document<unknown, {}, ICompany, {}, {}> & ICompany & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Company.d.ts.map