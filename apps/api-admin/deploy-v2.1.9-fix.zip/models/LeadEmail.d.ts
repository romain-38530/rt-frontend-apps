import mongoose, { Document } from 'mongoose';
export type EmailType = 'PRESENTATION' | 'COMMERCIAL_INTRO' | 'RELANCE_1' | 'RELANCE_2' | 'MANUEL';
export type EmailSendStatus = 'PENDING' | 'QUEUED' | 'SENT' | 'DELIVERED' | 'OPENED' | 'CLICKED' | 'BOUNCED' | 'COMPLAINED' | 'UNSUBSCRIBED' | 'FAILED';
export interface ILeadEmail extends Document {
    contactId: mongoose.Types.ObjectId;
    entrepriseId: mongoose.Types.ObjectId;
    typeEmail: EmailType;
    templateId?: string;
    sujet: string;
    corpsHtml?: string;
    corpsText?: string;
    langue: string;
    expediteurEmail: string;
    expediteurNom: string;
    mailgunMessageId?: string;
    dateEnvoi?: Date;
    statutEnvoi: EmailSendStatus;
    dateDelivered?: Date;
    dateOpened?: Date;
    nbOpens: number;
    dateClicked?: Date;
    nbClicks: number;
    linksClicked: string[];
    bounceType?: string;
    bounceMessage?: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ILeadEmail, {}, {}, {}, mongoose.Document<unknown, {}, ILeadEmail, {}, {}> & ILeadEmail & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=LeadEmail.d.ts.map