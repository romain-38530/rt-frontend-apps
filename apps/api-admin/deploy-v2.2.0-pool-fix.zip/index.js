"use strict";
/**
 * API Admin Gateway - SYMPHONI.A
 * Administration centralisee de la plateforme
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const mongoose_1 = __importDefault(require("mongoose"));
// Routes
const users_1 = __importDefault(require("./routes/users"));
const companies_1 = __importDefault(require("./routes/companies"));
const subscriptions_1 = __importDefault(require("./routes/subscriptions"));
const modules_1 = __importDefault(require("./routes/modules"));
const api_keys_1 = __importDefault(require("./routes/api-keys"));
const audit_1 = __importDefault(require("./routes/audit"));
const announcements_1 = __importDefault(require("./routes/announcements"));
const dashboard_1 = __importDefault(require("./routes/dashboard"));
const crm_1 = __importDefault(require("./routes/crm"));
const auth_1 = __importDefault(require("./routes/auth"));
// Middleware
const auth_2 = require("./middleware/auth");
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3020;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/rt-admin';
// Middleware
app.use((0, cors_1.default)({
    origin: process.env.CORS_ORIGIN?.split(',') || '*',
    credentials: true
}));
app.use(express_1.default.json({ limit: '10mb' }));
// Request logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});
// API Documentation
app.get('/', (req, res) => {
    res.json({
        name: 'RT Technologie Admin Gateway API',
        version: '1.0.0',
        description: 'Administration centralisee SYMPHONI.A',
        endpoints: {
            health: '/health',
            // User Management
            users: {
                list: 'GET /api/v1/admin/users',
                create: 'POST /api/v1/admin/users',
                get: 'GET /api/v1/admin/users/:id',
                update: 'PUT /api/v1/admin/users/:id',
                delete: 'DELETE /api/v1/admin/users/:id',
                activate: 'POST /api/v1/admin/users/:id/activate',
                deactivate: 'POST /api/v1/admin/users/:id/deactivate',
                resetPassword: 'POST /api/v1/admin/users/:id/reset-password',
                activity: 'GET /api/v1/admin/users/:id/activity',
                roles: 'PUT /api/v1/admin/users/:id/roles'
            },
            // Company Management
            companies: {
                list: 'GET /api/v1/admin/companies',
                create: 'POST /api/v1/admin/companies',
                get: 'GET /api/v1/admin/companies/:id',
                update: 'PUT /api/v1/admin/companies/:id',
                delete: 'DELETE /api/v1/admin/companies/:id',
                verify: 'POST /api/v1/admin/companies/:id/verify',
                suspend: 'POST /api/v1/admin/companies/:id/suspend',
                billing: 'GET /api/v1/admin/companies/:id/billing',
                subscription: 'PUT /api/v1/admin/companies/:id/subscription',
                modules: 'PUT /api/v1/admin/companies/:id/modules'
            },
            // Subscriptions & Billing
            subscriptions: {
                list: 'GET /api/v1/admin/subscriptions',
                get: 'GET /api/v1/admin/subscriptions/:id',
                update: 'PUT /api/v1/admin/subscriptions/:id',
                cancel: 'POST /api/v1/admin/subscriptions/:id/cancel'
            },
            invoices: {
                list: 'GET /api/v1/admin/invoices',
                refund: 'POST /api/v1/admin/invoices/:id/refund'
            },
            // Platform Monitoring
            dashboard: 'GET /api/v1/admin/dashboard',
            servicesHealth: 'GET /api/v1/admin/services/health',
            metrics: 'GET /api/v1/admin/metrics',
            logs: 'GET /api/v1/admin/logs',
            errors: 'GET /api/v1/admin/errors',
            // Module Management
            modules: {
                list: 'GET /api/v1/admin/modules',
                toggle: 'PUT /api/v1/admin/modules/:id/toggle',
                usage: 'GET /api/v1/admin/modules/:id/usage'
            },
            // API Keys
            apiKeys: {
                list: 'GET /api/v1/admin/api-keys',
                create: 'POST /api/v1/admin/api-keys',
                revoke: 'DELETE /api/v1/admin/api-keys/:id'
            },
            // Integrations
            integrations: {
                list: 'GET /api/v1/admin/integrations',
                configure: 'PUT /api/v1/admin/integrations/:id'
            },
            // Audit & Compliance
            audit: {
                list: 'GET /api/v1/admin/audit',
                export: 'GET /api/v1/admin/audit/export'
            },
            gdpr: {
                requests: 'GET /api/v1/admin/gdpr/requests',
                process: 'POST /api/v1/admin/gdpr/requests/:id/process'
            },
            // Notifications & Announcements
            notifications: {
                broadcast: 'POST /api/v1/admin/notifications/broadcast'
            },
            announcements: {
                list: 'GET /api/v1/admin/announcements',
                create: 'POST /api/v1/admin/announcements',
                update: 'PUT /api/v1/admin/announcements/:id',
                delete: 'DELETE /api/v1/admin/announcements/:id'
            },
            // CRM Lead Generation
            crm: {
                dashboard: 'GET /api/v1/admin/crm/dashboard',
                salons: {
                    list: 'GET /api/v1/admin/crm/salons',
                    create: 'POST /api/v1/admin/crm/salons',
                    get: 'GET /api/v1/admin/crm/salons/:id',
                    update: 'PUT /api/v1/admin/crm/salons/:id'
                },
                companies: {
                    list: 'GET /api/v1/admin/crm/companies',
                    create: 'POST /api/v1/admin/crm/companies',
                    get: 'GET /api/v1/admin/crm/companies/:id',
                    update: 'PUT /api/v1/admin/crm/companies/:id',
                    enrich: 'POST /api/v1/admin/crm/companies/:id/enrich',
                    assign: 'POST /api/v1/admin/crm/companies/:id/assign'
                },
                contacts: {
                    list: 'GET /api/v1/admin/crm/contacts',
                    create: 'POST /api/v1/admin/crm/contacts',
                    get: 'GET /api/v1/admin/crm/contacts/:id',
                    update: 'PUT /api/v1/admin/crm/contacts/:id',
                    verifyEmail: 'POST /api/v1/admin/crm/contacts/:id/verify-email'
                },
                emails: {
                    list: 'GET /api/v1/admin/crm/emails',
                    send: 'POST /api/v1/admin/crm/emails/send',
                    webhook: 'POST /api/v1/admin/crm/emails/webhook'
                },
                templates: {
                    list: 'GET /api/v1/admin/crm/templates',
                    create: 'POST /api/v1/admin/crm/templates',
                    update: 'PUT /api/v1/admin/crm/templates/:id'
                }
            }
        }
    });
});
// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        message: 'RT Admin Gateway API is running',
        version: '1.0.0',
        timestamp: new Date().toISOString(),
        mongodb: mongoose_1.default.connection.readyState === 1 ? 'connected' : 'disconnected'
    });
});
// Auth routes (public)
app.use('/auth', auth_1.default);
// Protected admin routes
app.use('/api/v1/admin/users', auth_2.authenticateAdmin, users_1.default);
app.use('/api/v1/admin/companies', auth_2.authenticateAdmin, companies_1.default);
app.use('/api/v1/admin/subscriptions', auth_2.authenticateAdmin, subscriptions_1.default);
app.use('/api/v1/admin/modules', auth_2.authenticateAdmin, modules_1.default);
app.use('/api/v1/admin/api-keys', auth_2.authenticateAdmin, api_keys_1.default);
app.use('/api/v1/admin/audit', auth_2.authenticateAdmin, audit_1.default);
app.use('/api/v1/admin/announcements', auth_2.authenticateAdmin, announcements_1.default);
app.use('/api/v1/admin/crm', crm_1.default); // CRM routes (auth handled internally, webhook needs to be public)
app.use('/api/v1/admin', auth_2.authenticateAdmin, dashboard_1.default);
// Error handling
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
        success: false,
        error: err.message || 'Internal Server Error'
    });
});
// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Route not found',
        path: req.path
    });
});
// Connect to MongoDB and start server
mongoose_1.default.connect(MONGODB_URI)
    .then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => {
        console.log(`RT Admin Gateway API running on port ${PORT}`);
        console.log(`Documentation: http://localhost:${PORT}/`);
    });
})
    .catch((error) => {
    console.error('MongoDB connection error:', error);
    process.exit(1);
});
exports.default = app;
//# sourceMappingURL=index.js.map