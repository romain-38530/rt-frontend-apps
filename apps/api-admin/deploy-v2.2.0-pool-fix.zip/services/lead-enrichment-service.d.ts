/**
 * Lead Enrichment Service
 * Enrichissement automatique des leads apres scraping
 * Recherche des contacts decideurs via Lemlist
 */
declare const TARGET_JOB_TITLES: string[];
interface EnrichmentResult {
    companyId: string;
    companyName: string;
    contactsFound: number;
    contactsCreated: number;
    errors: string[];
    duration: number;
}
interface BulkEnrichmentResult {
    totalCompanies: number;
    totalContactsFound: number;
    totalContactsCreated: number;
    results: EnrichmentResult[];
    errors: string[];
    duration: number;
}
declare class LeadEnrichmentService {
    /**
     * Enrichir une entreprise - trouver les contacts decideurs
     */
    enrichCompany(companyId: string): Promise<EnrichmentResult>;
    /**
     * Enrichir toutes les entreprises d'un salon
     */
    enrichSalonCompanies(salonId: string, limit?: number): Promise<BulkEnrichmentResult>;
    /**
     * Enrichir les entreprises nouvellement scrapees (sans contacts)
     */
    enrichNewCompanies(limit?: number): Promise<BulkEnrichmentResult>;
    /**
     * Workflow automatique: Scraping -> Enrichissement
     * Lance apres un scraping reussi
     */
    postScrapingEnrichment(salonId: string, maxCompanies?: number): Promise<{
        enrichmentStarted: boolean;
        message: string;
    }>;
    /**
     * Extraire le domaine depuis une URL ou site web
     */
    private extractDomain;
    /**
     * Calculer le score d'un contact
     */
    private calculateContactScore;
}
declare const _default: LeadEnrichmentService;
export default _default;
export { EnrichmentResult, BulkEnrichmentResult, TARGET_JOB_TITLES };
//# sourceMappingURL=lead-enrichment-service.d.ts.map