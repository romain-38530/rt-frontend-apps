import mongoose, { Document } from 'mongoose';
export interface IAnnouncement extends Document {
    title: string;
    content: string;
    type: 'info' | 'warning' | 'maintenance' | 'feature' | 'promotion';
    target: 'all' | 'admins' | 'companies' | 'plan' | 'module';
    targetIds: string[];
    priority: number;
    active: boolean;
    startDate: Date;
    endDate?: Date;
    createdBy: mongoose.Types.ObjectId;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IAnnouncement, {}, {}, {}, mongoose.Document<unknown, {}, IAnnouncement, {}, {}> & IAnnouncement & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Announcement.d.ts.map