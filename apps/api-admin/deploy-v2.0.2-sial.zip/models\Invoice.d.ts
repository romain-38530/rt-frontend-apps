import mongoose, { Document } from 'mongoose';
export interface IInvoice extends Document {
    number: string;
    companyId: mongoose.Types.ObjectId;
    subscriptionId: mongoose.Types.ObjectId;
    status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled' | 'refunded';
    items: {
        description: string;
        quantity: number;
        unitPrice: number;
        total: number;
    }[];
    subtotal: number;
    tax: number;
    taxRate: number;
    total: number;
    currency: string;
    dueDate: Date;
    paidAt?: Date;
    paymentMethod?: string;
    stripeInvoiceId?: string;
    refundedAmount?: number;
    refundedAt?: Date;
    notes?: string;
    createdAt: Date;
}
declare const _default: mongoose.Model<IInvoice, {}, {}, {}, mongoose.Document<unknown, {}, IInvoice, {}, {}> & IInvoice & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Invoice.d.ts.map