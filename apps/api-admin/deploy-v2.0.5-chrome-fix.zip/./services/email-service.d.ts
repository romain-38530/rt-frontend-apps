/**
 * CRM Email Service - OVH SMTP
 * Envoi d'emails commerciaux via SMTP OVH
 */
interface EmailSendOptions {
    to: string;
    subject: string;
    html: string;
    text?: string;
    from?: string;
    fromName?: string;
    replyTo?: string;
    tags?: string[];
}
interface EmailSendResult {
    id: string;
    message: string;
    success: boolean;
}
declare class CrmEmailService {
    private transporter;
    private config;
    constructor();
    private initTransporter;
    /**
     * Envoyer un email
     */
    sendEmail(options: EmailSendOptions): Promise<EmailSendResult | null>;
    /**
     * Envoyer un email avec un template
     */
    sendTemplateEmail(params: {
        to: string;
        templateHtml: string;
        templateSubject: string;
        variables: Record<string, string>;
        fromEmail?: string;
        fromName?: string;
        replyTo?: string;
        tags?: string[];
    }): Promise<EmailSendResult | null>;
    /**
     * Envoyer un email de prospection
     */
    sendProspectionEmail(params: {
        to: string;
        contactName: string;
        companyName: string;
        subject: string;
        body: string;
        signature?: string;
    }): Promise<EmailSendResult | null>;
    /**
     * Mapper un evenement vers notre statut email (pour tracking futur)
     */
    mapEventToStatus(event: string): string;
    /**
     * Verifier la configuration
     */
    isConfigured(): boolean;
    /**
     * Obtenir la configuration (sans password)
     */
    getConfig(): Record<string, unknown>;
}
declare const _default: CrmEmailService;
export default _default;
export { EmailSendOptions, EmailSendResult };
//# sourceMappingURL=email-service.d.ts.map