"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const SubscriptionSchema = new mongoose_1.Schema({
    companyId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Company', required: true },
    plan: {
        type: String,
        enum: ['free', 'starter', 'professional', 'enterprise', 'custom'],
        required: true
    },
    status: {
        type: String,
        enum: ['active', 'trial', 'past_due', 'cancelled', 'suspended'],
        default: 'trial'
    },
    billingCycle: {
        type: String,
        enum: ['monthly', 'quarterly', 'yearly'],
        default: 'monthly'
    },
    price: { type: Number, required: true },
    currency: { type: String, default: 'EUR' },
    modules: [String],
    limits: {
        users: { type: Number, default: 5 },
        orders: { type: Number, default: 100 },
        storage: { type: Number, default: 1024 }, // MB
        apiCalls: { type: Number, default: 10000 }
    },
    usage: {
        users: { type: Number, default: 0 },
        orders: { type: Number, default: 0 },
        storage: { type: Number, default: 0 },
        apiCalls: { type: Number, default: 0 }
    },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    trialEndDate: Date,
    autoRenew: { type: Boolean, default: true },
    stripeCustomerId: String,
    stripeSubscriptionId: String
}, {
    timestamps: true
});
SubscriptionSchema.index({ companyId: 1 });
SubscriptionSchema.index({ status: 1 });
SubscriptionSchema.index({ plan: 1 });
SubscriptionSchema.index({ endDate: 1 });
exports.default = mongoose_1.default.model('Subscription', SubscriptionSchema);
//# sourceMappingURL=Subscription.js.map