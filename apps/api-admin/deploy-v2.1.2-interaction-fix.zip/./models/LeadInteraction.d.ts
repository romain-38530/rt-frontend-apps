import mongoose, { Document } from 'mongoose';
export type InteractionType = 'CREATION' | 'ENRICHISSEMENT' | 'EMAIL_ENVOYE' | 'EMAIL_OUVERT' | 'EMAIL_CLICKED' | 'EMAIL_RECU' | 'ASSIGNATION' | 'CHANGEMENT_STATUT' | 'NOTE' | 'APPEL' | 'RDV' | 'CONVERSION';
export interface ILeadInteraction extends Document {
    entrepriseId: mongoose.Types.ObjectId;
    contactId?: mongoose.Types.ObjectId;
    commercialId?: mongoose.Types.ObjectId;
    typeInteraction: InteractionType;
    description?: string;
    metadata?: Record<string, unknown>;
    emailId?: mongoose.Types.ObjectId;
    createdBy?: string;
    createdAt: Date;
}
declare const _default: mongoose.Model<ILeadInteraction, {}, {}, {}, mongoose.Document<unknown, {}, ILeadInteraction, {}, {}> & ILeadInteraction & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=LeadInteraction.d.ts.map