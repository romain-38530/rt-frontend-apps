import mongoose, { Document } from 'mongoose';
export interface ICrmCommission extends Document {
    commercialId: mongoose.Types.ObjectId;
    type: 'conversion' | 'signature' | 'bonus' | 'recurring';
    leadCompanyId?: mongoose.Types.ObjectId;
    montant: number;
    devise: string;
    periode: string;
    status: 'pending' | 'validated' | 'paid' | 'cancelled';
    description?: string;
    dateValidation?: Date;
    datePaiement?: Date;
    validateurId?: mongoose.Types.ObjectId;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICrmCommission, {}, {}, {}, mongoose.Document<unknown, {}, ICrmCommission, {}, {}> & ICrmCommission & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=CrmCommission.d.ts.map