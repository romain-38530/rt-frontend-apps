import mongoose, { Document } from 'mongoose';
export declare const SALES_STAGES: {
    order: number;
    code: string;
    label: string;
    description: string;
}[];
export interface ICrmSalesStage extends Document {
    leadCompanyId: mongoose.Types.ObjectId;
    commercialId: mongoose.Types.ObjectId;
    stageCode: string;
    stageOrder: number;
    stageLabel: string;
    status: 'pending' | 'in_progress' | 'completed' | 'skipped';
    dateDebut?: Date;
    dateFin?: Date;
    notes?: string;
    actionsTaken?: string[];
    nextAction?: string;
    nextActionDate?: Date;
    documents?: Array<{
        name: string;
        url: string;
        type: string;
        uploadedAt: Date;
    }>;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICrmSalesStage, {}, {}, {}, mongoose.Document<unknown, {}, ICrmSalesStage, {}, {}> & ICrmSalesStage & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=CrmSalesStage.d.ts.map