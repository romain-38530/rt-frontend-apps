/**
 * InstallationPlanning - Planning des installations clients
 * Systeme partage entre manager et commerciaux avec validation email
 */
import mongoose, { Document } from 'mongoose';
export interface IInstallationPlanning extends Document {
    contractId: mongoose.Types.ObjectId;
    contractNumber: string;
    companyId?: mongoose.Types.ObjectId;
    companyName: string;
    contactName: string;
    contactEmail: string;
    contactPhone?: string;
    title: string;
    description?: string;
    proposedSlots: {
        date: Date;
        startTime: string;
        endTime: string;
        duration: number;
    }[];
    confirmedSlot?: {
        date: Date;
        startTime: string;
        endTime: string;
        duration: number;
    };
    assignedTo: {
        type: 'commercial' | 'technician' | 'manager';
        userId: mongoose.Types.ObjectId;
        userName: string;
    };
    commercialId: mongoose.Types.ObjectId;
    commercialName: string;
    approvedBy?: mongoose.Types.ObjectId;
    approvedByName?: string;
    approvedAt?: Date;
    status: 'draft' | 'proposed' | 'pending_client' | 'pending_manager' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled' | 'rescheduled';
    validation: {
        clientToken: string;
        clientValidatedAt?: Date;
        clientSelectedSlot?: number;
        managerValidatedAt?: Date;
        emailsSent: {
            type: 'proposal' | 'confirmation' | 'reminder' | 'cancellation';
            sentAt: Date;
            to: string;
        }[];
    };
    installationConfig: {
        type: 'remote' | 'onsite' | 'hybrid';
        estimatedDuration: number;
        phases: {
            name: string;
            duration: number;
            description?: string;
            completed?: boolean;
            completedAt?: Date;
        }[];
        requirements?: string[];
        meetingLink?: string;
        address?: string;
    };
    feedback?: {
        rating: number;
        comment?: string;
        submittedAt: Date;
    };
    internalNotes?: string;
    clientNotes?: string;
    reminders: {
        type: '24h' | '1h' | 'custom';
        scheduledFor: Date;
        sent: boolean;
        sentAt?: Date;
    }[];
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IInstallationPlanning, {}, {}, {}, mongoose.Document<unknown, {}, IInstallationPlanning, {}, {}> & IInstallationPlanning & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=InstallationPlanning.d.ts.map