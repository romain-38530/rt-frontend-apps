import mongoose, { Document } from 'mongoose';
export type MeetingStatus = 'scheduled' | 'confirmed' | 'completed' | 'cancelled' | 'no_show';
export type MeetingType = 'presentation' | 'demo' | 'follow_up' | 'closing';
export interface ICommercialMeeting extends Document {
    commercialId: mongoose.Types.ObjectId;
    leadCompanyId?: mongoose.Types.ObjectId;
    leadContactId?: mongoose.Types.ObjectId;
    prospectInfo: {
        companyName: string;
        contactName: string;
        email: string;
        phone?: string;
        position?: string;
    };
    title: string;
    description?: string;
    type: MeetingType;
    status: MeetingStatus;
    scheduledAt: Date;
    duration: number;
    timezone: string;
    meetingLink?: string;
    meetingProvider?: 'google_meet' | 'zoom' | 'teams' | 'phone';
    notes?: string;
    outcome?: string;
    nextSteps?: string;
    confirmationEmailSent: boolean;
    reminderEmailSent: boolean;
    bookingToken?: string;
    bookedViaEmail?: mongoose.Types.ObjectId;
    bookedAt: Date;
    cancelledAt?: Date;
    cancellationReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICommercialMeeting, {}, {}, {}, mongoose.Document<unknown, {}, ICommercialMeeting, {}, {}> & ICommercialMeeting & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=CommercialMeeting.d.ts.map