/**
 * ModulePack - Packs de modules avec remises
 */
import mongoose, { Document } from 'mongoose';
export interface IModulePack extends Document {
    packCode: string;
    packName: string;
    description: string;
    targetAudience: string;
    modules: {
        moduleCode: string;
        moduleName: string;
        includedUsers?: number;
    }[];
    pricing: {
        monthlyPrice: number;
        setupFee: number;
        annualDiscount: number;
        currency: string;
        originalPrice: number;
        savingsPercent: number;
    };
    installation: {
        totalEstimatedHours: number;
        phaseCount: number;
        phases: {
            name: string;
            duration: number;
            description: string;
        }[];
    };
    isActive: boolean;
    validFrom?: Date;
    validUntil?: Date;
    maxSubscriptions?: number;
    currentSubscriptions: number;
    displayOrder: number;
    badge?: string;
    color?: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IModulePack, {}, {}, {}, mongoose.Document<unknown, {}, IModulePack, {}, {}> & IModulePack & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=ModulePack.d.ts.map