"use strict";
/**
 * API Admin Gateway - SYMPHONI.A
 * Administration centralisee de la plateforme
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const mongoose_1 = __importDefault(require("mongoose"));
// Routes
const users_1 = __importDefault(require("./routes/users"));
const companies_1 = __importDefault(require("./routes/companies"));
const subscriptions_1 = __importDefault(require("./routes/subscriptions"));
const modules_1 = __importDefault(require("./routes/modules"));
const api_keys_1 = __importDefault(require("./routes/api-keys"));
const audit_1 = __importDefault(require("./routes/audit"));
const announcements_1 = __importDefault(require("./routes/announcements"));
const dashboard_1 = __importDefault(require("./routes/dashboard"));
const crm_1 = __importDefault(require("./routes/crm"));
const auth_1 = __importDefault(require("./routes/auth"));
const commercial_portal_1 = __importDefault(require("./routes/commercial-portal"));
const manager_1 = __importStar(require("./routes/manager"));
const transport_scraping_1 = __importDefault(require("./routes/transport-scraping"));
// Middleware
const auth_2 = require("./middleware/auth");
// Background scraping imports
const scraping_service_1 = __importDefault(require("./services/scraping-service"));
const LeadSalon_1 = __importDefault(require("./models/LeadSalon"));
const LeadCompany_1 = __importDefault(require("./models/LeadCompany"));
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3020;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/rt-admin';
// Middleware - CORS configuration
const corsOrigin = process.env.CORS_ORIGIN;
app.use((0, cors_1.default)({
    origin: corsOrigin === '*' || !corsOrigin ? true : corsOrigin.split(','),
    credentials: true
}));
app.use(express_1.default.json({ limit: '10mb' }));
// Request logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});
// API Documentation
app.get('/', (req, res) => {
    res.json({
        name: 'RT Technologie Admin Gateway API',
        version: '1.0.0',
        description: 'Administration centralisee SYMPHONI.A',
        endpoints: {
            health: '/health',
            // User Management
            users: {
                list: 'GET /api/v1/admin/users',
                create: 'POST /api/v1/admin/users',
                get: 'GET /api/v1/admin/users/:id',
                update: 'PUT /api/v1/admin/users/:id',
                delete: 'DELETE /api/v1/admin/users/:id',
                activate: 'POST /api/v1/admin/users/:id/activate',
                deactivate: 'POST /api/v1/admin/users/:id/deactivate',
                resetPassword: 'POST /api/v1/admin/users/:id/reset-password',
                activity: 'GET /api/v1/admin/users/:id/activity',
                roles: 'PUT /api/v1/admin/users/:id/roles'
            },
            // Company Management
            companies: {
                list: 'GET /api/v1/admin/companies',
                create: 'POST /api/v1/admin/companies',
                get: 'GET /api/v1/admin/companies/:id',
                update: 'PUT /api/v1/admin/companies/:id',
                delete: 'DELETE /api/v1/admin/companies/:id',
                verify: 'POST /api/v1/admin/companies/:id/verify',
                suspend: 'POST /api/v1/admin/companies/:id/suspend',
                billing: 'GET /api/v1/admin/companies/:id/billing',
                subscription: 'PUT /api/v1/admin/companies/:id/subscription',
                modules: 'PUT /api/v1/admin/companies/:id/modules'
            },
            // Subscriptions & Billing
            subscriptions: {
                list: 'GET /api/v1/admin/subscriptions',
                get: 'GET /api/v1/admin/subscriptions/:id',
                update: 'PUT /api/v1/admin/subscriptions/:id',
                cancel: 'POST /api/v1/admin/subscriptions/:id/cancel'
            },
            invoices: {
                list: 'GET /api/v1/admin/invoices',
                refund: 'POST /api/v1/admin/invoices/:id/refund'
            },
            // Platform Monitoring
            dashboard: 'GET /api/v1/admin/dashboard',
            servicesHealth: 'GET /api/v1/admin/services/health',
            metrics: 'GET /api/v1/admin/metrics',
            logs: 'GET /api/v1/admin/logs',
            errors: 'GET /api/v1/admin/errors',
            // Module Management
            modules: {
                list: 'GET /api/v1/admin/modules',
                toggle: 'PUT /api/v1/admin/modules/:id/toggle',
                usage: 'GET /api/v1/admin/modules/:id/usage'
            },
            // API Keys
            apiKeys: {
                list: 'GET /api/v1/admin/api-keys',
                create: 'POST /api/v1/admin/api-keys',
                revoke: 'DELETE /api/v1/admin/api-keys/:id'
            },
            // Integrations
            integrations: {
                list: 'GET /api/v1/admin/integrations',
                configure: 'PUT /api/v1/admin/integrations/:id'
            },
            // Audit & Compliance
            audit: {
                list: 'GET /api/v1/admin/audit',
                export: 'GET /api/v1/admin/audit/export'
            },
            gdpr: {
                requests: 'GET /api/v1/admin/gdpr/requests',
                process: 'POST /api/v1/admin/gdpr/requests/:id/process'
            },
            // Notifications & Announcements
            notifications: {
                broadcast: 'POST /api/v1/admin/notifications/broadcast'
            },
            announcements: {
                list: 'GET /api/v1/admin/announcements',
                create: 'POST /api/v1/admin/announcements',
                update: 'PUT /api/v1/admin/announcements/:id',
                delete: 'DELETE /api/v1/admin/announcements/:id'
            },
            // CRM Lead Generation
            crm: {
                dashboard: 'GET /api/v1/admin/crm/dashboard',
                salons: {
                    list: 'GET /api/v1/admin/crm/salons',
                    create: 'POST /api/v1/admin/crm/salons',
                    get: 'GET /api/v1/admin/crm/salons/:id',
                    update: 'PUT /api/v1/admin/crm/salons/:id'
                },
                companies: {
                    list: 'GET /api/v1/admin/crm/companies',
                    create: 'POST /api/v1/admin/crm/companies',
                    get: 'GET /api/v1/admin/crm/companies/:id',
                    update: 'PUT /api/v1/admin/crm/companies/:id',
                    enrich: 'POST /api/v1/admin/crm/companies/:id/enrich',
                    assign: 'POST /api/v1/admin/crm/companies/:id/assign'
                },
                contacts: {
                    list: 'GET /api/v1/admin/crm/contacts',
                    create: 'POST /api/v1/admin/crm/contacts',
                    get: 'GET /api/v1/admin/crm/contacts/:id',
                    update: 'PUT /api/v1/admin/crm/contacts/:id',
                    verifyEmail: 'POST /api/v1/admin/crm/contacts/:id/verify-email'
                },
                emails: {
                    list: 'GET /api/v1/admin/crm/emails',
                    send: 'POST /api/v1/admin/crm/emails/send',
                    webhook: 'POST /api/v1/admin/crm/emails/webhook'
                },
                templates: {
                    list: 'GET /api/v1/admin/crm/templates',
                    create: 'POST /api/v1/admin/crm/templates',
                    update: 'PUT /api/v1/admin/crm/templates/:id'
                }
            }
        }
    });
});
// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        message: 'RT Admin Gateway API is running',
        version: '1.0.0',
        timestamp: new Date().toISOString(),
        mongodb: mongoose_1.default.connection.readyState === 1 ? 'connected' : 'disconnected'
    });
});
// Auth routes (public)
app.use('/auth', auth_1.default);
// Protected admin routes
app.use('/api/v1/admin/users', auth_2.authenticateAdmin, users_1.default);
app.use('/api/v1/admin/companies', auth_2.authenticateAdmin, companies_1.default);
app.use('/api/v1/admin/subscriptions', auth_2.authenticateAdmin, subscriptions_1.default);
app.use('/api/v1/admin/modules', auth_2.authenticateAdmin, modules_1.default);
app.use('/api/v1/admin/api-keys', auth_2.authenticateAdmin, api_keys_1.default);
app.use('/api/v1/admin/audit', auth_2.authenticateAdmin, audit_1.default);
app.use('/api/v1/admin/announcements', auth_2.authenticateAdmin, announcements_1.default);
app.use('/api/v1/admin/crm', crm_1.default); // CRM routes (auth handled internally, webhook needs to be public)
app.use('/api/v1/commercial', commercial_portal_1.default); // Commercial portal (auth handled internally)
app.use('/api/v1/admin/manager', manager_1.default); // Manager routes (pricing, packs, promos, contracts, installations)
app.use('/api/v1/installation', manager_1.publicInstallationRoutes); // Public installation validation routes
app.use('/api/v1/admin/transport-scraping', auth_2.authenticateAdmin, transport_scraping_1.default); // Transport scraping for Affret IA
app.use('/api/v1/admin', auth_2.authenticateAdmin, dashboard_1.default);
// Error handling
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
        success: false,
        error: err.message || 'Internal Server Error'
    });
});
// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Route not found',
        path: req.path
    });
});
// Connect to MongoDB and start server
mongoose_1.default.connect(MONGODB_URI)
    .then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => {
        console.log(`RT Admin Gateway API running on port ${PORT}`);
        console.log(`Documentation: http://localhost:${PORT}/`);
    });
})
    .catch((error) => {
    console.error('MongoDB connection error:', error);
    process.exit(1);
});
// Tache de fond pour scraper les salons actifs
async function startBackgroundScraping() {
    console.log('[Background] Starting background scraping service...');
    // Attendre 30 secondes avant de demarrer (laisser le serveur demarrer)
    await new Promise(r => setTimeout(r, 30000));
    // Fonction de scraping
    const runScraping = async () => {
        try {
            // Trouver les salons avec statut A_SCRAPER ou TERMINE (pour refresh)
            const salonsToScrape = await LeadSalon_1.default.find({
                statutScraping: { $in: ['A_SCRAPER', 'TERMINE'] },
                urlListeExposants: { $exists: true, $ne: null }
            }).limit(1); // Un salon a la fois
            for (const salon of salonsToScrape) {
                console.log('[Background] Scraping salon:', salon.nom);
                try {
                    // Mettre a jour le statut
                    salon.statutScraping = 'EN_COURS';
                    salon.derniereExecution = new Date();
                    await salon.save();
                    // Determiner l'adaptateur
                    let adapterName = 'Generic';
                    const url = salon.urlListeExposants || '';
                    if (url.includes('sialparis') || url.includes('sial'))
                        adapterName = 'SIAL';
                    else if (url.includes('sitl'))
                        adapterName = 'SITL';
                    else if (url.includes('transportlogistic'))
                        adapterName = 'TransportLogistic';
                    // Lancer le scraping
                    const result = await scraping_service_1.default.scrapeUrl(salon.urlListeExposants, adapterName);
                    if (result.success && result.companies.length > 0) {
                        let created = 0;
                        let duplicates = 0;
                        for (const company of result.companies) {
                            try {
                                const existingCompany = await LeadCompany_1.default.findOne({
                                    $or: [
                                        { raisonSociale: company.raisonSociale, salonSourceId: salon._id },
                                        { siteWeb: company.siteWeb }
                                    ]
                                });
                                if (existingCompany) {
                                    duplicates++;
                                    continue;
                                }
                                const paysValue = company.pays || 'France';
                                await LeadCompany_1.default.create({
                                    raisonSociale: company.raisonSociale,
                                    siteWeb: company.siteWeb,
                                    adresse: {
                                        ligne1: company.rue,
                                        ville: company.ville,
                                        codePostal: company.codePostal,
                                        pays: paysValue
                                    },
                                    produits: company.produits,
                                    telephone: company.telephone,
                                    emailGenerique: company.email,
                                    secteurActivite: company.secteurActivite || 'Agroalimentaire',
                                    descriptionActivite: company.descriptionActivite,
                                    salonSourceId: salon._id,
                                    urlPageExposant: company.urlPageExposant,
                                    numeroStand: company.numeroStand,
                                    statutProspection: 'NEW',
                                    inPool: true,
                                    dateAddedToPool: new Date(),
                                    prioritePool: 3
                                });
                                created++;
                            }
                            catch (e) {
                                // Ignorer les erreurs individuelles
                            }
                        }
                        // Mettre a jour le salon
                        salon.statutScraping = 'TERMINE';
                        salon.nbExposantsCollectes = (salon.nbExposantsCollectes || 0) + created;
                        await salon.save();
                        console.log('[Background] Scraping ' + salon.nom + ': ' + created + ' nouvelles, ' + duplicates + ' doublons');
                    }
                    else {
                        salon.statutScraping = 'TERMINE';
                        await salon.save();
                    }
                }
                catch (error) {
                    console.error('[Background] Scraping error for ' + salon.nom + ':', error.message);
                    salon.statutScraping = 'ERREUR';
                    await salon.save();
                }
            }
        }
        catch (error) {
            console.error('[Background] Background scraping error:', error.message);
        }
    };
    // Executer toutes les 10 minutes
    setInterval(runScraping, 10 * 60 * 1000);
    // Executer immediatement au demarrage
    runScraping();
}
exports.default = app;
//# sourceMappingURL=index.js.map