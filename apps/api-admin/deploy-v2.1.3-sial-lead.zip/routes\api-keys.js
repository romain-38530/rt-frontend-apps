"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ApiKey_1 = __importDefault(require("../models/ApiKey"));
const Company_1 = __importDefault(require("../models/Company"));
const uuid_1 = require("uuid");
const crypto_1 = __importDefault(require("crypto"));
const router = (0, express_1.Router)();
// List API keys
router.get('/', async (req, res) => {
    try {
        const { page = 1, limit = 20, companyId, status } = req.query;
        const query = {};
        if (companyId)
            query.companyId = companyId;
        if (status)
            query.status = status;
        const total = await ApiKey_1.default.countDocuments(query);
        const keys = await ApiKey_1.default.find(query)
            .populate('companyId', 'name')
            .populate('createdBy', 'firstName lastName email')
            .select('-key -keyHash') // Don't expose full key
            .sort({ createdAt: -1 })
            .skip((Number(page) - 1) * Number(limit))
            .limit(Number(limit));
        // Add key preview (last 4 chars)
        const keysWithPreview = keys.map(k => ({
            ...k.toObject(),
            keyPreview: '****' + k._id.toString().slice(-4)
        }));
        res.json({
            success: true,
            data: keysWithPreview,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                totalPages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Create API key
router.post('/', async (req, res) => {
    try {
        const { name, companyId, permissions, rateLimit, expiresAt } = req.body;
        const company = await Company_1.default.findById(companyId);
        if (!company) {
            return res.status(400).json({ success: false, error: 'Company not found' });
        }
        // Generate API key
        const key = `rt_${(0, uuid_1.v4)().replace(/-/g, '')}`;
        const keyHash = crypto_1.default.createHash('sha256').update(key).digest('hex');
        const apiKey = new ApiKey_1.default({
            name,
            key,
            keyHash,
            companyId,
            permissions: permissions || ['read'],
            rateLimit: rateLimit || 1000,
            status: 'active',
            createdBy: req.user.id,
            expiresAt: expiresAt ? new Date(expiresAt) : undefined
        });
        await apiKey.save();
        // Return the full key only on creation
        res.status(201).json({
            success: true,
            data: {
                id: apiKey._id,
                name: apiKey.name,
                key: key, // Only time the full key is returned
                permissions: apiKey.permissions,
                rateLimit: apiKey.rateLimit,
                expiresAt: apiKey.expiresAt,
                createdAt: apiKey.createdAt
            },
            message: 'Store this API key securely. It will not be shown again.'
        });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Revoke API key
router.delete('/:id', async (req, res) => {
    try {
        const apiKey = await ApiKey_1.default.findById(req.params.id);
        if (!apiKey) {
            return res.status(404).json({ success: false, error: 'API key not found' });
        }
        apiKey.status = 'revoked';
        apiKey.revokedAt = new Date();
        apiKey.revokedBy = req.user.id;
        await apiKey.save();
        res.json({ success: true, message: 'API key revoked' });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
// Update API key (permissions, rate limit)
router.put('/:id', async (req, res) => {
    try {
        const { permissions, rateLimit, name } = req.body;
        const apiKey = await ApiKey_1.default.findById(req.params.id);
        if (!apiKey) {
            return res.status(404).json({ success: false, error: 'API key not found' });
        }
        if (apiKey.status !== 'active') {
            return res.status(400).json({ success: false, error: 'Cannot update revoked or expired key' });
        }
        if (name)
            apiKey.name = name;
        if (permissions)
            apiKey.permissions = permissions;
        if (rateLimit)
            apiKey.rateLimit = rateLimit;
        await apiKey.save();
        res.json({ success: true, data: apiKey });
    }
    catch (error) {
        res.status(500).json({ success: false, error: String(error) });
    }
});
exports.default = router;
//# sourceMappingURL=api-keys.js.map