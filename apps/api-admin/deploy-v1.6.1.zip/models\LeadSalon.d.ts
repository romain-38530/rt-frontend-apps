import mongoose, { Document } from 'mongoose';
export type ScrapingStatus = 'A_SCRAPER' | 'EN_COURS' | 'TERMINE' | 'ERREUR' | 'DESACTIVE';
export interface ILeadSalon extends Document {
    nom: string;
    edition?: string;
    dateDebut?: Date;
    dateFin?: Date;
    lieu?: string;
    ville?: string;
    pays: string;
    urlSalon?: string;
    urlListeExposants?: string;
    categorie?: string;
    statutScraping: ScrapingStatus;
    derniereExecution?: Date;
    nbExposantsCollectes: number;
    adaptateurConfig?: Record<string, unknown>;
    sourceDecouverte?: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ILeadSalon, {}, {}, {}, mongoose.Document<unknown, {}, ILeadSalon, {}, {}> & ILeadSalon & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=LeadSalon.d.ts.map