import mongoose, { Document } from 'mongoose';
export type EmailTemplateType = 'PRESENTATION' | 'COMMERCIAL_INTRO' | 'RELANCE_1' | 'RELANCE_2';
export interface ILeadEmailTemplate extends Document {
    code: string;
    nom: string;
    typeEmail: EmailTemplateType;
    langue: string;
    sujetTemplate: string;
    corpsHtmlTemplate: string;
    corpsTextTemplate?: string;
    variablesDisponibles: string[];
    actif: boolean;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ILeadEmailTemplate, {}, {}, {}, mongoose.Document<unknown, {}, ILeadEmailTemplate, {}, {}> & ILeadEmailTemplate & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=LeadEmailTemplate.d.ts.map