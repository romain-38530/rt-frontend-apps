import mongoose, { Document } from 'mongoose';
export type EmailStatus = 'UNKNOWN' | 'VALID' | 'INVALID' | 'CATCH_ALL' | 'DISPOSABLE' | 'RISKY';
export type ContactStatus = 'NEW' | 'CONTACTED' | 'INTERESTED' | 'MEETING_SCHEDULED' | 'CONVERTED' | 'OPTED_OUT' | 'BOUNCED';
export type EnrichmentSource = 'APOLLO' | 'HUNTER' | 'LEMLIST' | 'MANUAL' | 'SCRAPING';
export type Seniority = 'director' | 'vp' | 'manager' | 'senior' | 'entry' | 'unknown';
export interface ILeadContact extends Document {
    entrepriseId: mongoose.Types.ObjectId;
    civilite?: string;
    prenom?: string;
    nom: string;
    poste?: string;
    seniority?: Seniority;
    email?: string;
    emailStatus: EmailStatus;
    telephoneDirect?: string;
    linkedinUrl?: string;
    sourceEnrichissement?: EnrichmentSource;
    apolloPersonId?: string;
    hunterData?: Record<string, unknown>;
    lemlistData?: Record<string, unknown>;
    dateEnrichissement?: Date;
    statutContact: ContactStatus;
    estContactPrincipal: boolean;
    optOut: boolean;
    dateOptOut?: Date;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ILeadContact, {}, {}, {}, mongoose.Document<unknown, {}, ILeadContact, {}, {}> & ILeadContact & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=LeadContact.d.ts.map