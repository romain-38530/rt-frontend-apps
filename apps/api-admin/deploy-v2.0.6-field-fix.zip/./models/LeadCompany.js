"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const LeadCompanySchema = new mongoose_1.Schema({
    // Identification
    raisonSociale: { type: String, required: true },
    formeJuridique: String,
    siren: { type: String, maxlength: 9 },
    siret: { type: String, maxlength: 14 },
    tvaIntracommunautaire: String,
    // Coordonnées
    adresse: {
        ligne1: String,
        ligne2: String,
        codePostal: String,
        ville: String,
        pays: { type: String, required: true, maxlength: 2 }
    },
    telephone: String,
    emailGenerique: String,
    siteWeb: String,
    linkedinCompanyUrl: String,
    // Informations business
    secteurActivite: String,
    codeNaf: String,
    effectifTranche: String,
    chiffreAffairesTranche: String,
    descriptionActivite: String,
    // Enrichissement Apollo (legacy)
    apolloOrgId: String,
    apolloData: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    dateEnrichissementApollo: Date,
    // Enrichissement Lemlist
    lemlistData: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    dateEnrichissement: Date,
    // Source
    salonSourceId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'LeadSalon' },
    urlPageExposant: String,
    numeroStand: String,
    // Prospection
    statutProspection: {
        type: String,
        enum: ['NEW', 'ENRICHED', 'CONTACTED', 'IN_PROGRESS', 'CONVERTED', 'LOST', 'BLACKLISTED'],
        default: 'NEW'
    },
    commercialAssigneId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User' },
    dateAssignation: Date,
    scoreLead: { type: Number, min: 0, max: 100 },
    // Pool de leads
    inPool: { type: Boolean, default: false },
    dateAddedToPool: Date,
    nbContactsEnrichis: { type: Number, default: 0 },
    lastContactAttempt: Date,
    prioritePool: { type: Number, min: 1, max: 5, default: 3 }
}, {
    timestamps: true
});
// Index unique sur SIREN si présent
LeadCompanySchema.index({ siren: 1 }, { unique: true, sparse: true });
LeadCompanySchema.index({ adresse_pays: 1 });
LeadCompanySchema.index({ statutProspection: 1 });
LeadCompanySchema.index({ commercialAssigneId: 1 });
LeadCompanySchema.index({ salonSourceId: 1 });
LeadCompanySchema.index({ raisonSociale: 'text', descriptionActivite: 'text' });
LeadCompanySchema.index({ secteurActivite: 1 });
LeadCompanySchema.index({ scoreLead: -1 });
LeadCompanySchema.index({ inPool: 1, prioritePool: -1, scoreLead: -1 });
LeadCompanySchema.index({ inPool: 1, 'adresse.pays': 1 });
exports.default = mongoose_1.default.model('LeadCompany', LeadCompanySchema);
//# sourceMappingURL=LeadCompany.js.map